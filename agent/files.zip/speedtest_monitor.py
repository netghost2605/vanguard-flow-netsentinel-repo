import subprocess
import json
import time
import threading
import re
import sys
import csv
import socket
from datetime import datetime, timedelta
from pathlib import Path
from collections import defaultdict
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.animation import FuncAnimation
from matplotlib.dates import DateFormatter
import matplotlib.dates as mdates
import matplotlib.widgets as mwidgets
import matplotlib.gridspec as gridspec
from matplotlib.colors import to_rgba
import mplcursors

# ── Paths ─────────────────────────────────────────────────────────────────────
if getattr(sys, 'frozen', False):
    import shutil, tempfile
    bundled_speedtest = Path(sys._MEIPASS) / "speedtest.exe"
    temp_dir = Path(tempfile.gettempdir()) / "speedtest_monitor"
    temp_dir.mkdir(exist_ok=True)
    SPEEDTEST_PATH = str(temp_dir / "speedtest.exe")
    DATA_FILE      = str(temp_dir / "speedtest_data.json")
    CONFIG_FILE    = str(temp_dir / "speedtest_config.json")
    if not Path(SPEEDTEST_PATH).exists() or bundled_speedtest.stat().st_mtime > Path(SPEEDTEST_PATH).stat().st_mtime:
        shutil.copy2(bundled_speedtest, SPEEDTEST_PATH)
else:
    SPEEDTEST_PATH = r"C:\Users\colli\Desktop\speedtest.exe"
    DATA_FILE      = "speedtest_data.json"
    CONFIG_FILE    = "speedtest_config.json"

# ── Default paths (overridable via Settings) ───────────────────────────────────
_DEFAULT_SPEEDTEST_PATH = SPEEDTEST_PATH
_DEFAULT_TSHARK_PATH    = r"C:\Program Files\Wireshark\tshark.exe"

INTERVAL_MINUTES = 5

# ── Colour themes ──────────────────────────────────────────────────────────────
THEMES = {
    "Ocean":  {"download": "#00d4aa", "upload": "#a371f7", "ping": "#f7cc73"},
    "Sunset": {"download": "#ff6b6b", "upload": "#ffd93d", "ping": "#6bcb77"},
    "Neon":   {"download": "#39ff14", "upload": "#ff073a", "ping": "#00b4d8"},
    "Pastel": {"download": "#74c7ec", "upload": "#cba6f7", "ping": "#f9e2af"},
    "Mono":   {"download": "#e0e0e0", "upload": "#a0a0a0", "ping": "#606060"},
}

VIEW_MODES = ["Today", "This Week", "This Month", "All Time"]

BG       = '#050d1a'
PANEL_BG = '#06101e'
TICK_COL = '#6a9ab8'
SPIN_COL = '#0a1828'
TEXT_COL = '#c8dff0'
DNS_COL  = '#ff9f43'


# ─────────────────────────────────────────────────────────────────────────────
#  Gauge drawing  –  futuristic neon full-circle style
# ─────────────────────────────────────────────────────────────────────────────
def _hex_rgb(h):
    h = h.lstrip('#')
    return tuple(int(h[i:i+2], 16) / 255 for i in (0, 2, 4))


def draw_gauge(ax, value, max_val, color, label, is_ping=False):
    ax.clear()
    ax.set_facecolor('#0a0d14')
    ax.set_aspect('equal')
    ax.axis('off')

    R_OUTER   = 1.00
    R_TRACK   = 0.88
    TRACK_W   = 0.09
    R_INNER   = 0.52
    R_HUB     = 0.10
    R_NEEDLE  = 0.80
    ANG_START = 225.0
    ANG_END   = -45.0
    SWEEP     = ANG_START - ANG_END
    N         = 512

    cr, cg, cb = _hex_rgb(color)

    def a2r(deg):
        return np.radians(deg)

    def frac_to_ang(f):
        return ANG_START - f * SWEEP

    frac = float(np.clip(value / max_val if max_val > 0 else 0, 0, 1))

    for r, a in [(0.90, 0.04), (0.60, 0.07), (0.35, 0.10)]:
        glow = plt.Circle((0, 0), r, color=(cr * 0.4, cg * 0.4, cb * 0.4), alpha=a, zorder=0)
        ax.add_patch(glow)

    SEGS = 90
    SEG_GAP = 0.35
    for s in range(SEGS):
        f0   = s / SEGS
        f1   = (s + (1 - SEG_GAP)) / SEGS
        a1   = a2r(ANG_START - f0 * SWEEP)
        a2   = a2r(ANG_START - f1 * SWEEP)
        th   = np.linspace(a1, a2, 8)
        ro   = R_TRACK + TRACK_W * 0.55
        ri   = R_TRACK - TRACK_W * 0.55
        xo   = ro * np.cos(th);  yo = ro * np.sin(th)
        xi   = ri * np.cos(th[::-1]); yi = ri * np.sin(th[::-1])
        dim  = (cr * 0.15, cg * 0.15, cb * 0.15)
        ax.fill(np.r_[xo, xi], np.r_[yo, yi], color=dim, alpha=0.9, zorder=2)

    if frac > 0.005:
        a1_deg = ANG_START
        a2_deg = frac_to_ang(frac)
        th_act = np.linspace(a2r(a1_deg), a2r(a2_deg), N)
        for rr, aa, ww in [(R_TRACK,0.08,28),(R_TRACK,0.13,18),(R_TRACK,0.25,10),(R_TRACK,0.55,5),(R_TRACK,0.90,2.5)]:
            ax.plot(rr * np.cos(th_act), rr * np.sin(th_act), color=color, lw=ww, alpha=aa, solid_capstyle='round', zorder=3)
        ax.plot(R_TRACK * np.cos(th_act), R_TRACK * np.sin(th_act), color='white', lw=1.0, alpha=0.85, zorder=4)
        ro  = R_TRACK + TRACK_W * 0.55
        ri  = R_TRACK - TRACK_W * 0.55
        thf = np.linspace(a2r(a1_deg), a2r(a2_deg), N)
        xo  = ro * np.cos(thf);  yo = ro * np.sin(thf)
        xi  = ri * np.cos(thf[::-1]); yi = ri * np.sin(thf[::-1])
        ax.fill(np.r_[xo, xi], np.r_[yo, yi], color=color, alpha=0.45, zorder=3)

    th_full = np.linspace(a2r(ANG_START), a2r(ANG_END - 0.5), N)
    ax.plot(R_OUTER * np.cos(th_full), R_OUTER * np.sin(th_full),
            color=(cr * 0.5, cg * 0.5, cb * 0.5), lw=1.5, alpha=0.5, zorder=5)

    N_MAJOR = 11
    for i in range(N_MAJOR):
        f     = i / (N_MAJOR - 1)
        ang   = a2r(frac_to_ang(f))
        major = (i % 5 == 0)
        r0  = R_OUTER + 0.02
        r1  = R_OUTER + (0.11 if major else 0.06)
        lw  = 1.6 if major else 0.8
        col = (0.7, 0.7, 0.8) if major else (0.35, 0.35, 0.4)
        ax.plot([r0 * np.cos(ang), r1 * np.cos(ang)],
                [r0 * np.sin(ang), r1 * np.sin(ang)], color=col, lw=lw, zorder=6)
        if i < N_MAJOR - 1:
            for m in range(1, 5):
                fm   = f + m / ((N_MAJOR - 1) * 4)
                angm = a2r(frac_to_ang(fm))
                ax.plot([(R_OUTER+0.02)*np.cos(angm),(R_OUTER+0.045)*np.cos(angm)],
                        [(R_OUTER+0.02)*np.sin(angm),(R_OUTER+0.045)*np.sin(angm)],
                        color=(0.25, 0.25, 0.3), lw=0.6, zorder=6)
        if major:
            rv = r1 + 0.16
            ax.text(rv * np.cos(ang), rv * np.sin(ang), str(int(round(f * max_val))),
                    color='#aab4be', fontsize=7.5, ha='center', va='center', fontweight='bold', zorder=6)

    th_inner = np.linspace(0, 2 * np.pi, N)
    for lw, aa in [(14, 0.04), (8, 0.08), (4, 0.18), (1.5, 0.60)]:
        ax.plot(R_INNER * np.cos(th_inner), R_INNER * np.sin(th_inner),
                color=color, lw=lw, alpha=aa, zorder=5)
    ax.plot(R_INNER * np.cos(th_inner), R_INNER * np.sin(th_inner),
            color='white', lw=0.6, alpha=0.4, zorder=5)

    ang_n   = a2r(frac_to_ang(frac))
    perp    = ang_n + np.pi / 2
    hw_base = 0.045
    hw_tip  = 0.008
    nx = [np.cos(perp)*hw_base, np.cos(ang_n)*R_NEEDLE+np.cos(perp)*hw_tip,
          np.cos(ang_n)*R_NEEDLE-np.cos(perp)*hw_tip, -np.cos(perp)*hw_base]
    ny = [np.sin(perp)*hw_base, np.sin(ang_n)*R_NEEDLE+np.sin(perp)*hw_tip,
          np.sin(ang_n)*R_NEEDLE-np.sin(perp)*hw_tip, -np.sin(perp)*hw_base]
    for lw, aa in [(10, 0.06), (5, 0.15), (2, 0.4)]:
        ax.plot([0, np.cos(ang_n)*R_NEEDLE], [0, np.sin(ang_n)*R_NEEDLE],
                color=color, lw=lw, alpha=aa, solid_capstyle='round', zorder=7)
    ax.fill(nx, ny, color='white', alpha=0.92, zorder=8)

    for r, aa in [(R_HUB*1.8, 0.10), (R_HUB*1.3, 0.20)]:
        ax.add_patch(plt.Circle((0, 0), r, color=color, alpha=aa, zorder=8))
    ax.add_patch(plt.Circle((0, 0), R_HUB, color='#0d1020', ec='white', linewidth=1.2, alpha=0.95, zorder=9))
    ax.add_patch(plt.Circle((0, 0), R_HUB * 0.45, color=color, alpha=0.9, zorder=10))

    unit = 'ms' if is_ping else 'Mbps'
    ax.text(0, 0.22, f"{value:.1f}", color='white', fontsize=26, fontweight='bold',
            ha='center', va='center', zorder=11, fontfamily='monospace')
    ax.text(0, 0.04, unit, color=(cr*0.9, cg*0.9, cb*0.9), fontsize=9, ha='center', va='center', zorder=11)
    ax.text(0, -0.72, label, color=color, fontsize=11, fontweight='bold', ha='center', va='center', zorder=11)
    ax.plot(-0.14, -0.88, 'o', color='#2ea043', ms=5, zorder=11)
    ax.text(-0.04, -0.88, 'LIVE', color='#2ea043', fontsize=7, va='center', zorder=11)
    ax.set_xlim(-1.55, 1.55)
    ax.set_ylim(-1.75, 1.45)


# ─────────────────────────────────────────────────────────────────────────────
#  Background image path
# ─────────────────────────────────────────────────────────────────────────────
def _bg_image_path():
    if getattr(sys, 'frozen', False):
        p = Path(sys._MEIPASS) / 'bg.jpg'
        if p.exists():
            return str(p)
    candidates = [
        Path(__file__).parent / 'bg.jpg',
        Path(sys.argv[0]).parent / 'bg.jpg',
        Path('bg.jpg'),
    ]
    for c in candidates:
        if c.exists():
            return str(c)
    return None


def draw_metal_bg(fig, dial_bot, chart_top, chart_bot):
    import matplotlib.image as mpimg

    bg = fig.add_axes([0, 0, 1, 1], zorder=-20)
    bg.set_xlim(0, 1); bg.set_ylim(0, 1)
    bg.axis('off'); bg.patch.set_visible(False)

    img_path = _bg_image_path()
    if img_path:
        try:
            img = mpimg.imread(img_path)
            bg.imshow(img, aspect='auto', extent=[0, 1, 0, 1], zorder=1, alpha=1.0)
        except Exception:
            img_path = None

    if not img_path:
        bg.add_patch(mpatches.Rectangle((0, 0), 1, 1, facecolor='#050d1a', edgecolor='none', zorder=1))

    bg.add_patch(mpatches.Rectangle((0, 0), 1, 1, facecolor='#020810', alpha=0.55, edgecolor='none', zorder=2))
    bg.add_patch(mpatches.Rectangle((0, 0), 1, chart_top, facecolor='#010508', alpha=0.35, edgecolor='none', zorder=3))

    for side in (0, 1):
        for w, a in [(0.12, 0.45), (0.06, 0.25)]:
            x0 = 0.0 if side == 0 else 1.0 - w
            bg.add_patch(mpatches.Rectangle((x0, 0), w, 1, facecolor='#000408', alpha=a, edgecolor='none', zorder=4))

    for tb, h in [(0.0, 0.03), (0.97, 0.03)]:
        bg.add_patch(mpatches.Rectangle((0, tb), 1, h, facecolor='#000408', alpha=0.60, edgecolor='none', zorder=4))

    def chrome_bar(y_c, h=0.010):
        layers = [('#0a0e18',h*1.0,0.95),('#1a3060',h*0.70,0.80),
                  ('#3a6898',h*0.45,0.75),('#7ab0d8',h*0.22,0.80),('#c8e4f4',h*0.06,0.90)]
        for col_, frac, aa in layers:
            bg.add_patch(mpatches.Rectangle((0, y_c-h*0.5), 1.0, h*frac,
                         facecolor=col_, alpha=aa, edgecolor='none', zorder=10, transform=bg.transAxes))
        bg.plot([0, 1], [y_c+h*0.35, y_c+h*0.35], color='#d0eaf8', lw=0.8, alpha=0.70, zorder=11)

    chrome_bar(dial_bot,  h=0.012)
    chrome_bar(chart_top, h=0.008)
    chrome_bar(chart_bot, h=0.012)


# ─────────────────────────────────────────────────────────────────────────────
#  View-selector dial
# ─────────────────────────────────────────────────────────────────────────────
_VIEW_LABELS = ["Today", "This\nWeek", "This\nMonth", "All\nTime"]
_VIEW_KEYS   = ["Today", "This Week", "This Month", "All Time"]
_VIEW_COLOR  = '#38b8f0'


def draw_view_dial(ax, current_view):
    ax.clear(); ax.set_facecolor('#0a0d14'); ax.set_aspect('equal'); ax.axis('off')
    N=len(_VIEW_KEYS); R_OUT=1.00; R_MID=0.80; R_IN=0.58; R_HUB=0.10
    ANG_START=225.0; ANG_END=-45.0; SWEEP=ANG_START-ANG_END; SMOOTH=256; GAP_DEG=2.5
    cr,cg,cb=_hex_rgb(_VIEW_COLOR)
    for r,a in [(0.80,0.04),(0.50,0.07),(0.28,0.10)]:
        ax.add_patch(plt.Circle((0,0),r,color=(cr*0.3,cg*0.3,cb*0.3),alpha=a,zorder=0))
    seg_ranges=[]
    for i,(vkey,vlbl) in enumerate(zip(_VIEW_KEYS,_VIEW_LABELS)):
        f0=i/N; f1=(i+1)/N; seg_ranges.append((f0,f1,vkey))
        a1=np.radians(ANG_START-f0*SWEEP+GAP_DEG/2); a2=np.radians(ANG_START-f1*SWEEP-GAP_DEG/2)
        th=np.linspace(a1,a2,SMOOTH)
        xo=R_OUT*np.cos(th); yo=R_OUT*np.sin(th)
        xi=R_IN*np.cos(th[::-1]); yi=R_IN*np.sin(th[::-1])
        active=(vkey==current_view)
        if active:
            for lw,aa in [(22,0.05),(13,0.11),(6,0.24),(2,0.58)]:
                ax.plot(R_OUT*np.cos(th),R_OUT*np.sin(th),color=_VIEW_COLOR,lw=lw,alpha=aa,solid_capstyle='butt',zorder=3)
            ax.fill(np.r_[xo,xi],np.r_[yo,yi],color=_VIEW_COLOR,alpha=0.32,zorder=4)
            ax.plot(R_OUT*np.cos(th),R_OUT*np.sin(th),color='white',lw=0.8,alpha=0.50,zorder=5)
        else:
            dim=(cr*0.11,cg*0.11,cb*0.11)
            ax.fill(np.r_[xo,xi],np.r_[yo,yi],color=dim,alpha=0.85,zorder=2)
            ax.plot(R_OUT*np.cos(th),R_OUT*np.sin(th),color=(0.14,0.24,0.34),lw=0.8,alpha=0.55,zorder=2)
        f_mid=(f0+f1)/2; ang_m=np.radians(ANG_START-f_mid*SWEEP)
        col_='white' if active else (0.35,0.56,0.72); fw='bold' if active else 'normal'
        ax.text(R_MID*np.cos(ang_m),R_MID*np.sin(ang_m),vlbl,
                color=col_,fontsize=7.5,fontweight=fw,ha='center',va='center',zorder=6,linespacing=1.2)
        for f_tick in (f0,f1):
            ang_t=np.radians(ANG_START-f_tick*SWEEP)
            ax.plot([R_OUT*np.cos(ang_t),(R_OUT+0.09)*np.cos(ang_t)],
                    [R_OUT*np.sin(ang_t),(R_OUT+0.09)*np.sin(ang_t)],color='#2a4a6a',lw=1.2,zorder=6)
    th_full=np.linspace(np.radians(ANG_START),np.radians(ANG_END-0.5),SMOOTH)
    ax.plot(R_OUT*np.cos(th_full),R_OUT*np.sin(th_full),
            color=(cr*0.4,cg*0.4,cb*0.4),lw=1.2,alpha=0.5,zorder=5)
    th_inn=np.linspace(0,2*np.pi,SMOOTH)
    for lw_,aa_ in [(10,0.04),(5,0.10),(2,0.26),(0.8,0.55)]:
        ax.plot(R_IN*np.cos(th_inn),R_IN*np.sin(th_inn),color=_VIEW_COLOR,lw=lw_,alpha=aa_,zorder=5)
    for r_,aa_ in [(R_HUB*1.7,0.10),(R_HUB*1.2,0.20)]:
        ax.add_patch(plt.Circle((0,0),r_,color=_VIEW_COLOR,alpha=aa_,zorder=7))
    ax.add_patch(plt.Circle((0,0),R_HUB,color='#0d1020',ec='white',lw=1.2,zorder=8))
    ax.add_patch(plt.Circle((0,0),R_HUB*0.45,color=_VIEW_COLOR,alpha=0.9,zorder=9))
    ax.text(0,0.22,"VIEW",color='white',fontsize=11,fontweight='bold',ha='center',va='center',zorder=10)
    ax.text(0,0.05,"MODE",color=(cr*.8,cg*.8,cb*.8),fontsize=7.5,ha='center',va='center',zorder=10)
    ax.text(0,-0.20,current_view.upper().replace(" ","\n"),
            color=_VIEW_COLOR,fontsize=7,fontweight='bold',ha='center',va='center',zorder=10,linespacing=1.1)
    ax.set_xlim(-1.55,1.55); ax.set_ylim(-1.45,1.45)
    return seg_ranges


class SpeedTestMonitor:
    def __init__(self):
        self.config  = self._load_config()
        self.data    = self._load_data()
        self.current_view   = "Today"
        self.history_offset = 0
        self._fig           = None
        self._d_dl   = 0.0
        self._d_ul   = 0.0
        self._d_ping = 0.0
        self._d_dns  = 0.0
        self._dns_history = []
        self._running_dns    = False
        self._running_manual = False

    # ── Config / data persistence ──────────────────────────────────────────────
    def _load_config(self):
        defs = {"theme": "Ocean", "custom": None,
                "speedtest_path": "", "tshark_path": ""}
        if Path(CONFIG_FILE).exists():
            try:
                with open(CONFIG_FILE) as f:
                    loaded = json.load(f)
                if isinstance(loaded.get('theme'), str):
                    if loaded['theme'] in ('Ocean', 'Sunset', 'Neon', 'Pastel', 'Mono', None):
                        defs['theme'] = loaded['theme']
                if isinstance(loaded.get('custom'), dict):
                    custom = loaded['custom']
                    safe = {}
                    for k in ('download', 'upload', 'ping'):
                        v = custom.get(k, '')
                        if isinstance(v, str) and len(v) == 7 and v.startswith('#'):
                            if all(c in '0123456789abcdefABCDEF' for c in v[1:]):
                                safe[k] = v
                    if len(safe) == 3:
                        defs['custom'] = safe
                for key in ('speedtest_path', 'tshark_path'):
                    v = loaded.get(key, '')
                    if isinstance(v, str):
                        defs[key] = v.strip()
            except Exception:
                pass
        return defs

    def _save_config(self):
        with open(CONFIG_FILE, 'w') as f:
            json.dump(self.config, f, indent=2)

    @property
    def _speedtest_exe(self):
        p = self.config.get('speedtest_path', '').strip()
        return p if p else _DEFAULT_SPEEDTEST_PATH

    @property
    def _tshark_exe(self):
        p = self.config.get('tshark_path', '').strip()
        return p if p else _DEFAULT_TSHARK_PATH

    def _load_data(self):
        if Path(DATA_FILE).exists():
            try:
                with open(DATA_FILE) as f:
                    raw = f.read()
                    d = json.loads(raw) if raw else self._empty()
                    if not isinstance(d, dict):
                        return self._empty()
                    for key in ('timestamps', 'download', 'upload', 'ping',
                                'dns_timestamps', 'dns_values'):
                        if not isinstance(d.get(key), list):
                            d[key] = []
                    d.setdefault('dns_timestamps', [])
                    d.setdefault('dns_values', [])
                    for key in ('timestamps', 'download', 'upload', 'ping'):
                        d[key] = d[key][-10000:]
                    d['dns_timestamps'] = d['dns_timestamps'][-500:]
                    d['dns_values']     = d['dns_values'][-500:]
                    n = min(len(d['timestamps']), len(d['download']),
                            len(d['upload']), len(d['ping']))
                    for key in ('timestamps', 'download', 'upload', 'ping'):
                        d[key] = d[key][:n]
                    n_dns = min(len(d['dns_timestamps']), len(d['dns_values']))
                    d['dns_timestamps'] = d['dns_timestamps'][:n_dns]
                    d['dns_values']     = d['dns_values'][:n_dns]
                    self._dns_history = list(zip(d['dns_timestamps'], d['dns_values']))
                    return d
            except Exception:
                pass
        return self._empty()

    def _empty(self):
        return {'timestamps': [], 'download': [], 'upload': [], 'ping': [],
                'dns_timestamps': [], 'dns_values': []}

    def _save_data(self):
        self.data['dns_timestamps'] = [ts for ts, _ in self._dns_history]
        self.data['dns_values']     = [v  for _, v in self._dns_history]
        with open(DATA_FILE, 'w') as f:
            json.dump(self.data, f, indent=2)

    def export_range(self, start_dt, end_dt, fmt='csv'):
        rows = []
        for ts, dl, ul, pg in zip(
                self.data['timestamps'], self.data['download'],
                self.data['upload'], self.data['ping']):
            t = datetime.fromisoformat(ts)
            if start_dt <= t <= end_dt:
                rows.append({'timestamp': ts, 'download_mbps': dl,
                             'upload_mbps': ul, 'ping_ms': pg})
        stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        if fmt == 'json':
            out = Path(DATA_FILE).parent / f"speedtest_export_{stamp}.json"
            with open(out, 'w') as f:
                json.dump(rows, f, indent=2)
        else:
            out = Path(DATA_FILE).parent / f"speedtest_export_{stamp}.csv"
            with open(out, 'w', newline='') as f:
                writer = csv.DictWriter(
                    f, fieldnames=['timestamp','download_mbps','upload_mbps','ping_ms'])
                writer.writeheader(); writer.writerows(rows)
        return str(out), len(rows)

    def _export_to(self, start_dt, end_dt, fmt, out_dir):
        rows = []
        for ts, dl, ul, pg in zip(
                self.data['timestamps'], self.data['download'],
                self.data['upload'], self.data['ping']):
            t = datetime.fromisoformat(ts)
            if start_dt <= t <= end_dt:
                rows.append({'timestamp': ts, 'download_mbps': dl,
                             'upload_mbps': ul, 'ping_ms': pg})
        out_dir = Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        if fmt == 'json':
            out = out_dir / f"speedtest_export_{stamp}.json"
            with open(out, 'w') as f:
                json.dump(rows, f, indent=2)
        else:
            out = out_dir / f"speedtest_export_{stamp}.csv"
            with open(out, 'w', newline='') as f:
                writer = csv.DictWriter(
                    f, fieldnames=['timestamp','download_mbps','upload_mbps','ping_ms'])
                writer.writeheader(); writer.writerows(rows)
        return str(out), len(rows)

    @property
    def colors(self):
        if self.config.get("custom"):
            return self.config["custom"]
        return THEMES.get(self.config.get("theme", "Ocean"), THEMES["Ocean"])

    # ── Speed test ─────────────────────────────────────────────────────────────
    def run_speedtest(self):
        try:
            ts = datetime.now().strftime('%H:%M:%S')
            print(f"[{ts}] Running speed test...")
            exe = self._speedtest_exe
            if not Path(exe).exists():
                raise FileNotFoundError(f"speedtest.exe not found at: {exe}")
            dl = ul = pg = None
            r = subprocess.run(
                [exe, "--format=json", "--accept-license", "--accept-gdpr"],
                capture_output=True, text=True, timeout=150)
            print(f"   JSON attempt: exit={r.returncode}")
            if r.stderr.strip():
                print(f"   stderr: {r.stderr.strip()[:300]}")
            if r.returncode == 0:
                try:
                    st = json.loads(r.stdout.strip())
                    if 'bandwidth' in st.get('download', {}):
                        dl = round(st['download']['bandwidth'] / 125000, 2)
                        ul = round(st['upload']['bandwidth']   / 125000, 2)
                        pg = st['ping']['latency']
                    elif 'download' in st:
                        dl = round(st['download'] / 1e6, 2) if st['download'] > 1000 else float(st['download'])
                        ul = round(st['upload']   / 1e6, 2) if st['upload']   > 1000 else float(st['upload'])
                        pg = float(st.get('ping', 0))
                    else:
                        print("   JSON parsed but no download key found")
                except (json.JSONDecodeError, KeyError, TypeError) as e:
                    print(f"   JSON parse failed: {e}")
            else:
                print(f"   JSON mode not supported (exit {r.returncode}), trying plain-text...")
            if dl is None:
                r2 = subprocess.run(
                    [exe, "--accept-license", "--accept-gdpr"],
                    capture_output=True, text=True, timeout=150)
                txt = r2.stdout + r2.stderr
                dl = self._rx(txt, r'Download[^:]*:\s*([\d.]+)')
                ul = self._rx(txt, r'Upload[^:]*:\s*([\d.]+)')
                pg = self._rx(txt, r'(?:Latency|Ping)[^:]*:\s*([\d.]+)')
            if dl is None:
                r3 = subprocess.run([exe], capture_output=True, text=True, timeout=150)
                txt3 = r3.stdout + r3.stderr
                dl = self._rx(txt3, r'Download[^:]*:\s*([\d.]+)')
                ul = self._rx(txt3, r'Upload[^:]*:\s*([\d.]+)')
                pg = self._rx(txt3, r'(?:Latency|Ping)[^:]*:\s*([\d.]+)')
            if dl is None:
                raise ValueError("All attempts failed – could not read speed values.")
            pg = pg if pg is not None else 0.0
            ul = ul if ul is not None else 0.0
            self.data['timestamps'].append(datetime.now().isoformat())
            self.data['download'].append(dl)
            self.data['upload'].append(ul)
            self.data['ping'].append(pg)
            for key in ('timestamps', 'download', 'upload', 'ping'):
                if len(self.data[key]) > 10000:
                    self.data[key] = self.data[key][-10000:]
            self._save_data()
            print(f" ✓ DL {dl} Mbps | UL {ul} Mbps | Ping {pg} ms")
        except Exception as e:
            print(f" ✗ {e}")

    DNS_HOSTS = ['google.com', 'cloudflare.com', 'microsoft.com',
                 'amazon.com', 'bbc.co.uk', 'github.com']

    def run_dns_check(self):
        results = []
        for host in self.DNS_HOSTS:
            try:
                t0 = time.perf_counter(); socket.getaddrinfo(host, None)
                results.append((time.perf_counter() - t0) * 1000)
            except OSError:
                pass
        if not results: return None
        avg_ms = round(sum(results) / len(results), 2)
        self._dns_history.append((datetime.now().isoformat(), avg_ms))
        if len(self._dns_history) > 500:
            self._dns_history = self._dns_history[-500:]
        print(f"   DNS avg: {avg_ms:.1f} ms  ({len(results)}/{len(self.DNS_HOSTS)} hosts)")
        self._save_data()
        return avg_ms

    def _rx(self, text, pat):
        m = re.search(pat, text, re.IGNORECASE)
        if m:
            v = m.group(1) or (m.lastindex >= 2 and m.group(2))
            return float(v) if v else None
        return None

    @staticmethod
    def _style(ax):
        ax.set_facecolor(PANEL_BG)
        ax.yaxis.grid(True, color='#1a2535', linewidth=0.7, alpha=0.9, zorder=0)
        ax.xaxis.grid(False); ax.set_axisbelow(True)
        ax.tick_params(colors=TICK_COL, labelsize=8, length=3)
        for side, sp in ax.spines.items():
            if side in ('top', 'right'):
                sp.set_color('#3a4a5a'); sp.set_linewidth(0.6); sp.set_visible(True)
            elif side == 'left':
                sp.set_color('#0a1018'); sp.set_linewidth(1.2)
            else:
                sp.set_color('#0a1018'); sp.set_linewidth(1.2)

    @staticmethod
    def _titl(ax, ylabel, title):
        ax.set_ylabel(ylabel, color=TICK_COL, fontsize=8, labelpad=6)
        ax.set_title(title, loc='left', color=TEXT_COL, fontsize=10, fontweight='bold', pad=8)

    @staticmethod
    def _neon_bar(ax, xs, ys, width, color, **kw):
        cr, cg, cb = _hex_rgb(color)
        ax.bar(xs, ys, width=width*3.5, color=(cr*0.35,cg*0.35,cb*0.35), alpha=0.18, zorder=1)
        ax.bar(xs, ys, width=width*2.0, color=(cr*0.6,cg*0.6,cb*0.6), alpha=0.22, zorder=2)
        ax.bar(xs, ys, width=width, color=color, alpha=0.90, zorder=3, **kw)
        for x, y in zip(xs, ys):
            if y and y > 0:
                ax.plot([x-width/2, x+width/2], [y, y], color='white', lw=0.8, alpha=0.55, zorder=4)

    @staticmethod
    def _neon_line(ax, xs, ys, color, marker=True):
        cr, cg, cb = _hex_rgb(color)
        ys_arr = np.array(ys, dtype=float)
        ax.fill_between(xs, 0, ys_arr, color=(cr*0.4,cg*0.4,cb*0.4), alpha=0.18, zorder=1)
        for lw, aa in [(12,0.04),(7,0.09),(3.5,0.22)]:
            ax.plot(xs, ys_arr, color=color, lw=lw, alpha=aa, solid_capstyle='round', zorder=2)
        ax.plot(xs, ys_arr, color=color, lw=1.4, alpha=0.95, solid_capstyle='round', zorder=3)
        ax.plot(xs, ys_arr, color='white', lw=0.5, alpha=0.35, solid_capstyle='round', zorder=4)
        if marker and len(xs) <= 60:
            ax.scatter(xs, ys_arr, s=28, color=color, zorder=5,
                       edgecolors='white', linewidths=0.5, alpha=0.9)

    # ── Settings dialog ────────────────────────────────────────────────────────
    def _open_settings_dialog(self, on_saved=None):
        """Dark-themed Settings dialog for configuring executable paths."""
        import tkinter as tk
        from tkinter import filedialog
        import shutil as _shutil

        # Toplevel shares the existing Tk root that matplotlib already created.
        # Using tk.Tk() a second time breaks StringVar updates and filedialog.
        win = tk.Toplevel()
        win.title('Settings')
        win.configure(bg='#0a1828')
        win.resizable(False, False)
        win.grab_set()
        win.lift()
        win.focus_force()

        FG = '#c8dff0'; BG2 = '#0a1828'; ENT = '#0d2235'
        ACC = '#38b8f0'; WARN = '#ff9f43'

        def lbl(parent, text, fg=FG, **kw):
            return tk.Label(parent, text=text, fg=fg, bg=BG2,
                            font=('Consolas', 9), **kw)

        def mk_entry(parent, width=46):
            return tk.Entry(parent, width=width,
                            bg=ENT, fg=FG, insertbackground=FG, relief='flat',
                            font=('Consolas', 9), highlightthickness=1,
                            highlightcolor=ACC, highlightbackground='#1a3050')

        tk.Label(win, text='⚙  Settings', fg=ACC, bg=BG2,
                 font=('Consolas', 12, 'bold')).pack(pady=(14, 4), padx=14, anchor='w')
        tk.Frame(win, bg='#1a3050', height=1).pack(fill='x', padx=12)

        # ── speedtest.exe ─────────────────────────────────────────────────────
        tk.Label(win, text='  Speedtest CLI', fg=ACC, bg='#060f1c',
                 font=('Consolas', 9, 'bold')).pack(fill='x', pady=(10, 0))
        tk.Frame(win, bg='#060f1c', height=1).pack(fill='x')
        sf = tk.Frame(win, bg=BG2); sf.pack(fill='x', padx=10, pady=4)
        sf.columnconfigure(1, weight=1)

        lbl(sf, 'speedtest.exe').grid(row=0, column=0, sticky='w', padx=(4, 6), pady=3)
        st_entry = mk_entry(sf)
        st_entry.insert(0, self.config.get('speedtest_path', ''))
        st_entry.grid(row=0, column=1, padx=(0, 4), pady=3, sticky='ew')
        bf1 = tk.Frame(sf, bg=BG2); bf1.grid(row=0, column=2, padx=(0, 4))

        st_status = tk.StringVar(value='')

        def _browse_st():
            p = filedialog.askopenfilename(parent=win, title='Locate speedtest.exe',
                filetypes=[('Executable', '*.exe'), ('All files', '*.*')])
            if p:
                st_entry.delete(0, 'end')
                st_entry.insert(0, p)
                st_status.set('')

        def _test_st():
            exe = st_entry.get().strip() or _DEFAULT_SPEEDTEST_PATH
            st_status.set('Testing…')
            def _w():
                if not Path(exe).exists():
                    win.after(0, lambda: st_status.set('✗  Not found')); return
                try:
                    flags = subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0
                    r = subprocess.run([exe, '--version'], capture_output=True,
                                       text=True, timeout=10, creationflags=flags)
                    ver = (r.stdout + r.stderr).strip().splitlines()
                    win.after(0, lambda: st_status.set(
                        f'✓  {ver[0][:55]}' if ver else '✓  OK'))
                except Exception as ex:
                    win.after(0, lambda: st_status.set(f'✗  {ex}'))
            threading.Thread(target=_w, daemon=True).start()

        tk.Button(bf1, text='Browse…', bg=ENT, fg=ACC, relief='flat',
                  font=('Consolas', 8), cursor='hand2',
                  command=_browse_st).pack(side='left', padx=(0, 3))
        tk.Button(bf1, text='Test', bg=ENT, fg='#38f0a8', relief='flat',
                  font=('Consolas', 8), cursor='hand2',
                  command=_test_st).pack(side='left')

        lbl(sf, f'Default: {_DEFAULT_SPEEDTEST_PATH}', fg='#2a4a6a').grid(
            row=1, column=1, sticky='w', padx=(0, 4))
        tk.Label(sf, textvariable=st_status, fg='#38f0a8', bg=BG2,
                 font=('Consolas', 8)).grid(row=2, column=1, sticky='w',
                                            padx=(0, 4), pady=(0, 6))

        # ── tshark.exe ────────────────────────────────────────────────────────
        tk.Label(win, text='  Wireshark / tshark', fg=ACC, bg='#060f1c',
                 font=('Consolas', 9, 'bold')).pack(fill='x', pady=(8, 0))
        tk.Frame(win, bg='#060f1c', height=1).pack(fill='x')
        tf = tk.Frame(win, bg=BG2); tf.pack(fill='x', padx=10, pady=4)
        tf.columnconfigure(1, weight=1)

        lbl(tf, 'tshark.exe').grid(row=0, column=0, sticky='w', padx=(4, 6), pady=3)
        tsh_entry = mk_entry(tf)
        tsh_entry.insert(0, self.config.get('tshark_path', ''))
        tsh_entry.grid(row=0, column=1, padx=(0, 4), pady=3, sticky='ew')
        bf2 = tk.Frame(tf, bg=BG2); bf2.grid(row=0, column=2, padx=(0, 4))

        tsh_status = tk.StringVar(value='')

        def _browse_tsh():
            cur = tsh_entry.get().strip()
            init = str(Path(cur).parent) if cur else r'C:\Program Files\Wireshark'
            p = filedialog.askopenfilename(parent=win, title='Locate tshark.exe',
                initialdir=init, filetypes=[('Executable', '*.exe'), ('All files', '*.*')])
            if p:
                tsh_entry.delete(0, 'end')
                tsh_entry.insert(0, p)
                tsh_status.set('')

        def _test_tsh():
            exe = tsh_entry.get().strip() or _DEFAULT_TSHARK_PATH
            tsh_status.set('Testing…')
            def _w():
                if not Path(exe).exists():
                    win.after(0, lambda: tsh_status.set('✗  Not found')); return
                try:
                    flags = subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0
                    r = subprocess.run([exe, '--version'], capture_output=True,
                                       text=True, timeout=10, creationflags=flags)
                    ver = (r.stdout + r.stderr).strip().splitlines()
                    win.after(0, lambda: tsh_status.set(
                        f'✓  {ver[0][:55]}' if ver else '✓  OK'))
                except Exception as ex:
                    win.after(0, lambda: tsh_status.set(f'✗  {ex}'))
            threading.Thread(target=_w, daemon=True).start()

        def _auto_detect():
            # Run in thread so "Searching" label renders before result arrives
            tsh_status.set('Searching…')
            def _w():
                candidates = [
                    r'C:\Program Files\Wireshark\tshark.exe',
                    r'C:\Program Files (x86)\Wireshark\tshark.exe',
                ]
                in_path = _shutil.which('tshark')
                if in_path:
                    candidates.insert(0, in_path)
                found = next((c for c in candidates if Path(c).exists()), None)
                def _upd():
                    if found:
                        tsh_entry.delete(0, 'end')
                        tsh_entry.insert(0, found)
                        tsh_status.set(f'✓  Found: {found}')
                    else:
                        tsh_status.set('✗  Not found — install Wireshark from wireshark.org')
                win.after(0, _upd)
            threading.Thread(target=_w, daemon=True).start()

        tk.Button(bf2, text='Browse…', bg=ENT, fg=ACC, relief='flat',
                  font=('Consolas', 8), cursor='hand2',
                  command=_browse_tsh).pack(side='left', padx=(0, 3))
        tk.Button(bf2, text='Test', bg=ENT, fg='#38f0a8', relief='flat',
                  font=('Consolas', 8), cursor='hand2',
                  command=_test_tsh).pack(side='left')

        lbl(tf, f'Default: {_DEFAULT_TSHARK_PATH}', fg='#2a4a6a').grid(
            row=1, column=1, sticky='w', padx=(0, 4))
        tk.Label(tf, textvariable=tsh_status, fg='#38f0a8', bg=BG2,
                 font=('Consolas', 8)).grid(row=2, column=1, sticky='w',
                                            padx=(0, 4), pady=(0, 4))
        tk.Button(tf, text='⊙  Auto-detect', bg=ENT, fg=WARN, relief='flat',
                  font=('Consolas', 8), cursor='hand2',
                  command=_auto_detect).grid(row=3, column=1, sticky='w',
                                             padx=(0, 4), pady=(0, 8))

        # ── Save / Cancel ─────────────────────────────────────────────────────
        tk.Frame(win, bg='#1a3050', height=1).pack(fill='x', padx=12, pady=(10, 0))

        def _save():
            self.config['speedtest_path'] = st_entry.get().strip()
            self.config['tshark_path']    = tsh_entry.get().strip()
            self._save_config()
            win.destroy()
            if on_saved:
                on_saved()

        btn_fr = tk.Frame(win, bg=BG2)
        btn_fr.pack(pady=(4, 14), padx=14)
        tk.Button(btn_fr, text='  Save  ', bg='#062040', fg=ACC, relief='flat',
                  font=('Consolas', 10, 'bold'), cursor='hand2',
                  command=_save).pack(side='left', padx=8)
        tk.Button(btn_fr, text='  Cancel  ', bg='#1a1a2a', fg='#8899aa', relief='flat',
                  font=('Consolas', 10), cursor='hand2',
                  command=win.destroy).pack(side='left', padx=8)

        if not tsh_entry.get():
            win.after(100, _auto_detect)
    # ── Graph ─────────────────────────────────────────────────────────────────
    def create_graph(self):
        plt.style.use('dark_background')
        self._fig = fig = plt.figure(figsize=(20, 14))
        fig.patch.set_facecolor(BG)
        fig.canvas.manager.set_window_title('Network Monitor')

        DIAL_TOP  = 0.970; DIAL_BOT  = 0.620
        CHART_TOP = 0.598; CHART_BOT = 0.055
        L, R      = 0.030, 0.975

        draw_metal_bg(fig, DIAL_BOT, CHART_TOP, CHART_BOT)

        dial_gs = gridspec.GridSpec(1, 5, left=L, right=R, top=DIAL_TOP, bottom=DIAL_BOT, wspace=0.06)
        ax_dl   = fig.add_subplot(dial_gs[0, 0])
        ax_ul   = fig.add_subplot(dial_gs[0, 1])
        ax_ping = fig.add_subplot(dial_gs[0, 2])
        ax_dns  = fig.add_subplot(dial_gs[0, 3])
        ax_view = fig.add_subplot(dial_gs[0, 4])

        chart_gs = gridspec.GridSpec(2, 3, left=L, right=R, top=CHART_TOP, bottom=CHART_BOT, hspace=0.48, wspace=0.30)
        ax1 = fig.add_subplot(chart_gs[0, 0]); ax2 = fig.add_subplot(chart_gs[0, 1])
        ax3 = fig.add_subplot(chart_gs[0, 2]); ax4 = fig.add_subplot(chart_gs[1, 0])
        ax5 = fig.add_subplot(chart_gs[1, 1]); ax6 = fig.add_subplot(chart_gs[1, 2])

        fig.add_artist(plt.Line2D([L, R], [CHART_TOP+0.004, CHART_TOP+0.004],
                                  transform=fig.transFigure, color=SPIN_COL, linewidth=0.8))

        # ── Button bar ────────────────────────────────────────────────────────
        RUN_W=0.130; DNS_W=0.130; BTN_H=0.022; GAP=0.008
        total_btn_w = RUN_W + GAP + DNS_W
        btn_left = 0.5 - total_btn_w / 2

        run_ax = fig.add_axes([btn_left, DIAL_BOT+0.004, RUN_W, BTN_H])
        run_btn = mwidgets.Button(run_ax, '  ▶  RUN SPEED TEST NOW  ', color='#062040', hovercolor='#0a3a60')
        run_btn.label.set_color('#38b8f0'); run_btn.label.set_fontsize(8); run_btn.label.set_fontweight('bold')

        status_ax = fig.add_axes([btn_left-0.19, DIAL_BOT+0.004, 0.18, BTN_H]); status_ax.axis('off')
        _status_txt = [status_ax.text(1.0, 0.5, '', color=TICK_COL, fontsize=7.5,
                                      va='center', ha='right', fontfamily='monospace',
                                      transform=status_ax.transAxes)]

        dns_btn_left = btn_left + RUN_W + GAP
        dns_ax = fig.add_axes([dns_btn_left, DIAL_BOT+0.004, DNS_W, BTN_H])
        dns_btn = mwidgets.Button(dns_ax, '  ⊙  MONITOR DNS  ', color='#1a0e04', hovercolor='#3a2008')
        dns_btn.label.set_color(DNS_COL); dns_btn.label.set_fontsize(8); dns_btn.label.set_fontweight('bold')

        dns_status_ax = fig.add_axes([dns_btn_left+DNS_W+GAP, DIAL_BOT+0.004, 0.15, BTN_H])
        dns_status_ax.axis('off')
        _dns_status_txt = [dns_status_ax.text(0.0, 0.5, '', color=DNS_COL, fontsize=7.5,
                                               va='center', ha='left', fontfamily='monospace',
                                               transform=dns_status_ax.transAxes)]
        RUN_H = BTN_H

        def _run_now(event):
            if getattr(self, '_running_manual', False): return
            self._running_manual = True
            run_btn.label.set_text('  ◌  RUNNING…  '); run_btn.ax.set_facecolor('#041828')
            run_btn.label.set_color('#5ab4e0'); _status_txt[0].set_text('Testing…')
            fig.canvas.draw_idle()
            def _worker():
                self.run_speedtest(); self._running_manual = False
                run_btn.label.set_text('  ▶  RUN SPEED TEST NOW  '); run_btn.ax.set_facecolor('#062040')
                run_btn.label.set_color('#38b8f0')
                last = self.data['download']
                val  = f"✓  {last[-1]:.1f} Mbps" if last else "✓  Done"
                _status_txt[0].set_text(val); _status_txt[0].set_color('#2ea043')
                do_update(None)
            threading.Thread(target=_worker, daemon=True).start()
        run_btn.on_clicked(_run_now)

        def _monitor_dns_now(event):
            if getattr(self, '_running_dns', False): return
            self._running_dns = True
            dns_btn.label.set_text('  ◌  CHECKING…  '); dns_btn.ax.set_facecolor('#100800')
            _dns_status_txt[0].set_text('Resolving…'); fig.canvas.draw_idle()
            def _dns_worker():
                avg = self.run_dns_check(); self._running_dns = False
                dns_btn.label.set_text('  ⊙  MONITOR DNS  '); dns_btn.ax.set_facecolor('#1a0e04')
                if avg is not None:
                    _dns_status_txt[0].set_text(f'✓  {avg:.1f} ms')
                    self._d_dns = avg
                    draw_gauge(ax_dns, self._d_dns, max(200.0, avg*2), DNS_COL, "DNS ⊙", is_ping=True)
                    _draw_dns_chart(ax5)
                else:
                    _dns_status_txt[0].set_text('✗  no response')
                fig.canvas.draw_idle()
            threading.Thread(target=_dns_worker, daemon=True).start()
        dns_btn.on_clicked(_monitor_dns_now)

        # ── Wireshark button ──────────────────────────────────────────────────
        WIRE_W = 0.110
        wire_ax = fig.add_axes([dns_btn_left+DNS_W+GAP, DIAL_BOT+0.004, WIRE_W, BTN_H])
        wire_btn = mwidgets.Button(wire_ax, '  [WS]  WIRESHARK  ', color='#0a1a0e', hovercolor='#142a1a')
        wire_btn.label.set_color('#39ff14'); wire_btn.label.set_fontsize(8); wire_btn.label.set_fontweight('bold')
        _ws_instances = []
        def _open_wireshark(event):
            # CHANGE: pass tshark path from settings
            ws = WiresharkWindow(tshark_path=self._tshark_exe)
            _ws_instances.append(ws)
        wire_btn.on_clicked(_open_wireshark)

        # ── EtherApe button ───────────────────────────────────────────────────
        EA_W = 0.110
        ea_ax = fig.add_axes([dns_btn_left+DNS_W+GAP+WIRE_W+GAP, DIAL_BOT+0.004, EA_W, BTN_H])
        ea_btn = mwidgets.Button(ea_ax, '  ◎  ETHERAPE  ', color='#0d0a1e', hovercolor='#1e1440')
        ea_btn.label.set_color('#a371f7'); ea_btn.label.set_fontsize(8); ea_btn.label.set_fontweight('bold')
        _ea_instances = []
        def _open_etherape(event):
            # CHANGE: pass tshark path from settings
            ea = EtherApeWindow(tshark_path=self._tshark_exe)
            _ea_instances.append(ea)
        ea_btn.on_clicked(_open_etherape)

        # ── Settings button (NEW) ─────────────────────────────────────────────
        SET_W = 0.085
        set_ax = fig.add_axes([dns_btn_left+DNS_W+GAP+WIRE_W+GAP+EA_W+GAP, DIAL_BOT+0.004, SET_W, BTN_H])
        set_btn = mwidgets.Button(set_ax, '  ⚙  SETTINGS  ', color='#0d1828', hovercolor='#162438')
        set_btn.label.set_color('#6a9ab8'); set_btn.label.set_fontsize(8); set_btn.label.set_fontweight('bold')
        def _open_settings(event):
            self._open_settings_dialog(on_saved=lambda: do_update(None))
        set_btn.on_clicked(_open_settings)

        # ── Agents button ──────────────────────────────────────────────────
        AGT_W = 0.090
        agt_ax = fig.add_axes([
            dns_btn_left + DNS_W + GAP + WIRE_W + GAP + EA_W + GAP + SET_W + GAP,
            DIAL_BOT + 0.004, AGT_W, BTN_H])
        agt_btn = mwidgets.Button(
            agt_ax, '  ⊞  AGENTS  ',
            color='#0d1a0d', hovercolor='#162816'
        )
        agt_btn.label.set_color('#39ff14')
        agt_btn.label.set_fontsize(8)
        agt_btn.label.set_fontweight('bold')
        _agt_instances = []
        def _open_agents(event):
            aw = AgentsWindow(self)
            _agt_instances.append(aw)
        agt_btn.on_clicked(_open_agents)

        # ── Export button ─────────────────────────────────────────────────────
        EXP_W=0.110; EXP_H=RUN_H
        exp_ax = fig.add_axes([btn_left-EXP_W-GAP, DIAL_BOT+0.004, EXP_W, EXP_H])
        exp_btn = mwidgets.Button(exp_ax, '  ⬇  EXPORT DATA  ', color='#06201a', hovercolor='#0a3a28')
        exp_btn.label.set_color('#38f0a8'); exp_btn.label.set_fontsize(8); exp_btn.label.set_fontweight('bold')

        exp_status_ax = fig.add_axes([btn_left-EXP_W-GAP-0.17, DIAL_BOT+0.004, 0.16, EXP_H])
        exp_status_ax.axis('off')
        _exp_status_txt = [exp_status_ax.text(1.0, 0.5, '', color=TICK_COL, fontsize=7,
                                               va='center', ha='right', fontfamily='monospace',
                                               transform=exp_status_ax.transAxes)]

        def _open_export_dialog(event):
            import tkinter as tk
            from tkinter import ttk, messagebox, filedialog

            root = tk.Tk()
            root.title('Export Speed Data')
            root.configure(bg='#0a1828')
            root.resizable(False, False)

            FG, BG2, ENT = '#c8dff0', '#0a1828', '#0d2235'
            ACCENT = '#38f0a8'

            def lbl(parent, text, **kw):
                return tk.Label(parent, text=text, fg=FG, bg=BG2, font=('Consolas', 9), **kw)

            def entry(parent, width=14):
                e = tk.Entry(parent, width=width, bg=ENT, fg=FG, insertbackground=FG,
                             relief='flat', font=('Consolas', 9), highlightthickness=1,
                             highlightcolor=ACCENT, highlightbackground='#1a3050')
                return e

            self.data = self._load_data()
            if self.data['timestamps']:
                t_min = datetime.fromisoformat(min(self.data['timestamps']))
                t_max = datetime.fromisoformat(max(self.data['timestamps']))
            else:
                t_min = t_max = datetime.now()

            DATE_FMT = '%Y-%m-%d'; TIME_FMT = '%H:%M:%S'

            tk.Label(root, text='⬇  Export Speed Data', fg=ACCENT, bg=BG2,
                     font=('Consolas', 11, 'bold')).grid(row=0, column=0, columnspan=3, pady=(14,6), padx=16)
            tk.Frame(root, bg='#1a3050', height=1).grid(row=1, column=0, columnspan=3, sticky='ew', padx=14, pady=(0,8))

            lbl(root, 'From date (YYYY-MM-DD)').grid(row=2, column=0, sticky='w', padx=14, pady=3)
            e_from_d = entry(root); e_from_d.insert(0, t_min.strftime(DATE_FMT)); e_from_d.grid(row=2, column=1, padx=6, pady=3)
            lbl(root, 'time (HH:MM:SS)').grid(row=2, column=2, sticky='w', padx=(0,14), pady=3)
            e_from_t = entry(root, width=10); e_from_t.insert(0, '00:00:00'); e_from_t.grid(row=2, column=3, padx=(0,14), pady=3)

            lbl(root, 'To date   (YYYY-MM-DD)').grid(row=3, column=0, sticky='w', padx=14, pady=3)
            e_to_d = entry(root); e_to_d.insert(0, t_max.strftime(DATE_FMT)); e_to_d.grid(row=3, column=1, padx=6, pady=3)
            lbl(root, 'time (HH:MM:SS)').grid(row=3, column=2, sticky='w', padx=(0,14), pady=3)
            e_to_t = entry(root, width=10); e_to_t.insert(0, t_max.strftime(TIME_FMT)); e_to_t.grid(row=3, column=3, padx=(0,14), pady=3)

            sc_frame = tk.Frame(root, bg=BG2)
            sc_frame.grid(row=4, column=0, columnspan=4, padx=14, pady=(6,2), sticky='w')
            lbl(sc_frame, 'Quick range:').pack(side='left', padx=(0,6))
            now = datetime.now()
            def _set_range(days_back):
                start = (now - timedelta(days=days_back)).replace(hour=0, minute=0, second=0, microsecond=0)
                e_from_d.delete(0,'end'); e_from_d.insert(0, start.strftime(DATE_FMT))
                e_from_t.delete(0,'end'); e_from_t.insert(0,'00:00:00')
                e_to_d.delete(0,'end');   e_to_d.insert(0, now.strftime(DATE_FMT))
                e_to_t.delete(0,'end');   e_to_t.insert(0, now.strftime(TIME_FMT))
            for lbl_txt, days in [('Today',0),('7 days',6),('30 days',29),('All',36500)]:
                tk.Button(sc_frame, text=lbl_txt, bg='#0d2235', fg=ACCENT, relief='flat',
                          font=('Consolas',8), cursor='hand2',
                          command=lambda d=days: _set_range(d)).pack(side='left', padx=3)

            fmt_frame = tk.Frame(root, bg=BG2)
            fmt_frame.grid(row=5, column=0, columnspan=4, padx=14, pady=(8,4), sticky='w')
            lbl(fmt_frame, 'Format:').pack(side='left', padx=(0,8))
            fmt_var = tk.StringVar(value='csv')
            for fmt_lbl, fmt_val in [('CSV (.csv)','csv'),('JSON (.json)','json')]:
                tk.Radiobutton(fmt_frame, text=fmt_lbl, variable=fmt_var, value=fmt_val,
                               fg=FG, bg=BG2, selectcolor='#0d2235',
                               activebackground=BG2, activeforeground=ACCENT,
                               font=('Consolas',9)).pack(side='left', padx=5)

            path_frame = tk.Frame(root, bg=BG2)
            path_frame.grid(row=6, column=0, columnspan=4, padx=14, pady=(4,8), sticky='ew')
            lbl(path_frame, 'Save to:').pack(side='left', padx=(0,6))
            default_dir = str(Path(DATA_FILE).parent)
            path_entry = entry(path_frame, width=32); path_entry.insert(0, default_dir)
            path_entry.pack(side='left', padx=(0,4))
            def _browse():
                d = filedialog.askdirectory(initialdir=path_entry.get(), title='Choose export folder')
                if d: path_entry.delete(0,'end'); path_entry.insert(0, d)
            tk.Button(path_frame, text='Browse...', bg='#0d2235', fg=ACCENT, relief='flat',
                      font=('Consolas',8), cursor='hand2', command=_browse).pack(side='left')

            err_var = tk.StringVar()
            tk.Label(root, textvariable=err_var, fg='#ff6b6b', bg=BG2,
                     font=('Consolas',8)).grid(row=7, column=0, columnspan=4, padx=14)

            btn_frame = tk.Frame(root, bg=BG2)
            btn_frame.grid(row=8, column=0, columnspan=4, pady=(4,14), padx=14)
            result = [None]

            def _do_export():
                err_var.set('')
                try:
                    start_dt = datetime.strptime(e_from_d.get().strip()+' '+e_from_t.get().strip(), '%Y-%m-%d %H:%M:%S')
                    end_dt   = datetime.strptime(e_to_d.get().strip()+' '+e_to_t.get().strip(), '%Y-%m-%d %H:%M:%S')
                except ValueError:
                    err_var.set('Invalid date/time – use YYYY-MM-DD and HH:MM:SS'); return
                if end_dt < start_dt:
                    err_var.set('"To" must be after "From"'); return
                save_dir = path_entry.get().strip() or str(Path(DATA_FILE).parent)
                try:
                    filepath, n = self._export_to(start_dt, end_dt, fmt_var.get(), Path(save_dir))
                    result[0] = (filepath, n); root.destroy()
                except Exception as ex:
                    err_var.set(f'Export failed: {ex}')

            tk.Button(btn_frame, text='  Export  ', bg='#062a1a', fg=ACCENT, relief='flat',
                      font=('Consolas',10,'bold'), cursor='hand2', command=_do_export).pack(side='left', padx=8)
            tk.Button(btn_frame, text='  Cancel  ', bg='#1a1a2a', fg='#8899aa', relief='flat',
                      font=('Consolas',10), cursor='hand2', command=root.destroy).pack(side='left', padx=8)
            root.mainloop()
            if result[0]:
                filepath, n = result[0]; short = Path(filepath).name
                _exp_status_txt[0].set_text(f'✓ {n} rows → {short}')
                _exp_status_txt[0].set_color('#38f0a8')
            else:
                _exp_status_txt[0].set_text('')
            fig.canvas.draw_idle()
        exp_btn.on_clicked(_open_export_dialog)

        import tkinter as tk
        from tkinter import colorchooser as tkcc

        SW=0.018; SH=0.042; SX=0.979
        dial_mid=(DIAL_TOP+DIAL_BOT)/2
        swatch_defs=[("dl","↓ Download"),("ul","↑ Upload"),("ping","○ Ping")]
        swatch_axes={}; swatch_buttons={}
        total_h=3*SH+2*0.006; sy_top=dial_mid+total_h/2

        for idx,(key,label) in enumerate(swatch_defs):
            sy=sy_top-idx*(SH+0.006)-SH
            sax=fig.add_axes([SX,sy,SW,SH])
            col_key={"dl":"download","ul":"upload","ping":"ping"}[key]
            cur_col=self.colors[col_key]
            sbtn=mwidgets.Button(sax,'●',color=cur_col,hovercolor=cur_col+'cc')
            sbtn.label.set_color('white'); sbtn.label.set_fontsize(11)
            swatch_axes[key]=sax; swatch_buttons[key]=sbtn

        clbl_ax=fig.add_axes([SX,sy_top+0.004,SW,0.016]); clbl_ax.axis('off')
        clbl_ax.text(0.5,0.5,'CLR',color=TICK_COL,fontsize=6,ha='center',va='center',
                     transform=clbl_ax.transAxes,fontweight='bold')

        def _refresh_swatch_btns():
            for key,sbtn in swatch_buttons.items():
                col_key={"dl":"download","ul":"upload","ping":"ping"}[key]
                sbtn.ax.set_facecolor(self.colors[col_key])
            fig.canvas.draw_idle()

        def _open_picker(col_key, event):
            cur_hex=self.colors[col_key]
            root2=tk.Tk(); root2.withdraw()
            result=tkcc.askcolor(color=cur_hex,title=f'Pick colour – {col_key.capitalize()}',parent=root2)
            root2.destroy()
            if result and result[1]:
                cur_custom=dict(self.colors); cur_custom[col_key]=result[1]
                self.config["custom"]=cur_custom; self.config["theme"]=None
                self._save_config(); _refresh_swatch_btns(); do_update(None)

        swatch_buttons["dl"].on_clicked(lambda e: _open_picker("download", e))
        swatch_buttons["ul"].on_clicked(lambda e: _open_picker("upload", e))
        swatch_buttons["ping"].on_clicked(lambda e: _open_picker("ping", e))

        _seg_ranges=[None]

        def _on_click(event):
            if event.inaxes is not ax_view: return
            x,y=event.xdata,event.ydata
            if x is None or y is None: return
            ang_deg=np.degrees(np.arctan2(y,x))
            ANG_START=225.0; SWEEP=270.0
            raw=(ANG_START-ang_deg)%360; frac=raw/SWEEP
            if not (0.0<=frac<=1.0): return
            if _seg_ranges[0] is None: return
            for f0,f1,vkey in _seg_ranges[0]:
                if f0<=frac<f1:
                    self.current_view=vkey; do_update(None); return
        fig.canvas.mpl_connect('button_press_event', _on_click)

        _max={'dl':200.0,'ul':100.0,'ping':150.0,'dns':200.0}

        def _draw_dns_chart(ax):
            ax.clear(); self._style(ax)
            if len(self._dns_history)<2:
                ax.text(0.5,0.5,'No DNS data yet\nClick  \u2299 MONITOR DNS  to start',
                        transform=ax.transAxes,ha='center',va='center',
                        color=TICK_COL,fontsize=9,fontfamily='monospace',linespacing=1.8)
                self._titl(ax,'ms','DNS Resolution History'); return
            times=[datetime.fromisoformat(ts) for ts,_ in self._dns_history]
            vals=[v for _,v in self._dns_history]
            if len(times)<=60: self._neon_line(ax,times,vals,DNS_COL,marker=True)
            else: self._neon_line(ax,times,vals,DNS_COL,marker=False)
            ax.xaxis.set_major_formatter(DateFormatter('%H:%M'))
            plt.setp(ax.get_xticklabels(),rotation=30,ha='right',color=TICK_COL,fontsize=7)
            ax.tick_params(axis='y',colors=TICK_COL,labelsize=7)
            ax.annotate(f'{vals[-1]:.1f} ms',xy=(times[-1],vals[-1]),
                        xytext=(8,4),textcoords='offset points',
                        color=DNS_COL,fontsize=7.5,fontweight='bold',fontfamily='monospace')
            for ref_ms,label,alpha in [(20,'20 ms',0.4),(100,'100 ms',0.3)]:
                ax.axhline(ref_ms,color=DNS_COL,lw=0.7,alpha=alpha,ls='--')
                ax.text(times[0],ref_ms+1,label,color=DNS_COL,fontsize=6.5,
                        alpha=alpha+0.1,fontfamily='monospace')
            self._titl(ax,'ms',f'DNS Resolution History  ({len(vals)} samples)')

        def do_update(_frame):
            self.data=self._load_data()
            c=self.colors; dl_c,ul_c,pg_c=c["download"],c["upload"],c["ping"]
            all_times=[datetime.fromisoformat(ts) for ts in self.data['timestamps']]
            all_dl=self.data['download']; all_ul=self.data['upload']; all_ping=self.data['ping']
            last=lambda lst:(lst[-1] or 0.0) if lst else 0.0
            tgt_dl,tgt_ul,tgt_pg=last(all_dl),last(all_ul),last(all_ping)
            if all_dl:   _max['dl']   = max(200.0, max(x for x in all_dl   if x)*1.3)
            if all_ul:   _max['ul']   = max(100.0, max(x for x in all_ul   if x)*1.3)
            if all_ping: _max['ping'] = max(150.0, max(x for x in all_ping if x)*1.3)
            self._d_dl,self._d_ul,self._d_ping=tgt_dl,tgt_ul,tgt_pg
            draw_gauge(ax_dl,   self._d_dl,   _max['dl'],   dl_c, "Download ↓")
            draw_gauge(ax_ul,   self._d_ul,   _max['ul'],   ul_c, "Upload ↑")
            draw_gauge(ax_ping, self._d_ping, _max['ping'], pg_c, "Ping ○", is_ping=True)
            draw_gauge(ax_dns,  self._d_dns,  _max['dns'],  DNS_COL, "DNS ⊙", is_ping=True)
            _seg_ranges[0]=draw_view_dial(ax_view,self.current_view)

            now=datetime.now()
            today_s=now.replace(hour=0,minute=0,second=0,microsecond=0)
            week_s=today_s-timedelta(days=now.weekday())
            month_s=now.replace(day=1,hour=0,minute=0,second=0,microsecond=0)
            view=self.current_view
            if view=="Today":      ws,we=today_s,now+timedelta(hours=1)
            elif view=="This Week": ws,we=week_s, now+timedelta(hours=1)
            elif view=="This Month": ws,we=month_s,now+timedelta(hours=1)
            elif view=="All Time":  ws,we=datetime(2000,1,1),now+timedelta(hours=1)
            else:
                ws=today_s-timedelta(days=self.history_offset); we=ws+timedelta(days=1)

            ii_w=[i for i,t in enumerate(all_times) if ws<=t<we]
            wt=[all_times[i] for i in ii_w]; w_dl=[all_dl[i] for i in ii_w]
            w_ul=[all_ul[i] for i in ii_w]; w_ping=[all_ping[i] for i in ii_w]
            suffix=(f" ({ws.strftime('%b %d')})" if view=="History" else "")

            def bar_or_line(ax,vals,col,ylabel,title):
                ax.clear(); self._style(ax)
                clean=[v if v is not None else 0 for v in vals]
                if wt:
                    if view in ("Today","History"):
                        xs=[t.hour+t.minute/60 for t in wt]
                        self._neon_bar(ax,xs,clean,0.22,col)
                        ax.set_xlim(0,24); ax.set_xticks(range(0,25,4))
                        ax.set_xticklabels([f"{h:02d}:00" for h in range(0,25,4)],
                                           fontsize=7,color=TICK_COL)
                    else:
                        self._neon_line(ax,wt,clean,col)
                        ax.xaxis.set_major_formatter(DateFormatter('%m/%d'))
                        plt.setp(ax.get_xticklabels(),rotation=30,ha='right',color=TICK_COL,fontsize=7)
                ax.tick_params(axis='y',colors=TICK_COL,labelsize=7)
                self._titl(ax,ylabel,f"{title} – {view}{suffix}")

            bar_or_line(ax1,w_dl,dl_c,'Mbps','Download')
            bar_or_line(ax2,w_ul,ul_c,'Mbps','Upload')
            bar_or_line(ax3,w_ping,pg_c,'ms','Latency')

            ax4.clear(); self._style(ax4)
            d_dl,d_ul,d_lab=[],[],[]
            for d in range(13,-1,-1):
                day=today_s-timedelta(days=d)
                ii=[i for i,t in enumerate(all_times) if day<=t<day+timedelta(days=1)]
                if ii:
                    d_dl.append(np.mean([all_dl[i]  for i in ii if all_dl[i]  is not None]))
                    d_ul.append(np.mean([all_ul[i]  for i in ii if all_ul[i]  is not None]))
                    d_lab.append(day.strftime('%m/%d'))
            if d_dl:
                x=np.arange(len(d_dl))
                self._neon_bar(ax4,x-0.20,d_dl,0.35,dl_c)
                self._neon_bar(ax4,x+0.20,d_ul,0.35,ul_c)
                ax4.set_xticks(x)
                ax4.set_xticklabels(d_lab,fontsize=7,color=TICK_COL,rotation=40,ha='right')
                for col,lbl in [(dl_c,'DL'),(ul_c,'UL')]:
                    ax4.plot([],[],'o',color=col,ms=5,label=lbl)
                ax4.legend(frameon=False,fontsize=8,labelcolor=TEXT_COL,loc='upper right')
            ax4.tick_params(axis='y',colors=TICK_COL,labelsize=7)
            self._titl(ax4,'Mbps','Daily Averages (14 days)')

            _draw_dns_chart(ax5)

            ax6.clear(); ax6.set_facecolor(PANEL_BG)
            ax6.set_xticks([]); ax6.set_yticks([])
            for sp in ax6.spines.values(): sp.set_color(SPIN_COL); sp.set_linewidth(0.6)

            def _s(v):
                v=[x for x in v if x is not None]
                if not v: return "—","—","—","—"
                return (f"{np.mean(v):.1f}",f"{max(v):.1f}",f"{min(v):.1f}",f"{np.std(v):.1f}")

            def _jitter(pings):
                p=[x for x in pings if x is not None]
                if len(p)<2: return "—"
                diffs=[abs(p[i+1]-p[i]) for i in range(len(p)-1)]
                return f"{np.mean(diffs):.1f} ms"

            hdrs=["Metric","Avg","Max","Min","σ","Jitter"]
            col_x=[0.04,0.22,0.38,0.54,0.69,0.83]
            for ci,h in enumerate(hdrs):
                ax6.text(col_x[ci],0.91,h,transform=ax6.transAxes,color=TICK_COL,
                         fontsize=7.5,fontweight='bold',va='top',fontfamily='monospace')
            ax6.plot([0.02,0.98],[0.87,0.87],color='#0d2235',lw=1.5,
                     transform=ax6.transAxes,zorder=2,clip_on=False)

            dns_vals=[v for _,v in self._dns_history]
            data_rows=[
                ("↓ Download",dl_c,  *_s(w_dl),   "—"),
                ("↑ Upload",  ul_c,  *_s(w_ul),   "—"),
                ("○ Ping",    pg_c,  *_s(w_ping), _jitter(w_ping)),
                ("⊙ DNS",     DNS_COL,*_s(dns_vals),_jitter(dns_vals)),
            ]
            for ri,(metric,rc,avg,mx,mn,sd,jit) in enumerate(data_rows):
                y=0.76-ri*0.16
                cells=[metric,avg,mx,mn,sd,jit]
                for ci,cell in enumerate(cells):
                    is_j=(ci==5 and jit!="—")
                    ax6.text(col_x[ci],y,cell,transform=ax6.transAxes,
                             color=(rc if ci==0 else (rc if is_j else TEXT_COL)),
                             fontsize=8,fontweight='bold' if (ci==0 or is_j) else 'normal',
                             va='top',fontfamily='monospace')
                ax6.plot([0.02,0.98],[y-0.038,y-0.038],color='#080f18',lw=0.8,
                         transform=ax6.transAxes,zorder=1,clip_on=False)

            ax6.text(0.04,0.10,f"Tests in window: {len(w_dl)}   |   Total recorded: {len(all_times)}",
                     transform=ax6.transAxes,color=TICK_COL,fontsize=7.5,fontfamily='monospace')
            last_ts=(datetime.fromisoformat(self.data['timestamps'][-1]).strftime('%H:%M  %d %b %Y')
                     if all_times else '—')
            ax6.text(0.04,0.03,f"Last test:  {last_ts}",transform=ax6.transAxes,
                     color=TICK_COL,fontsize=7.5,fontfamily='monospace')

            # Show configured path status
            st_ok  = '✓' if Path(self._speedtest_exe).exists()  else '✗'
            tsh_ok = '✓' if Path(self._tshark_exe).exists() else '✗'
            path_color = '#2ea043' if st_ok=='✓' and tsh_ok=='✓' else '#ff6b6b'
            ax6.text(0.04,-0.07,
                     f"speedtest: {st_ok} {Path(self._speedtest_exe).name}   "
                     f"tshark: {tsh_ok} {Path(self._tshark_exe).name}",
                     transform=ax6.transAxes,color=path_color,fontsize=6.5,
                     fontfamily='monospace',clip_on=False)

            self._titl(ax6,'',f'Statistics – {view}{suffix}')
            fig.canvas.draw_idle()

        _tick=[0]; _max_s=[200.0,100.0,150.0,200.0]

        def on_tick(frame):
            try:
                _tick[0]+=1
                if _tick[0]%20==0: do_update(frame); return
                self.data=self._load_data(); c=self.colors
                last=lambda lst:(lst[-1] or 0.0) if lst else 0.0
                tgt_dl=last(self.data['download']); tgt_ul=last(self.data['upload'])
                tgt_ping=last(self.data['ping'])
                tgt_dns=self._dns_history[-1][1] if self._dns_history else 0.0
                if self.data['download']: _max_s[0]=max(200.0,max(x for x in self.data['download'] if x)*1.3)
                if self.data['upload']:   _max_s[1]=max(100.0,max(x for x in self.data['upload']   if x)*1.3)
                if self.data['ping']:     _max_s[2]=max(150.0,max(x for x in self.data['ping']     if x)*1.3)
                if self._dns_history:     _max_s[3]=max(200.0,max(v for _,v in self._dns_history)*1.3)
                ease=0.20
                self._d_dl   +=(tgt_dl   -self._d_dl)  *ease
                self._d_ul   +=(tgt_ul   -self._d_ul)  *ease
                self._d_ping +=(tgt_ping -self._d_ping)*ease
                self._d_dns  +=(tgt_dns  -self._d_dns) *ease
                draw_gauge(ax_dl,   self._d_dl,   _max_s[0],c["download"],"Download ↓")
                draw_gauge(ax_ul,   self._d_ul,   _max_s[1],c["upload"],  "Upload ↑")
                draw_gauge(ax_ping, self._d_ping, _max_s[2],c["ping"],    "Ping ○",is_ping=True)
                draw_gauge(ax_dns,  self._d_dns,  _max_s[3],DNS_COL,      "DNS ⊙",is_ping=True)
                _seg_ranges[0]=draw_view_dial(ax_view,self.current_view)
                fig.canvas.draw_idle()
            except Exception:
                pass

        _anim=FuncAnimation(fig,on_tick,interval=1000,cache_frame_data=False)
        do_update(None)
        plt.show()

    def run_continuous(self):
        while True:
            self.run_speedtest()
            time.sleep(INTERVAL_MINUTES * 60)



# ─────────────────────────────────────────────────────────────────────────────
#  EtherApe Monitor
# ─────────────────────────────────────────────────────────────────────────────
class EtherApeWindow:
    MAX_NODES = 60; MAX_FLOWS = 150; DECAY = 0.92; RENDER_MS = 200; TABLE_MS = 2000
    _BG='#050d1a'; _PANEL='#06101e'; _ACC='#38b8f0'; _TEXT='#c8dff0'; _TICK='#6a9ab8'; _SPIN='#0a1828'

    PROTO_COLORS = {
        'http':'#39ff14','http2':'#39ff14','tls':'#6bcb77','ssl':'#6bcb77',
        'dns':'#ff9f43','mdns':'#ff9f43','dhcp':'#ffd93d','dhcpv6':'#ffd93d',
        'icmp':'#ff6b6b','icmpv6':'#ff9999','tcp':'#00d4aa','udp':'#a371f7',
        'arp':'#74c7ec','other':'#c8dff0',
    }
    PROTO_PRIORITY = ['http2','http','tls','ssl','dns','mdns','dhcp','dhcpv6','icmpv6','icmp','tcp','udp','arp']

    def __init__(self, tshark_path=None):
        import tkinter as tk
        from tkinter import ttk
        from matplotlib.collections import LineCollection
        self._tk=tk; self._ttk=ttk
        # CHANGE: accept tshark_path from Settings
        self.TSHARK = tshark_path if tshark_path else _DEFAULT_TSHARK_PATH

        self.root=tk.Toplevel()
        self.root.title('EtherApe — Network Topology Monitor')
        self.root.configure(bg=self._BG)
        self.root.geometry('1440x940'); self.root.minsize(900,600)
        self.root.protocol('WM_DELETE_WINDOW',self._on_close)

        self._cap_proc=None; self._capturing=False; self._interfaces=[]
        self._closed=False; self._pkt_queue=[]
        self._nodes={}; self._flows={}
        self._filter_proto='ALL'; self._show_labels=True; self._show_legend=True
        self._resolve_names=False; self._dns_cache={}
        self._total_bytes=0; self._total_pkts=0; self._tick=0; self._pulse_t=0.0
        self._label_fontsize=9; self._label_fontfamily='Consolas'
        self._flow_seg_map=[]
        self._replaying=False; self._replay_thread=None; self._replay_speed=1.0
        self._zoom=1.0; self._pan_x=0.5; self._pan_y=0.5
        self._pan_dragging=False; self._pan_last=(0.0,0.0)

        self._build_style(); self._build_ui(); self._load_interfaces()
        self.root.update_idletasks(); self.root.lift(); self.root.focus_force()
        self._schedule_render(); self._schedule_table_update()

    def _on_close(self):
        self._closed=True; self._stop_capture(); self._stop_replay(); self.root.destroy()

    def _build_style(self):
        s=self._ttk.Style(self.root); s.theme_use('clam')
        s.configure('EA.Treeview',background=self._PANEL,fieldbackground=self._PANEL,
                    foreground=self._TEXT,font=('Consolas',9),rowheight=19,borderwidth=0)
        s.configure('EA.Treeview.Heading',background='#040c1a',foreground=self._TICK,
                    font=('Consolas',9,'bold'),relief='flat')
        s.map('EA.Treeview',background=[('selected','#0a3060')],foreground=[('selected','white')])

    def _btn(self,parent,text,cmd,fg,bg,hover=None,**kw):
        return self._tk.Button(parent,text=text,command=cmd,bg=bg,fg=fg,
                               activebackground=hover or bg,activeforeground=fg,
                               font=('Consolas',9,'bold'),relief='flat',cursor='hand2',padx=8,pady=3,**kw)

    def _lbl(self,parent,text,fg=None,**kw):
        return self._tk.Label(parent,text=text,bg='#040c1a',fg=fg or self._TICK,font=('Consolas',9),**kw)

    def _apply_font(self):
        try: sz=int(self._font_size_var.get()); fam=self._font_family_var.get()
        except Exception: return
        sz=max(6,min(24,sz)); self._label_fontsize=sz; self._label_fontfamily=fam
        s=self._ttk.Style(self.root)
        s.configure('EA.Treeview',font=(fam,sz),rowheight=sz+10)
        s.configure('EA.Treeview.Heading',font=(fam,sz,'bold'))
        if hasattr(self,'_flow_detail'): self._flow_detail.config(font=(fam,sz))
        self._reconfigure_labels(self.root,fam,sz)

    def _reconfigure_labels(self,widget,fam,sz):
        try:
            wtype=widget.winfo_class()
            if wtype in ('Label','Button','Checkbutton','Radiobutton'):
                try:
                    cur=widget.cget('font')
                    if isinstance(cur,(list,tuple)) and len(cur)>=2:
                        bold='bold' if (len(cur)>=3 and 'bold' in str(cur[2])) else ''
                        widget.config(font=(fam,sz,bold) if bold else (fam,sz))
                except Exception: pass
            elif wtype in ('Entry','Spinbox','Text'):
                try: widget.config(font=(fam,sz))
                except Exception: pass
        except Exception: pass
        try:
            for child in widget.winfo_children(): self._reconfigure_labels(child,fam,sz)
        except Exception: pass

    def _build_ui(self):
        tk=self._tk; ttk=self._ttk; r=self.root
        hdr=tk.Frame(r,bg='#020810',height=46); hdr.pack(fill='x'); hdr.pack_propagate(False)
        tk.Label(hdr,text='◎  ETHERAPE MONITOR',bg='#020810',fg=self._ACC,
                 font=('Consolas',15,'bold')).pack(side='left',padx=16,pady=8)
        tk.Label(hdr,text='Live Network Topology & Traffic Flow',bg='#020810',fg=self._TICK,
                 font=('Consolas',9)).pack(side='left',pady=14)
        self._total_var=tk.StringVar(value='')
        tk.Label(hdr,textvariable=self._total_var,bg='#020810',fg=self._ACC,
                 font=('Consolas',9,'bold')).pack(side='right',padx=16)
        tk.Frame(r,bg=self._SPIN,height=1).pack(fill='x')

        tb1=tk.Frame(r,bg='#040c1a',pady=5); tb1.pack(fill='x',padx=4)
        self._lbl(tb1,'Interface:').pack(side='left',padx=(8,4))
        self._iface_var=tk.StringVar()
        self._iface_cb=ttk.Combobox(tb1,textvariable=self._iface_var,width=36,state='readonly',font=('Consolas',9))
        self._iface_cb.pack(side='left',padx=(0,8),ipady=2)
        self._start_btn=self._btn(tb1,'▶  Start',self._start_capture,'#38f0a8','#062a1a','#0a4028')
        self._start_btn.pack(side='left',padx=2)
        self._stop_btn=self._btn(tb1,'◼  Stop',self._stop_capture,'#ff6b6b','#200808','#3a1010')
        self._stop_btn.pack(side='left',padx=2); self._stop_btn.config(state='disabled')
        self._btn(tb1,'⊘  Clear',self._clear,'#a371f7','#100820','#1e1040').pack(side='left',padx=2)
        tk.Frame(tb1,bg=self._SPIN,width=1,height=26).pack(side='left',padx=8)
        self._btn(tb1,'📂  Open PCAP',self._open_pcap_replay,'#ffd93d','#1a1400','#2a2200').pack(side='left',padx=2)
        self._replay_btn=self._btn(tb1,'⏵  Replay',self._start_replay,'#ff9f43','#1a0e00','#2a1800')
        self._replay_btn.pack(side='left',padx=2); self._replay_btn.config(state='disabled')
        self._stop_replay_btn=self._btn(tb1,'⏹  Stop Replay',self._stop_replay,'#ff6b6b','#200808','#3a1010')
        self._stop_replay_btn.pack(side='left',padx=2); self._stop_replay_btn.config(state='disabled')
        self._lbl(tb1,'  Speed:').pack(side='left',padx=(6,2))
        self._speed_var=tk.DoubleVar(value=1.0)
        tk.Spinbox(tb1,values=(0.1,0.25,0.5,1.0,2.0,4.0,8.0,16.0,0),textvariable=self._speed_var,width=5,
                   bg='#0d2235',fg=self._TEXT,insertbackground=self._TEXT,relief='flat',font=('Consolas',9),
                   buttonbackground='#0d2235',
                   command=lambda:setattr(self,'_replay_speed',self._speed_var.get())).pack(side='left',padx=(0,2),ipady=2)
        self._lbl(tb1,'x').pack(side='left')
        self._replay_file_var=tk.StringVar(value='')
        tk.Label(tb1,textvariable=self._replay_file_var,bg='#040c1a',fg='#ffd93d',font=('Consolas',8)).pack(side='left',padx=4)
        tk.Frame(tb1,bg=self._SPIN,width=1,height=26).pack(side='left',padx=8)
        self._lbl(tb1,'Filter:').pack(side='left',padx=(4,4))
        self._proto_var=tk.StringVar(value='ALL')
        proto_cb=ttk.Combobox(tb1,textvariable=self._proto_var,width=8,
                               values=['ALL','TCP','UDP','DNS','HTTP','TLS','ICMP','ARP','DHCP'],
                               state='readonly',font=('Consolas',9))
        proto_cb.pack(side='left',padx=(0,8),ipady=2)
        proto_cb.bind('<<ComboboxSelected>>',lambda e:setattr(self,'_filter_proto',self._proto_var.get()))
        tk.Frame(tb1,bg=self._SPIN,width=1,height=26).pack(side='left',padx=6)
        self._label_var=tk.BooleanVar(value=True); self._legend_var=tk.BooleanVar(value=True); self._dns_var=tk.BooleanVar(value=False)
        for var,text,attr in [(self._label_var,'Labels','_show_labels'),(self._legend_var,'Legend','_show_legend'),(self._dns_var,'Resolve DNS','_resolve_names')]:
            tk.Checkbutton(tb1,text=text,variable=var,command=lambda a=attr,v=var:setattr(self,a,v.get()),
                           bg='#040c1a',fg=self._TICK,selectcolor='#0a1828',
                           activebackground='#040c1a',activeforeground=self._TEXT,font=('Consolas',8)).pack(side='left',padx=5)
        self._pkt_var=tk.StringVar(value='0 pkts')
        tk.Label(tb1,textvariable=self._pkt_var,bg='#040c1a',fg=self._ACC,font=('Consolas',9,'bold')).pack(side='right',padx=12)

        tb2=tk.Frame(r,bg='#040c1a',pady=4); tb2.pack(fill='x',padx=4)
        FONT_FAMILIES=['monospace','Consolas','Courier New','DejaVu Sans Mono','Arial','Helvetica','Tahoma']
        self._font_family_var=tk.StringVar(value='Consolas'); self._font_size_var=tk.IntVar(value=9)
        tk.Frame(tb2,bg=self._SPIN,width=1,height=22).pack(side='right',padx=6)
        ff_cb=ttk.Combobox(tb2,textvariable=self._font_family_var,values=FONT_FAMILIES,width=16,state='readonly',font=('Consolas',8))
        ff_cb.pack(side='right',padx=(0,4),ipady=1); ff_cb.bind('<<ComboboxSelected>>',lambda e:self._apply_font())
        tk.Label(tb2,text='Font:',bg='#040c1a',fg=self._TICK,font=('Consolas',9)).pack(side='right',padx=(6,2))
        fs_spin=tk.Spinbox(tb2,from_=6,to=24,textvariable=self._font_size_var,width=3,bg='#0d2235',fg=self._TEXT,
                           insertbackground=self._TEXT,relief='flat',font=('Consolas',9),buttonbackground='#0d2235',command=self._apply_font)
        fs_spin.pack(side='right',padx=(0,2),ipady=2); fs_spin.bind('<Return>',lambda e:self._apply_font())
        tk.Label(tb2,text='Size:',bg='#040c1a',fg=self._TICK,font=('Consolas',9)).pack(side='right',padx=(6,2))
        self._lbl(tb2,'Capture Filter (BPF):').pack(side='left',padx=(8,4))
        self._cfilt_var=tk.StringVar()
        tk.Entry(tb2,textvariable=self._cfilt_var,width=36,bg='#0d2235',fg=self._TEXT,
                 insertbackground=self._TEXT,relief='flat',font=('Consolas',9),
                 highlightthickness=1,highlightcolor='#a371f7',highlightbackground='#1a3050').pack(side='left',padx=(0,6),ipady=3)
        self._lbl(tb2,'(applied at capture start)',fg='#2a4060').pack(side='left')
        tk.Frame(r,bg=self._SPIN,height=1).pack(fill='x')

        import matplotlib; matplotlib.use('TkAgg')
        from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
        from matplotlib.collections import LineCollection

        pw=tk.PanedWindow(r,orient='horizontal',bg='#0a1828',sashwidth=6,sashrelief='raised',handlesize=10)
        pw.pack(fill='both',expand=True)
        canvas_frame=tk.Frame(pw,bg=self._BG); pw.add(canvas_frame,width=960)
        self._fig=plt.figure(figsize=(10,8),facecolor=self._BG)
        self._ax=self._fig.add_axes([0,0,1,1])
        self._ax.set_facecolor(self._BG); self._ax.set_xlim(0,1); self._ax.set_ylim(0,1)
        self._ax.set_aspect('equal'); self._ax.axis('off')
        self._edge_col=LineCollection([],linewidths=[],colors=[],alpha=0.7,capstyle='round',zorder=2)
        self._ax.add_collection(self._edge_col)
        self._glow_col=LineCollection([],linewidths=[],colors=[],alpha=0.12,capstyle='round',zorder=1)
        self._ax.add_collection(self._glow_col)
        self._node_sc=self._ax.scatter([],[],s=[],c=[],zorder=8,alpha=0.88,edgecolors='white',linewidths=0.5)
        self._pulse_sc=self._ax.scatter([],[],s=[],c=[],zorder=9,alpha=0.75)
        self._canvas=FigureCanvasTkAgg(self._fig,master=canvas_frame)
        self._canvas.get_tk_widget().pack(fill='both',expand=True)
        self._canvas.mpl_connect('button_press_event',self._on_canvas_click)
        self._canvas.mpl_connect('scroll_event',self._on_scroll)
        self._canvas.mpl_connect('button_press_event',self._on_pan_start)
        self._canvas.mpl_connect('motion_notify_event',self._on_pan_move)
        self._canvas.mpl_connect('button_release_event',self._on_pan_end)
        zoom_bar=tk.Frame(canvas_frame,bg='#040c1a')
        zoom_bar.place(relx=0.0,rely=1.0,anchor='sw',x=6,y=-6)
        self._zoom_lbl=tk.Label(zoom_bar,text='100%',bg='#040c1a',fg=self._TICK,font=('Consolas',8))
        self._zoom_lbl.pack(side='left',padx=2)
        tk.Button(zoom_bar,text='⊟ Reset View',command=self._zoom_reset,bg='#040c1a',fg=self._TICK,
                  relief='flat',font=('Consolas',8),cursor='hand2',
                  activebackground='#0a1828',activeforeground=self._ACC).pack(side='left',padx=4)

        right=tk.Frame(pw,bg=self._PANEL); pw.add(right,width=460)
        right_pw=tk.PanedWindow(right,orient='vertical',bg='#0a1828',sashwidth=6,sashrelief='raised',handlesize=10)
        right_pw.pack(fill='both',expand=True)
        hf=tk.Frame(right_pw,bg=self._PANEL); right_pw.add(hf,height=260,minsize=80)
        tk.Label(hf,text='  Active Hosts',bg='#040c1a',fg=self._ACC,font=('Consolas',9,'bold')).pack(fill='x',pady=(2,0))
        hcols=('ip','name','pkts','bytes','proto'); hhdrs=('IP / Host','Name','Pkts','Bytes','Proto'); hwids=(140,110,55,75,58)
        self._host_tree=ttk.Treeview(hf,columns=hcols,show='headings',style='EA.Treeview',selectmode='browse')
        for c,h,w in zip(hcols,hhdrs,hwids):
            self._host_tree.heading(c,text=h,anchor='w',command=lambda cc=c:self._sort_hosts(cc))
            self._host_tree.column(c,width=w,minwidth=30,stretch=(c=='name'))
        for proto,col in self.PROTO_COLORS.items(): self._host_tree.tag_configure(proto,foreground=col)
        hvsb=ttk.Scrollbar(hf,orient='vertical',command=self._host_tree.yview)
        self._host_tree.configure(yscrollcommand=hvsb.set); hvsb.pack(side='right',fill='y')
        self._host_tree.pack(fill='both',expand=True,padx=(4,0),pady=(0,4))
        flow_outer=tk.PanedWindow(right_pw,orient='vertical',bg='#0a1828',sashwidth=6,sashrelief='raised',handlesize=10)
        right_pw.add(flow_outer,minsize=80)
        ff=tk.Frame(flow_outer,bg=self._PANEL); flow_outer.add(ff,height=200,minsize=60)
        tk.Label(ff,text='  Active Flows',bg='#040c1a',fg=self._ACC,font=('Consolas',9,'bold')).pack(fill='x',pady=(2,0))
        fcols=('src','dst','proto','pkts','bytes'); fhdrs=('Source','Destination','Proto','Pkts','Bytes'); fwids=(160,160,58,50,68)
        self._flow_tree=ttk.Treeview(ff,columns=fcols,show='headings',style='EA.Treeview',selectmode='browse')
        for c,h,w in zip(fcols,fhdrs,fwids):
            self._flow_tree.heading(c,text=h,anchor='w')
            self._flow_tree.column(c,width=w,minwidth=40,stretch=(c=='dst'))
        for proto,col in self.PROTO_COLORS.items(): self._flow_tree.tag_configure(proto,foreground=col)
        fvsb=ttk.Scrollbar(ff,orient='vertical',command=self._flow_tree.yview)
        self._flow_tree.configure(yscrollcommand=fvsb.set); fvsb.pack(side='right',fill='y')
        self._flow_tree.pack(fill='both',expand=True,padx=(4,0),pady=(0,4))
        df=tk.Frame(flow_outer,bg=self._PANEL); flow_outer.add(df,height=200,minsize=60)
        tk.Label(df,text='  Flow Detail',bg='#040c1a',fg=self._ACC,font=('Consolas',9,'bold')).pack(fill='x',pady=(2,0))
        self._flow_detail=tk.Text(df,bg='#04080e',fg=self._TEXT,font=('Consolas',9),relief='flat',
                                   state='disabled',wrap='word',selectbackground='#0a3060',height=8)
        dvsb=ttk.Scrollbar(df,orient='vertical',command=self._flow_detail.yview)
        self._flow_detail.configure(yscrollcommand=dvsb.set); dvsb.pack(side='right',fill='y')
        self._flow_detail.pack(fill='both',expand=True,padx=(4,0),pady=(0,4))
        for tag,col in [('hdr',self._ACC),('label',self._TICK),('val',self._TEXT)]:
            self._flow_detail.tag_configure(tag,foreground=col,font=('Consolas',9,'bold') if tag=='hdr' else ('Consolas',9))
        for proto,col in self.PROTO_COLORS.items(): self._flow_detail.tag_configure(f'p_{proto}',foreground=col)
        self._flow_detail.config(state='normal'); self._flow_detail.insert('end','Click a flow above to see details.')
        self._flow_detail.config(state='disabled')
        self._flow_tree.bind('<<TreeviewSelect>>',self._on_flow_select)
        sb=tk.Frame(r,bg='#020810',height=22); sb.pack(fill='x',side='bottom'); sb.pack_propagate(False)
        self._status=tk.StringVar(value='Ready — select an interface and click ▶ Start')
        tk.Label(sb,textvariable=self._status,bg='#020810',fg=self._TICK,font=('Consolas',8),anchor='w').pack(side='left',padx=8,pady=2)

    def _load_interfaces(self):
        def _worker():
            flags=subprocess.CREATE_NO_WINDOW if sys.platform=='win32' else 0
            try:
                rd=subprocess.run([self.TSHARK,'-D'],capture_output=True,text=True,timeout=8,creationflags=flags)
                ifaces=[]
                for line in rd.stdout.splitlines():
                    m=re.match(r'^(\d+)\.\s+(.+)$',line.strip())
                    if m:
                        num=m.group(1); raw=m.group(2).strip()
                        name=EtherApeWindow._friendly_name(raw,int(num))
                        ifaces.append((num,raw,name))
                def _upd():
                    self._interfaces=ifaces
                    self._iface_cb['values']=[f'{n}. {nm}' for n,_,nm in ifaces]
                    if ifaces: self._iface_cb.current(0)
                    self._status.set(f'Found {len(ifaces)} interface(s)' if ifaces else '⚠  No interfaces — is npcap installed?')
                self.root.after(0,_upd)
            except FileNotFoundError:
                self.root.after(0,lambda:self._status.set(f'⚠  tshark.exe not found at {self.TSHARK}'))
            except Exception as ex:
                self.root.after(0,lambda:self._status.set(f'⚠  {ex}'))
        threading.Thread(target=_worker,daemon=True).start()

    @staticmethod
    def _friendly_name(raw_desc,index):
        m=re.search(r'\(([^)]+)\)\s*$',raw_desc)
        base=m.group(1).strip() if m else raw_desc.strip()
        base=re.sub(r'^\\\\[^\\]+\\[^\\]+\\?','',base).strip()
        base=re.sub(r'^\{[A-F0-9\-]+\}','',base,flags=re.I).strip()
        if not base: base=raw_desc.strip()
        hints=[(r'wi.?fi|wireless|wlan|802\.11|wlp','Wi-Fi'),(r'ethernet|eth|local area|lan|gigabit|intel|realtek','Ethernet'),(r'loopback|npcap loopback|lo\b','Loopback'),(r'bluetooth','Bluetooth'),(r'vpn|tun|tap|nordvpn|expressvpn|openvpn','VPN'),(r'virtual|vmware|virtualbox|hyper.?v|veth','Virtual'),(r'mobile|cellular|lte|4g|5g|ndis','Mobile Broadband'),(r'usb','USB Network')]
        lo=base.lower()
        for pattern,label in hints:
            if re.search(pattern,lo,re.I):
                if len(base)<60 and not re.search(r'\{[A-F0-9\-]+\}',base,re.I): return base
                return f'{label} {index}'
        if len(base)<=48 and not re.search(r'\{[A-F0-9\-]+\}',base,re.I): return base
        return f'Interface {index}'

    def _proto_tag(self,protos):
        if not protos: return 'other'
        parts=set(protos.split(':'))
        for p in self.PROTO_PRIORITY:
            if p in parts: return p
        return 'other'

    def _start_capture(self):
        if self._capturing: return
        cb_text=self._iface_var.get().strip()
        m_iface=re.match(r'^(\d+)\.',cb_text)
        if not m_iface:
            self._show_error_dialog('No Interface','No interface selected.'); return
        iface_num=m_iface.group(1)
        sel=self._iface_cb.current()
        friendly=self._interfaces[sel][2] if 0<=sel<len(self._interfaces) else cb_text
        self._pkts_this_run=0; self._capturing=True
        self._start_btn.config(state='disabled'); self._stop_btn.config(state='normal')
        self._status.set(f'◎  Starting capture on {friendly}...')
        threading.Thread(target=self._launch_tshark,args=(iface_num,friendly),daemon=True).start()

    def _launch_tshark(self,iface_num,friendly):
        flags=subprocess.CREATE_NO_WINDOW if sys.platform=='win32' else 0
        cmd=[self.TSHARK,'-i',iface_num,'-l','-n','-T','fields',
             '-e','ip.src','-e','ip.dst','-e','ipv6.src','-e','ipv6.dst',
             '-e','eth.src','-e','eth.dst','-e','frame.protocols','-e','frame.len',
             '-E','separator=\t','-E','quote=n','-E','occurrence=f']
        cf=getattr(self,'_cfilt_var',None)
        if cf:
            v=cf.get().strip()
            if v: cmd+=['-f',v]
        try:
            proc=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=flags)
        except FileNotFoundError:
            self._capturing=False
            msg=f'tshark.exe not found at:\n{self.TSHARK}\n\nUpdate path in \u2699 Settings or install Wireshark.'
            self.root.after(0,lambda:self._show_error_dialog('tshark Not Found',msg))
            self.root.after(0,self._reset_buttons); return
        except Exception as ex:
            self._capturing=False
            self.root.after(0,lambda:self._show_error_dialog('Launch Error',str(ex)))
            self.root.after(0,self._reset_buttons); return
        self._cap_proc=proc
        self.root.after(0,lambda:self._status.set(f'\u25ce  Capturing on {friendly}...'))
        stderr_lines=[]
        def _drain_stderr():
            try:
                for raw in proc.stderr: stderr_lines.append(raw.decode('utf-8',errors='replace').rstrip())
            except Exception: pass
        threading.Thread(target=_drain_stderr,daemon=True).start()
        self._capture_loop(proc,stderr_lines,friendly)

    def _capture_loop(self,proc,stderr_lines,friendly):
        got_packets=False; user_stopped=False
        try:
            while self._capturing:
                line=proc.stdout.readline()
                if not line: break
                raw=line.decode('utf-8',errors='replace').rstrip('\r\n')
                if not raw: continue
                parts=raw.split('\t')
                while len(parts)<8: parts.append('')
                src=parts[0] or parts[2] or parts[4] or ''
                dst=parts[1] or parts[3] or parts[5] or ''
                protos=parts[6].lower()
                length=int(parts[7]) if parts[7].isdigit() else 0
                if src and dst:
                    got_packets=True; self._pkts_this_run+=1
                    self._pkt_queue.append((src,dst,protos,length))
            user_stopped=not self._capturing
        except Exception: pass
        import time as _t; _t.sleep(0.3)
        ret=proc.poll()
        if not user_stopped and not got_packets:
            err='\n'.join(stderr_lines).strip() or '(no error output from tshark)'
            lo=err.lower()
            if 'permission' in lo or 'access' in lo or 'denied' in lo: hint='\n\n\U0001f4a1 Run as Administrator.'
            elif 'npcap' in lo or 'winpcap' in lo: hint='\n\n\U0001f4a1 Install Npcap from npcap.com'
            else: hint='\n\n\U0001f4a1 Try right-click \u2192 Run as Administrator.'
            msg=f'tshark exited (code {ret}) without packets.\n\nstderr:\n{err}{hint}'
            self.root.after(0,lambda m=msg:self._show_error_dialog('Capture Failed',m))
        self.root.after(0,self._on_ended)

    def _show_error_dialog(self,title,message):
        tk=self._tk
        win=tk.Toplevel(self.root); win.title(title); win.configure(bg=self._BG)
        win.geometry('620x340'); win.resizable(True,True); win.grab_set()
        tk.Label(win,text=f'  \u26a0  {title}',bg='#200808',fg='#ff6b6b',font=('Consolas',11,'bold')).pack(fill='x')
        tk.Frame(win,bg='#3a0808',height=1).pack(fill='x')
        fc=tk.Frame(win,bg=self._PANEL); fc.pack(fill='both',expand=True,padx=8,pady=8)
        txt=tk.Text(fc,bg='#04080e',fg=self._TEXT,font=('Consolas',9),relief='flat',wrap='word',state='normal')
        vsb=self._ttk.Scrollbar(fc,orient='vertical',command=txt.yview)
        txt.configure(yscrollcommand=vsb.set); vsb.pack(side='right',fill='y'); txt.pack(fill='both',expand=True)
        txt.insert('end',message); txt.config(state='disabled')
        tk.Button(win,text='  OK  ',command=win.destroy,bg='#062040',fg=self._ACC,
                  font=('Consolas',10,'bold'),relief='flat',cursor='hand2').pack(pady=(0,8))

    def _reset_buttons(self):
        self._start_btn.config(state='normal'); self._stop_btn.config(state='disabled')
        self._status.set('Ready')

    def _stop_capture(self):
        self._capturing=False
        if self._cap_proc:
            try: self._cap_proc.terminate()
            except Exception: pass
            self._cap_proc=None

    def _on_ended(self):
        self._capturing=False; self._reset_buttons()
        pkts=getattr(self,'_pkts_this_run',0)
        if pkts>0: self._status.set(f'Capture stopped \u2014 {pkts:,} packet{"s" if pkts!=1 else ""} captured')

    def _clear(self):
        self._pkt_queue.clear(); self._nodes.clear(); self._flows.clear()
        self._total_bytes=0; self._total_pkts=0; self._status.set('Cleared')

    def _open_pcap_replay(self):
        from tkinter import filedialog
        path=filedialog.askopenfilename(title='Open PCAP for Replay',parent=self.root,
            filetypes=[('PCAP / PCAPNG','*.pcap *.pcapng *.cap *.pcap.gz'),('All files','*.*')])
        if not path: return
        self._pcap_replay_path=path
        name=path.split('/')[-1].split('\\')[-1]
        self._replay_file_var.set(f'  {name}')
        self._replay_btn.config(state='normal')
        self._status.set(f'PCAP loaded: {name}  \u2014 click \u23f5 Replay to start')

    def _start_replay(self):
        if self._replaying or self._capturing: return
        path=getattr(self,'_pcap_replay_path',None)
        if not path: return
        self._stop_replay(); self._clear(); self._replaying=True
        self._replay_btn.config(state='disabled'); self._stop_replay_btn.config(state='normal')
        self._start_btn.config(state='disabled')
        speed=self._replay_speed if self._replay_speed>0 else 1.0
        self._replay_thread=threading.Thread(target=self._replay_loop,args=(path,speed),daemon=True)
        self._replay_thread.start()

    def _stop_replay(self): self._replaying=False

    def _replay_loop(self,path,speed):
        import time as _t
        flags=subprocess.CREATE_NO_WINDOW if sys.platform=='win32' else 0
        cmd=[self.TSHARK,'-r',path,'-n','-T','fields','-e','frame.time_relative',
             '-e','ip.src','-e','ip.dst','-e','ipv6.src','-e','ipv6.dst',
             '-e','eth.src','-e','eth.dst','-e','frame.protocols','-e','frame.len',
             '-E','separator=\t','-E','quote=n','-E','occurrence=f']
        try:
            proc=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=flags)
        except FileNotFoundError:
            if not self._closed:
                self.root.after(0,lambda:self._show_error_dialog('tshark Not Found',f'Not found at {self.TSHARK}'))
                self.root.after(0,self._replay_ended)
            return
        except Exception as ex:
            if not self._closed: self.root.after(0,lambda:self._show_error_dialog('Replay Error',str(ex)))
            self.root.after(0,self._replay_ended); return
        threading.Thread(target=lambda:proc.stderr.read(),daemon=True).start()
        prev_ts=None; wall_prev=None; pkt_count=0
        try:
            for raw_line in proc.stdout:
                if not self._replaying: proc.terminate(); break
                raw=raw_line.decode('utf-8',errors='replace').rstrip('\r\n')
                if not raw: continue
                parts=raw.split('\t')
                while len(parts)<9: parts.append('')
                ts_str=parts[0]; src=parts[1] or parts[3] or parts[5] or ''
                dst=parts[2] or parts[4] or parts[6] or ''; protos=parts[7].lower()
                length=int(parts[8]) if parts[8].isdigit() else 0
                try: ts=float(ts_str)
                except: ts=None
                now=_t.perf_counter()
                if ts is not None and prev_ts is not None and wall_prev is not None:
                    gap=(ts-prev_ts)/speed; elapsed=now-wall_prev; sleep_for=gap-elapsed
                    if sleep_for>0: _t.sleep(min(sleep_for,2.0))
                prev_ts=ts; wall_prev=_t.perf_counter()
                if src and dst:
                    pkt_count+=1; self._pkt_queue.append((src,dst,protos,length))
        except Exception: pass
        if not self._closed: self.root.after(0,self._replay_ended)

    def _replay_ended(self):
        self._replaying=False; self._replay_btn.config(state='normal')
        self._stop_replay_btn.config(state='disabled'); self._start_btn.config(state='normal')
        path=getattr(self,'_pcap_replay_path','')
        name=path.split('/')[-1].split('\\')[-1] if path else ''
        self._status.set(f'Replay finished \u2014 {name}  ({self._total_pkts:,} pkts processed)')

    def _sort_hosts(self,col):
        items=[(self._host_tree.item(i,'values'),i) for i in self._host_tree.get_children()]
        rev=getattr(self,'_host_sort_rev',False); idx=('ip','name','pkts','bytes','proto').index(col)
        def _k(x):
            v=x[0][idx]
            try: return float(v.replace(',','').replace('KB','').replace('MB',''))
            except: return v.lower()
        items.sort(key=_k,reverse=not rev)
        for i,(_,iid) in enumerate(items): self._host_tree.move(iid,'',i)
        self._host_sort_rev=not rev

    def _schedule_render(self):
        if not self._closed: self.root.after(self.RENDER_MS,self._render_tick)

    def _schedule_table_update(self):
        if not self._closed: self.root.after(self.TABLE_MS,self._table_tick)

    def _render_tick(self):
        if self._closed: return
        try: self._render_tick_inner()
        except Exception: pass
        self._schedule_render()

    def _render_tick_inner(self):
        batch=self._pkt_queue[:200]; del self._pkt_queue[:200]
        fp=self._filter_proto
        for src,dst,protos,length in batch:
            ptag=self._proto_tag(protos)
            if fp!='ALL' and fp.lower() not in protos: continue
            self._total_bytes+=length; self._total_pkts+=1
            for ip in (src,dst):
                if ip not in self._nodes:
                    if len(self._nodes)>=self.MAX_NODES: continue
                    angle=len(self._nodes)*2*np.pi/self.MAX_NODES; r_=0.30+0.15*np.random.random()
                    self._nodes[ip]={'bytes':0.0,'pkts':0,'pos':(0.5+r_*np.cos(angle),0.5+r_*np.sin(angle)),'proto':ptag,'age':0}
                nd=self._nodes[ip]; nd['bytes']+=length; nd['pkts']+=1; nd['proto']=ptag; nd['age']=0
            key=(src,dst,ptag)
            if key not in self._flows:
                if len(self._flows)>=self.MAX_FLOWS:
                    evict=min(self._flows,key=lambda k:self._flows[k]['bytes']); del self._flows[evict]
                self._flows[key]={'bytes':0.0,'pkts':0,'proto':ptag,'age':0}
            fl=self._flows[key]; fl['bytes']+=length; fl['pkts']+=1; fl['age']=0
        self._tick+=1; self._pulse_t=(self._pulse_t+0.07)%1.0
        for ip in [ip for ip,nd in self._nodes.items() if nd['bytes']<50]: del self._nodes[ip]
        for nd in self._nodes.values(): nd['bytes']*=self.DECAY
        for k in [k for k,fl in self._flows.items() if fl['bytes']<20]: del self._flows[k]
        for fl in self._flows.values(): fl['bytes']*=self.DECAY
        nodes=self._nodes; flows=self._flows
        if not nodes:
            self._edge_col.set_segments([]); self._glow_col.set_segments([])
            self._node_sc.set_offsets(np.empty((0,2))); self._node_sc.set_sizes([])
            self._pulse_sc.set_offsets(np.empty((0,2))); self._pulse_sc.set_sizes([])
            if not getattr(self,'_placeholder_drawn',False):
                for _t in list(self._ax.texts): _t.remove()
                self._ax.text(0.5,0.5,'No traffic yet\nStart a capture to see the topology',
                              color=self._TICK,fontsize=13,ha='center',va='center',
                              fontfamily='monospace',linespacing=1.8,zorder=20)
                self._placeholder_drawn=True
            self._apply_view(); self._canvas.draw_idle(); return
        else:
            self._placeholder_drawn=False
            if self._ax.texts:
                for _t in list(self._ax.texts): _t.remove()
        max_bytes=max((n['bytes'] for n in nodes.values()),default=1) or 1
        segs,lws,colors_e,segs_glow,lws_glow=[],[],[],[],[]
        pulse_xs,pulse_ys,pulse_ss,pulse_cs=[],[],[],[]
        flow_seg_map=[]
        for (src,dst,proto),fl in flows.items():
            if src not in nodes or dst not in nodes: continue
            if fl['bytes']<10: continue
            if fp!='ALL' and fp.lower()!=proto: continue
            x0,y0=nodes[src]['pos']; x1,y1=nodes[dst]['pos']
            col=self.PROTO_COLORS.get(proto,self.PROTO_COLORS['other'])
            frac=np.log1p(fl['bytes'])/np.log1p(max_bytes); lw=max(0.8,frac*5.0)
            segs.append([(x0,y0),(x1,y1)]); lws.append(lw); colors_e.append(col)
            segs_glow.append([(x0,y0),(x1,y1)]); lws_glow.append(lw*6); colors_e.append(col)
            flow_seg_map.append((x0,y0,x1,y1,src,dst,proto))
            t=(self._pulse_t+hash(src)*0.01)%1.0
            px=x0+(x1-x0)*t; py=y0+(y1-y0)*t; ps=max(12,frac*60)
            pulse_xs.append(px); pulse_ys.append(py); pulse_ss.append(ps); pulse_cs.append(col)
        self._flow_seg_map=flow_seg_map
        if segs:
            self._edge_col.set_segments(segs); self._edge_col.set_linewidth(lws)
            self._edge_col.set_colors(colors_e[:len(segs)]); self._edge_col.set_alpha(0.75)
            self._glow_col.set_segments(segs_glow); self._glow_col.set_linewidth(lws_glow)
            self._glow_col.set_colors(colors_e[:len(segs)]); self._glow_col.set_alpha(0.10)
        else:
            self._edge_col.set_segments([]); self._glow_col.set_segments([])
        if pulse_xs:
            pts=np.column_stack([pulse_xs,pulse_ys])
            self._pulse_sc.set_offsets(pts); self._pulse_sc.set_sizes(pulse_ss); self._pulse_sc.set_facecolors(pulse_cs)
        else:
            self._pulse_sc.set_offsets(np.empty((0,2))); self._pulse_sc.set_sizes([])
        node_xs,node_ys,node_ss,node_cs=[],[],[],[]
        for ip,nd in nodes.items():
            x,y=nd['pos']; col=self.PROTO_COLORS.get(nd['proto'],self.PROTO_COLORS['other'])
            frac=nd['bytes']/max_bytes; sz=max(40,min(1400,frac*1200+40))
            node_xs.append(x); node_ys.append(y); node_ss.append(sz); node_cs.append(col)
        if node_xs:
            pts=np.column_stack([node_xs,node_ys])
            self._node_sc.set_offsets(pts); self._node_sc.set_sizes(node_ss); self._node_sc.set_facecolors(node_cs)
        else:
            self._node_sc.set_offsets(np.empty((0,2))); self._node_sc.set_sizes([])
        for txt in list(self._ax.texts): txt.remove()
        if self._show_labels:
            for ip,nd in nodes.items():
                x,y=nd['pos']; col=self.PROTO_COLORS.get(nd['proto'],self.PROTO_COLORS['other'])
                disp=self._resolve(ip); frac=nd['bytes']/max_bytes
                r_px=max(0.012,min(0.065,0.012+frac*0.053))
                self._ax.text(x,y-r_px-0.022,disp,color=col,fontsize=self._label_fontsize,
                              ha='center',va='top',fontfamily=self._label_fontfamily,fontweight='bold',zorder=11,
                              bbox=dict(boxstyle='round,pad=0.08',facecolor='#020810',edgecolor='none',alpha=0.60))
        if self._show_legend:
            protos_seen=set(nd['proto'] for nd in nodes.values())
            lx,ly=0.01,0.99
            for proto in self.PROTO_PRIORITY+['other']:
                if proto not in protos_seen: continue
                col=self.PROTO_COLORS.get(proto,self.PROTO_COLORS['other'])
                self._ax.text(lx+0.028,ly-0.004,f'● {proto.upper()}',color=col,
                              fontsize=self._label_fontsize,va='center',
                              fontfamily=self._label_fontfamily,fontweight='bold',zorder=12)
                ly-=0.036
        tb=self._total_bytes
        unit='KB' if tb<1e6 else 'MB' if tb<1e9 else 'GB'
        div=1e3 if tb<1e6 else 1e6 if tb<1e9 else 1e9
        self._total_var.set(f'{len(nodes)} hosts  |  {len(flows)} flows  |  {self._total_pkts:,} pkts  |  {tb/div:.1f} {unit}')
        self._pkt_var.set(f'{self._total_pkts:,} pkts')
        self._apply_view(); self._canvas.draw_idle()

    def _table_tick(self):
        if self._closed: return
        try: self._table_tick_inner()
        except Exception: pass
        self._schedule_table_update()

    def _table_tick_inner(self):
        nodes=dict(self._nodes); flows=dict(self._flows)
        self._host_tree.delete(*self._host_tree.get_children())
        for ip,nd in sorted(nodes.items(),key=lambda x:x[1]['bytes'],reverse=True)[:60]:
            b=nd['bytes']; unit='KB' if b<1e6 else 'MB'; div=1e3 if b<1e6 else 1e6
            name=self._dns_cache.get(ip,'')
            self._host_tree.insert('','end',values=(ip,name,f"{nd['pkts']:,}",f"{b/div:.1f}{unit}",nd['proto'].upper()),tags=(nd['proto'],))
        self._flow_tree.delete(*self._flow_tree.get_children())
        for (src,dst,proto),fl in sorted(flows.items(),key=lambda x:x[1]['bytes'],reverse=True)[:80]:
            b=fl['bytes']; unit='KB' if b<1e6 else 'MB'; div=1e3 if b<1e6 else 1e6
            iid=f'{src}|{dst}|{proto}'
            self._flow_tree.insert('','end',iid=iid,
                values=(src[:22],dst[:22],proto.upper(),f"{fl['pkts']:,}",f"{b/div:.1f}{unit}"),tags=(proto,))

    def _apply_view(self):
        half=0.5/self._zoom
        self._ax.set_xlim(self._pan_x-half,self._pan_x+half)
        self._ax.set_ylim(self._pan_y-half,self._pan_y+half)
        try: self._zoom_lbl.config(text=f'{int(self._zoom*100)}%')
        except Exception: pass

    def _zoom_reset(self):
        self._zoom=1.0; self._pan_x=0.5; self._pan_y=0.5
        self._apply_view(); self._canvas.draw_idle()

    def _on_scroll(self,event):
        if self._closed or event.xdata is None or event.ydata is None: return
        factor=1.15 if event.button=='up' else (1/1.15)
        new_zoom=max(0.2,min(20.0,self._zoom*factor))
        cx,cy=event.xdata,event.ydata
        self._pan_x=cx+(self._pan_x-cx)*(self._zoom/new_zoom)
        self._pan_y=cy+(self._pan_y-cy)*(self._zoom/new_zoom)
        self._zoom=new_zoom; self._apply_view(); self._canvas.draw_idle()

    def _on_pan_start(self,event):
        if self._closed: return
        if event.button in (2,3) and event.xdata is not None and event.ydata is not None:
            self._pan_dragging=True; self._pan_last=(event.xdata,event.ydata)

    def _on_pan_move(self,event):
        if self._closed or not self._pan_dragging: return
        if event.xdata is None or event.ydata is None: return
        dx=event.xdata-self._pan_last[0]; dy=event.ydata-self._pan_last[1]
        self._pan_x-=dx; self._pan_y-=dy; self._apply_view(); self._canvas.draw_idle()

    def _on_pan_end(self,event):
        if event.button in (2,3): self._pan_dragging=False

    def _on_canvas_click(self,event):
        if self._closed: return
        try:
            if event.xdata is None or event.ydata is None: return
            cx,cy=event.xdata,event.ydata; best_dist=0.04; best_flow=None
            for (x0,y0,x1,y1,src,dst,proto) in self._flow_seg_map:
                dx,dy=x1-x0,y1-y0; seg_len2=dx*dx+dy*dy
                if seg_len2==0: dist=((cx-x0)**2+(cy-y0)**2)**0.5
                else:
                    t=max(0.0,min(1.0,((cx-x0)*dx+(cy-y0)*dy)/seg_len2))
                    px,py=x0+t*dx,y0+t*dy; dist=((cx-px)**2+(cy-py)**2)**0.5
                if dist<best_dist: best_dist=dist; best_flow=(src,dst,proto)
            if best_flow:
                src,dst,proto=best_flow; self._show_flow_detail(src,dst,proto)
                iid=f'{src}|{dst}|{proto}'
                try:
                    if self._flow_tree.exists(iid): self._flow_tree.selection_set(iid); self._flow_tree.see(iid)
                except Exception: pass
        except Exception: pass

    def _show_flow_detail(self,src,dst,proto):
        try:
            fl=self._flows.get((src,dst,proto))
            txt=self._flow_detail; txt.config(state='normal'); txt.delete('1.0','end')
            txt.insert('end','  Flow Detail\n','hdr'); txt.insert('end','\u2500'*36+'\n','label')
            def row(label,value,vtag='val'):
                txt.insert('end',f'  {label:<16}','label'); txt.insert('end',f'{value}\n',vtag)
            row('Protocol',proto.upper(),f'p_{proto}'); txt.insert('end','\n')
            row('Source IP',src)
            src_name=self._dns_cache.get(src,'')
            if src_name and src_name!=src: row('  \u2192 hostname',src_name)
            row('Destination',dst)
            dst_name=self._dns_cache.get(dst,'')
            if dst_name and dst_name!=dst: row('  \u2192 hostname',dst_name)
            txt.insert('end','\n')
            if fl:
                b=fl['bytes']; pkts=fl['pkts']
                if b<1e3: b_str=f'{b:.0f} B'
                elif b<1e6: b_str=f'{b/1e3:.1f} KB'
                elif b<1e9: b_str=f'{b/1e6:.1f} MB'
                else: b_str=f'{b/1e9:.2f} GB'
                row('Packets',f'{pkts:,}'); row('Data (approx)',b_str)
                if pkts>0: row('Avg pkt size',f'{b/pkts:.0f} B')
            else: txt.insert('end','  (flow data expired)\n','label')
            txt.insert('end','\n'); txt.insert('end','\u2500'*36+'\n','label')
            txt.config(state='disabled')
        except Exception:
            try: self._flow_detail.config(state='disabled')
            except Exception: pass

    def _on_flow_select(self,event=None):
        sel=self._flow_tree.selection()
        if not sel: return
        iid=sel[0]
        try: src,dst,proto=iid.split('|',2)
        except ValueError: return
        self._show_flow_detail(src,dst,proto)

    def _resolve(self,ip):
        if not self._resolve_names: return ip[:18]
        if ip in self._dns_cache: return self._dns_cache[ip]
        self._dns_cache[ip]=ip
        def _r(addr=ip):
            try: self._dns_cache[addr]=socket.gethostbyaddr(addr)[0][:20]
            except Exception: self._dns_cache[addr]=addr
        threading.Thread(target=_r,daemon=True).start()
        return ip[:18]


# ─────────────────────────────────────────────────────────────────────────────
#  Wireshark Monitor
# ─────────────────────────────────────────────────────────────────────────────
class WiresharkWindow:
    TSHARK = r"C:\Program Files\Wireshark\tshark.exe"

    _BG    = '#050d1a'
    _PANEL = '#06101e'
    _ACC   = '#38b8f0'
    _TEXT  = '#c8dff0'
    _TICK  = '#6a9ab8'
    _SPIN  = '#0a1828'

    PROTO_COLORS = {
        'http2':  '#39ff14', 'http':   '#39ff14',
        'tls':    '#6bcb77', 'ssl':    '#6bcb77',
        'dns':    '#ff9f43', 'mdns':   '#ff9f43',
        'dhcp':   '#ffd93d', 'dhcpv6': '#ffd93d',
        'icmpv6': '#ff9999', 'icmp':   '#ff6b6b',
        'tcp':    '#00d4aa', 'udp':    '#a371f7',
        'arp':    '#74c7ec', 'ipv6':   '#5ab8d4',
        'ip':     '#4a9ab4', 'other':  '#c8dff0',
    }
    PROTO_PRIORITY = [
        'http2','http','tls','ssl','dns','mdns','dhcp','dhcpv6',
        'icmpv6','icmp','tcp','udp','arp','ipv6','ip',
    ]
    _IFACE_HINTS = [
        (r'wi.?fi|wireless|wlan|802\.11|wlp',         'Wi-Fi'),
        (r'ethernet|eth|local area|lan|gigabit|intel|realtek', 'Ethernet'),
        (r'loopback|npcap loopback|lo\b',             'Loopback'),
        (r'bluetooth',                                  'Bluetooth'),
        (r'vpn|tun|tap|nordvpn|expressvpn|openvpn',   'VPN'),
        (r'virtual|vmware|virtualbox|hyper.?v|veth',  'Virtual'),
        (r'mobile|cellular|lte|4g|5g|ndis',           'Mobile Broadband'),
        (r'usb',                                        'USB Network'),
    ]

    def __init__(self, tshark_path=None):
        import tkinter as tk
        from tkinter import ttk, filedialog, messagebox
        import tempfile
        self._tk  = tk
        self._ttk = ttk
        self._fd  = filedialog
        self._mb  = messagebox

        # Accept path from Settings
        if tshark_path:
            self.TSHARK = tshark_path

        self.root = tk.Toplevel()
        self.root.title('Wireshark Monitor')
        self.root.configure(bg=self._BG)
        self.root.geometry('1440x940')
        self.root.minsize(900, 620)

        self._packets    = []
        self._all_pkts   = []
        self._pkt_queue  = []
        self._capfile    = Path(tempfile.gettempdir()) / 'nm_wireshark.pcap'
        self._cap_proc   = None
        self._capturing  = False
        self._pkt_count  = 0
        self._sort_col   = None
        self._sort_rev   = False
        self._interfaces = []

        try:
            self._build_style()
            self._build_ui()
            self._build_menu()
            self._load_interfaces()
            self.root.update_idletasks()
            self.root.lift()
            self.root.focus_force()
        except Exception as _err:
            import traceback as _tb
            _msg = _tb.format_exc()
            print(_msg)
            import tkinter.messagebox as _tmb
            try:
                _tmb.showerror('Wireshark Init Error', str(_err) + '\n\n' + _msg[-800:], parent=self.root)
            except Exception:
                pass

    @classmethod
    def _friendly_name(cls, raw_desc: str, index: int) -> str:
        m = re.search(r'\(([^)]+)\)\s*$', raw_desc)
        base = m.group(1).strip() if m else raw_desc.strip()
        base = re.sub(r'^\\\\\\\\[^\\\\]+\\\\[^\\\\]+\\\\?', '', base).strip()
        base = re.sub(r'^\\{[A-F0-9\\-]+\\}', '', base, flags=re.I).strip()
        if not base:
            base = raw_desc.strip()
        lo = base.lower()
        for pattern, label in cls._IFACE_HINTS:
            if re.search(pattern, lo, re.I):
                if len(base) < 60 and not re.search(r'\\{[A-F0-9\\-]+\\}', base, re.I):
                    return base
                return f'{label} {index}'
        if len(base) <= 48 and not re.search(r'\\{[A-F0-9\\-]+\\}', base, re.I):
            return base
        return f'Interface {index}'

    def _build_style(self):
        s = self._ttk.Style(self.root)
        s.theme_use('clam')
        p, acc, txt, tick = self._PANEL, self._ACC, self._TEXT, self._TICK
        for name, fs in [('Pkt', 9), ('Det', 8), ('Stat', 9)]:
            s.configure(f'{name}.Treeview',
                        background=p, fieldbackground=p, foreground=txt,
                        font=('Consolas', fs), rowheight=20, borderwidth=0)
            s.configure(f'{name}.Treeview.Heading',
                        background='#040c1a', foreground=tick,
                        font=('Consolas', fs, 'bold'), relief='flat')
            s.map(f'{name}.Treeview',
                  background=[('selected', '#0a3060')],
                  foreground=[('selected', 'white')])

    def _build_menu(self):
        tk = self._tk
        mbar = tk.Menu(self.root, bg='#040c1a', fg=self._TEXT,
                       activebackground='#0a3060', activeforeground='white',
                       relief='flat', bd=0, font=('Consolas', 9))
        self.root.config(menu=mbar)
        self.root.update_idletasks()

        analyse = tk.Menu(mbar, tearoff=0, bg='#040c1a', fg=self._TEXT,
                          activebackground='#0a3060', activeforeground='white',
                          font=('Consolas', 9))
        mbar.add_cascade(label='Analyse', menu=analyse)
        analyse.add_command(label='Expert Information', command=self._show_expert_info)
        analyse.add_separator()
        analyse.add_command(label='Follow TCP Stream', command=lambda: self._follow_stream('tcp'))
        analyse.add_command(label='Follow UDP Stream', command=lambda: self._follow_stream('udp'))
        analyse.add_command(label='Follow TLS Stream', command=lambda: self._follow_stream('tls'))
        analyse.add_separator()
        analyse.add_command(label='Decode As…', command=self._decode_as)
        analyse.add_command(label='Show Packet Bytes', command=self._show_packet_bytes)

        stats = tk.Menu(mbar, tearoff=0, bg='#040c1a', fg=self._TEXT,
                        activebackground='#0a3060', activeforeground='white',
                        font=('Consolas', 9))
        mbar.add_cascade(label='Statistics', menu=stats)
        stats.add_command(label='Summary / Capture File Properties', command=self._show_summary)
        stats.add_separator()
        stats.add_command(label='Protocol Hierarchy', command=self._show_proto_hierarchy)
        stats.add_separator()
        stats.add_command(label='Conversations — Ethernet', command=lambda: self._show_conversations('eth'))
        stats.add_command(label='Conversations — IPv4',     command=lambda: self._show_conversations('ip'))
        stats.add_command(label='Conversations — IPv6',     command=lambda: self._show_conversations('ipv6'))
        stats.add_command(label='Conversations — TCP',      command=lambda: self._show_conversations('tcp'))
        stats.add_command(label='Conversations — UDP',      command=lambda: self._show_conversations('udp'))
        stats.add_separator()
        stats.add_command(label='Endpoints — IPv4', command=lambda: self._show_endpoints('ip'))
        stats.add_command(label='Endpoints — IPv6', command=lambda: self._show_endpoints('ipv6'))
        stats.add_command(label='Endpoints — TCP',  command=lambda: self._show_endpoints('tcp'))
        stats.add_command(label='Endpoints — UDP',  command=lambda: self._show_endpoints('udp'))
        stats.add_separator()
        stats.add_command(label='I/O Graph',       command=self._show_io_graph)
        stats.add_command(label='Packet Lengths',  command=self._show_packet_lengths)
        stats.add_separator()
        stats.add_command(label='DNS Statistics',  command=self._show_dns_stats)
        stats.add_command(label='HTTP Statistics', command=self._show_http_stats)

    def _btn(self, parent, text, cmd, fg, bg, hover=None, **kw):
        if hover is None:
            hover = bg
        return self._tk.Button(
            parent, text=text, command=cmd,
            bg=bg, fg=fg, activebackground=hover, activeforeground=fg,
            font=('Consolas', 9, 'bold'), relief='flat',
            cursor='hand2', padx=10, pady=3, **kw)

    def _entry(self, parent, var, width, accent=None):
        return self._tk.Entry(
            parent, textvariable=var, width=width,
            bg='#0d2235', fg=self._TEXT, insertbackground=self._TEXT,
            relief='flat', font=('Consolas', 9),
            highlightthickness=1,
            highlightcolor=accent or self._ACC,
            highlightbackground='#1a3050')

    def _stat_window(self, title, width=900, height=500):
        win = self._tk.Toplevel(self.root)
        win.title(title)
        win.configure(bg=self._BG)
        win.geometry(f'{width}x{height}')
        hdr = self._tk.Frame(win, bg='#020810', height=36)
        hdr.pack(fill='x'); hdr.pack_propagate(False)
        self._tk.Label(hdr, text=f'  {title}',
                       bg='#020810', fg=self._ACC,
                       font=('Consolas', 11, 'bold')).pack(side='left', pady=6)
        self._tk.Frame(win, bg=self._SPIN, height=1).pack(fill='x')
        return win

    def _stat_tree(self, parent, columns, headings, widths, style='Stat.Treeview'):
        frm = self._tk.Frame(parent, bg=self._PANEL)
        frm.pack(fill='both', expand=True, padx=6, pady=6)
        tv = self._ttk.Treeview(frm, columns=columns, show='headings',
                                  style=style, selectmode='browse')
        for c, h, w in zip(columns, headings, widths):
            tv.heading(c, text=h, anchor='w')
            tv.column(c, width=w, minwidth=40, stretch=(c == columns[-1]))
        vsb = self._ttk.Scrollbar(frm, orient='vertical', command=tv.yview)
        hsb = self._ttk.Scrollbar(frm, orient='horizontal', command=tv.xview)
        tv.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        vsb.pack(side='right', fill='y')
        hsb.pack(side='bottom', fill='x')
        tv.pack(fill='both', expand=True)
        return tv

    def _run_tshark(self, args, timeout=30):
        flags = subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0
        r = subprocess.run([self.TSHARK] + args,
                           capture_output=True, text=True, timeout=timeout,
                           creationflags=flags)
        return r.stdout, r.stderr

    def _need_file(self):
        if not self._capfile.exists():
            self._mb.showwarning('No Data',
                'No capture data available.\n'
                'Start a capture or open a PCAP file first.',
                parent=self.root)
            return False
        return True

    def _build_ui(self):
        tk  = self._tk
        ttk = self._ttk
        r   = self.root

        hdr = tk.Frame(r, bg='#020810', height=46)
        hdr.pack(fill='x'); hdr.pack_propagate(False)
        tk.Label(hdr, text='[WS]  WIRESHARK MONITOR',
                 bg='#020810', fg=self._ACC,
                 font=('Consolas', 15, 'bold')).pack(side='left', padx=16, pady=8)
        tk.Label(hdr, text='Live Packet Capture & Deep Inspection',
                 bg='#020810', fg=self._TICK,
                 font=('Consolas', 9)).pack(side='left', pady=14)
        self._ver_var = tk.StringVar(value='')
        tk.Label(hdr, textvariable=self._ver_var, bg='#020810', fg='#2a4060',
                 font=('Consolas', 8)).pack(side='right', padx=14, pady=14)
        tk.Frame(r, bg=self._SPIN, height=1).pack(fill='x')

        tb1 = tk.Frame(r, bg='#040c1a', pady=5)
        tb1.pack(fill='x', padx=4)

        tk.Label(tb1, text='Interface:', bg='#040c1a', fg=self._TICK,
                 font=('Consolas', 9)).pack(side='left', padx=(8, 4))
        self._iface_var = tk.StringVar()
        self._iface_cb  = ttk.Combobox(tb1, textvariable=self._iface_var,
                                        width=38, state='readonly',
                                        font=('Consolas', 9))
        self._iface_cb.pack(side='left', padx=(0, 8), ipady=2)

        self._start_btn = self._btn(tb1, '▶  Start Capture', self._start_capture,
                                    '#38f0a8', '#062a1a', '#0a4028')
        self._start_btn.pack(side='left', padx=2)
        self._stop_btn = self._btn(tb1, '◼  Stop', self._stop_capture,
                                   '#ff6b6b', '#200808', '#3a1010')
        self._stop_btn.pack(side='left', padx=2)
        self._stop_btn.config(state='disabled')
        self._btn(tb1, '⊘  Clear', self._clear,
                  '#a371f7', '#100820', '#1e1040').pack(side='left', padx=2)

        tk.Frame(tb1, bg=self._SPIN, width=1, height=26).pack(side='left', padx=8)
        self._btn(tb1, '📂  Open PCAP', self._open_pcap,
                  self._TICK, '#0a1820', '#142030').pack(side='left', padx=2)
        self._btn(tb1, '💾  Save PCAP', self._save_pcap,
                  self._TICK, '#0a1820', '#142030').pack(side='left', padx=2)
        tk.Frame(tb1, bg=self._SPIN, width=1, height=26).pack(side='left', padx=8)
        self._btn(tb1, '❆  AI Query', self._open_ai_query,
                  '#c084fc', '#130820', '#1e1040').pack(side='left', padx=2)
        tk.Frame(tb1, bg=self._SPIN, width=1, height=26).pack(side='left', padx=8)

        self._scroll_var = tk.BooleanVar(value=True)
        tk.Checkbutton(tb1, text='Auto-scroll', variable=self._scroll_var,
                       bg='#040c1a', fg=self._TICK, selectcolor='#0a1828',
                       activebackground='#040c1a', activeforeground=self._TEXT,
                       font=('Consolas', 8)).pack(side='left', padx=4)
        self._count_var = tk.StringVar(value='0 packets')
        tk.Label(tb1, textvariable=self._count_var, bg='#040c1a',
                 fg=self._ACC, font=('Consolas', 9, 'bold')).pack(side='right', padx=12)

        tb2 = tk.Frame(r, bg='#040c1a', pady=4)
        tb2.pack(fill='x', padx=4)
        tk.Label(tb2, text='Display Filter:', bg='#040c1a', fg=self._TICK,
                 font=('Consolas', 9)).pack(side='left', padx=(8, 4))
        self._dfilt_var   = tk.StringVar()
        self._dfilt_entry = self._entry(tb2, self._dfilt_var, 50)
        self._dfilt_entry.pack(side='left', padx=(0, 4), ipady=3)
        self._dfilt_entry.bind('<Return>', lambda e: self._apply_display_filter())
        self._btn(tb2, 'Apply', self._apply_display_filter,
                  self._ACC, '#062040', '#0a3a60').pack(side='left', padx=2)
        self._btn(tb2, '✕ Clear',
                  lambda: (self._dfilt_var.set(''), self._apply_display_filter()),
                  self._TICK, '#0a1820', '#142030').pack(side='left', padx=2)
        tk.Label(tb2, text='   Capture Filter (BPF):',
                 bg='#040c1a', fg=self._TICK,
                 font=('Consolas', 9)).pack(side='left', padx=(8, 4))
        self._cfilt_var = tk.StringVar()
        self._entry(tb2, self._cfilt_var, 30,
                    accent='#a371f7').pack(side='left', padx=(0, 4), ipady=3)
        tk.Label(tb2, text='(applied at start)',
                 bg='#040c1a', fg='#2a4060',
                 font=('Consolas', 7)).pack(side='left', padx=2)
        tk.Frame(r, bg=self._SPIN, height=1).pack(fill='x')

        leg = tk.Frame(r, bg='#030810', height=22)
        leg.pack(fill='x'); leg.pack_propagate(False)
        for lbl, key in [('TCP','tcp'),('UDP','udp'),('DNS','dns'),
                          ('HTTP/TLS','tls'),('ICMP','icmp'),('ARP','arp'),('DHCP','dhcp')]:
            col = self.PROTO_COLORS.get(key, self._TEXT)
            tk.Label(leg, text=f'■ {lbl}', bg='#030810', fg=col,
                     font=('Consolas', 7)).pack(side='left', padx=6, pady=3)
        tk.Frame(r, bg=self._SPIN, height=1).pack(fill='x')

        main_pw = tk.PanedWindow(r, orient='vertical', bg=self._BG,
                                  sashwidth=5, sashrelief='flat', handlesize=0)
        main_pw.pack(fill='both', expand=True)

        pf = tk.Frame(main_pw, bg=self._PANEL)
        main_pw.add(pf, height=490)
        cols   = ('no','time','src','dst','proto','len','info')
        hdrs   = ('No.','Time (s)','Source','Destination','Protocol','Len','Info')
        widths = (55, 100, 160, 160, 88, 52, 700)
        self._tree = ttk.Treeview(pf, columns=cols, show='headings',
                                   style='Pkt.Treeview', selectmode='browse')
        for c, h, w in zip(cols, hdrs, widths):
            self._tree.heading(c, text=h, command=lambda cc=c: self._sort_col_click(cc))
            self._tree.column(c, width=w, minwidth=30, stretch=(c == 'info'))
        for proto, color in self.PROTO_COLORS.items():
            self._tree.tag_configure(proto, foreground=color)
        self._tree.tag_configure('even', background='#060f1c')
        self._tree.tag_configure('odd',  background=self._PANEL)
        vsb = ttk.Scrollbar(pf, orient='vertical',   command=self._tree.yview)
        hsb = ttk.Scrollbar(pf, orient='horizontal',  command=self._tree.xview)
        self._tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        vsb.pack(side='right', fill='y'); hsb.pack(side='bottom', fill='x')
        self._tree.pack(fill='both', expand=True)
        self._tree.bind('<<TreeviewSelect>>', self._on_select)
        self._tree.bind('<Button-3>', self._right_click_menu)

        bot_pw = tk.PanedWindow(main_pw, orient='horizontal', bg=self._BG,
                                 sashwidth=5, sashrelief='flat', handlesize=0)
        main_pw.add(bot_pw, height=290)

        df = tk.Frame(bot_pw, bg=self._PANEL)
        bot_pw.add(df, width=700)
        tk.Label(df, text='  Packet Details', bg='#040c1a', fg=self._ACC,
                 font=('Consolas', 9, 'bold')).pack(fill='x', pady=(2, 0))
        self._dtree = ttk.Treeview(df, style='Det.Treeview', show='tree headings')
        self._dtree['columns'] = ('val',)
        self._dtree.heading('#0',  text='Field', anchor='w')
        self._dtree.heading('val', text='Value', anchor='w')
        self._dtree.column('#0',  width=270, minwidth=80)
        self._dtree.column('val', width=400, minwidth=80, stretch=True)
        dvsb = ttk.Scrollbar(df, orient='vertical', command=self._dtree.yview)
        self._dtree.configure(yscrollcommand=dvsb.set)
        dvsb.pack(side='right', fill='y')
        self._dtree.pack(fill='both', expand=True, padx=(4, 0), pady=(0, 4))

        hf = tk.Frame(bot_pw, bg=self._PANEL)
        bot_pw.add(hf)
        tk.Label(hf, text='  Hex Dump', bg='#040c1a', fg=self._ACC,
                 font=('Consolas', 9, 'bold')).pack(fill='x', pady=(2, 0))
        hc = tk.Frame(hf, bg=self._PANEL)
        hc.pack(fill='both', expand=True, padx=4, pady=(0, 4))
        self._hex = tk.Text(hc, bg='#04080e', fg='#74c7ec',
                            font=('Consolas', 8), relief='flat',
                            state='disabled', wrap='none',
                            selectbackground='#0a3060')
        hvsb = ttk.Scrollbar(hc, orient='vertical',   command=self._hex.yview)
        hhsb = ttk.Scrollbar(hc, orient='horizontal',  command=self._hex.xview)
        self._hex.configure(yscrollcommand=hvsb.set, xscrollcommand=hhsb.set)
        hvsb.pack(side='right', fill='y'); hhsb.pack(side='bottom', fill='x')
        self._hex.pack(fill='both', expand=True)
        for tag, fg in [('off','#2a4a6a'),('bytes','#74c7ec'),
                        ('null','#1a2a3a'),('asc','#c8dff0')]:
            self._hex.tag_configure(tag, foreground=fg)

        sb = tk.Frame(r, bg='#020810', height=22)
        sb.pack(fill='x', side='bottom'); sb.pack_propagate(False)
        self._status = tk.StringVar(value='Ready — select an interface and click ▶ Start Capture')
        tk.Label(sb, textvariable=self._status, bg='#020810', fg=self._TICK,
                 font=('Consolas', 8), anchor='w').pack(side='left', padx=8, pady=2)
        self._stats_var = tk.StringVar(value='')
        tk.Label(sb, textvariable=self._stats_var, bg='#020810', fg=self._ACC,
                 font=('Consolas', 8, 'bold')).pack(side='right', padx=12)

    def _load_interfaces(self):
        def _worker():
            flags = subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0
            try:
                rv = subprocess.run([self.TSHARK, '--version'],
                                    capture_output=True, text=True, timeout=6, creationflags=flags)
                ver = rv.stdout.splitlines()[0] if rv.stdout else ''
                self.root.after(0, lambda: self._ver_var.set(ver))
                rd = subprocess.run([self.TSHARK, '-D'],
                                    capture_output=True, text=True, timeout=8, creationflags=flags)
                ifaces = []
                for line in rd.stdout.splitlines():
                    m = re.match(r'^(\d+)\.\s+(.+)$', line.strip())
                    if m:
                        num  = m.group(1); raw = m.group(2).strip()
                        name = self._friendly_name(raw, int(num))
                        ifaces.append((num, raw, name))
                def _upd():
                    self._interfaces = ifaces
                    self._iface_cb['values'] = [f'{n}. {name}' for n, _, name in ifaces]
                    if ifaces: self._iface_cb.current(0)
                    self._status.set(
                        f'Found {len(ifaces)} interface(s)' if ifaces else
                        '⚠  No interfaces found — is npcap installed?')
                self.root.after(0, _upd)
            except FileNotFoundError:
                self.root.after(0, lambda: self._status.set(
                    f'⚠  tshark.exe not found at {self.TSHARK}  —  update in ⚙ Settings'))
            except Exception as ex:
                self.root.after(0, lambda: self._status.set(f'⚠  {ex}'))
        threading.Thread(target=_worker, daemon=True).start()

    def _start_capture(self):
        if self._capturing or not self._interfaces: return
        sel = self._iface_cb.current()
        if sel < 0: return
        iface_num = self._interfaces[sel][0]
        cmd = [self.TSHARK, '-i', iface_num, '-l', '-n',
               '-T', 'fields',
               '-e', 'frame.number',    '-e', 'frame.time_relative',
               '-e', 'ip.src',          '-e', 'ip.dst',
               '-e', 'ipv6.src',        '-e', 'ipv6.dst',
               '-e', 'eth.src',         '-e', 'eth.dst',
               '-e', 'frame.protocols', '-e', 'frame.len',
               '-e', '_ws.col.Info',
               '-E', 'separator=\t', '-E', 'quote=n', '-E', 'occurrence=f',
               '-w', str(self._capfile)]
        cf = self._cfilt_var.get().strip()
        if cf: cmd += ['-f', cf]
        flags = subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0
        try:
            self._cap_proc = subprocess.Popen(cmd, stdout=subprocess.PIPE,
                stderr=subprocess.PIPE, text=True, creationflags=flags)
        except FileNotFoundError:
            self._status.set(f'⚠  tshark not found: {self.TSHARK}  —  update in ⚙ Settings')
            return
        except Exception as ex:
            self._status.set(f'⚠  {ex}'); return
        self._capturing = True; self._pkt_count = 0
        self._all_pkts = []; self._pkt_queue = []
        self._start_btn.config(state='disabled')
        self._stop_btn.config(state='normal')
        friendly = self._interfaces[sel][2]
        self._status.set(f'◎  Capturing on {friendly}…')
        threading.Thread(target=self._capture_loop, daemon=True).start()
        self._ui_drain_tick()

    def _capture_loop(self):
        try:
            for raw in self._cap_proc.stdout:
                if not self._capturing: break
                line = raw.rstrip('\n')
                if not line: continue
                parts = line.split('\t')
                while len(parts) < 11: parts.append('')
                no   = parts[0] or str(self._pkt_count + 1)
                t    = parts[1]
                src  = parts[2] or parts[4] or parts[6] or '—'
                dst  = parts[3] or parts[5] or parts[7] or '—'
                proto = parts[8].lower(); length = parts[9]; info = parts[10]
                ptag  = self._proto_tag(proto)
                self._pkt_count += 1
                pkt = (no, f'{float(t):.6f}' if t else '?', src, dst,
                       ptag.upper(), length, info)
                self._all_pkts.append((pkt, ptag))
                if len(self._all_pkts) > 50000:
                    self._all_pkts = self._all_pkts[-40000:]
                self._pkt_queue.append((pkt, ptag))
        except Exception:
            pass
        finally:
            self.root.after(0, self._on_ended)

    def _ui_drain_tick(self):
        BATCH_SIZE = 150; DRAIN_MS = 100; MAX_ROWS = 20000
        if not self._capturing:
            self._drain_queue(MAX_ROWS); return
        self._drain_queue(MAX_ROWS, limit=BATCH_SIZE)
        self.root.after(DRAIN_MS, self._ui_drain_tick)

    def _drain_queue(self, max_rows, limit=None):
        batch = self._pkt_queue[:limit] if limit else self._pkt_queue[:]
        if limit: del self._pkt_queue[:limit]
        else: self._pkt_queue.clear()
        if not batch: return
        children = self._tree.get_children()
        overflow = len(children) + len(batch) - max_rows
        if overflow > 0: self._tree.delete(*children[:overflow])
        for pkt, ptag in batch:
            count = int(pkt[0]) if pkt[0].isdigit() else len(self._packets) + 1
            tag   = 'even' if count % 2 == 0 else 'odd'
            self._tree.insert('', 'end', values=pkt, tags=(ptag, tag))
            self._packets.append(pkt)
        n = self._pkt_count
        self._count_var.set(f'{n:,} packet{"s" if n != 1 else ""}')
        if self._scroll_var.get():
            ch = self._tree.get_children()
            if ch: self._tree.see(ch[-1])

    def _proto_tag(self, protos):
        if not protos: return 'other'
        parts = set(protos.split(':'))
        for p in self.PROTO_PRIORITY:
            if p in parts: return p
        return 'other'

    def _stop_capture(self):
        self._capturing = False
        if self._cap_proc:
            try: self._cap_proc.terminate()
            except Exception: pass
            self._cap_proc = None

    def _on_ended(self):
        self._capturing = False
        self._start_btn.config(state='normal')
        self._stop_btn.config(state='disabled')
        n = self._pkt_count
        self._status.set(
            f'Capture stopped — {n} packet{"s" if n != 1 else ""} recorded'
            + ('  |  pcap saved' if self._capfile.exists() else ''))

    def _on_select(self, _event):
        sel = self._tree.selection()
        if not sel: return
        vals = self._tree.item(sel[0], 'values')
        if not vals: return
        threading.Thread(target=self._fetch_detail, args=(vals[0],), daemon=True).start()

    def _fetch_detail(self, pkt_no):
        if not self._capfile.exists(): return
        try: pkt_no = str(int(pkt_no))
        except (ValueError, TypeError): return
        flags = subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0
        filt  = f'frame.number == {pkt_no}'
        try:
            rv = subprocess.run([self.TSHARK, '-r', str(self._capfile), '-Y', filt, '-V', '-n'],
                                capture_output=True, text=True, timeout=12, creationflags=flags)
            detail = rv.stdout
        except Exception as ex: detail = f'Error: {ex}'
        try:
            rh = subprocess.run([self.TSHARK, '-r', str(self._capfile), '-Y', filt, '-x', '-n'],
                                capture_output=True, text=True, timeout=12, creationflags=flags)
            hexdump = rh.stdout
        except Exception as ex: hexdump = f'Error: {ex}'
        self.root.after(0, lambda: self._render_detail(detail, hexdump))

    def _render_detail(self, detail_text, hex_text):
        self._dtree.delete(*self._dtree.get_children())
        node_stack = ['']
        for line in detail_text.splitlines():
            if not line.strip(): continue
            stripped = line.lstrip(' ')
            indent   = (len(line) - len(stripped)) // 4
            key, _, val = stripped.partition(':')
            key = key.strip(); val = val.strip()
            while len(node_stack) > indent + 1: node_stack.pop()
            iid = self._dtree.insert(node_stack[-1], 'end', text=key, values=(val,), open=(indent < 2))
            node_stack.append(iid)
        self._hex.config(state='normal'); self._hex.delete('1.0', 'end')
        for line in hex_text.splitlines():
            if not line.strip(): self._hex.insert('end', '\n'); continue
            m = re.match(r'^([0-9a-f]+)\s{2}([\s0-9a-f]+?)\s{2,}(.*)$', line, re.IGNORECASE)
            if m:
                self._hex.insert('end', f'{m.group(1)}  ', 'off')
                for tok in m.group(2).split():
                    self._hex.insert('end', f'{tok} ', 'null' if tok == '00' else 'bytes')
                self._hex.insert('end', f'  {m.group(3)}\n', 'asc')
            else:
                self._hex.insert('end', line + '\n')
        self._hex.config(state='disabled')

    def _right_click_menu(self, event):
        sel = self._tree.identify_row(event.y)
        if not sel: return
        self._tree.selection_set(sel)
        vals = self._tree.item(sel, 'values')
        menu = self._tk.Menu(self.root, tearoff=0, bg='#040c1a', fg=self._TEXT,
                             activebackground='#0a3060', activeforeground='white',
                             font=('Consolas', 9))
        menu.add_command(label='Follow TCP Stream', command=lambda: self._follow_stream('tcp'))
        menu.add_command(label='Follow UDP Stream', command=lambda: self._follow_stream('udp'))
        menu.add_separator()
        menu.add_command(label='Copy Source IP', command=lambda: self._copy(vals[2] if vals else ''))
        menu.add_command(label='Copy Dest IP',   command=lambda: self._copy(vals[3] if vals else ''))
        menu.add_command(label='Copy Info',      command=lambda: self._copy(vals[6] if vals else ''))
        menu.add_separator()
        menu.add_command(label='Filter by Source',   command=lambda: self._quick_filter('ip.src', vals[2] if vals else ''))
        menu.add_command(label='Filter by Dest',     command=lambda: self._quick_filter('ip.dst', vals[3] if vals else ''))
        menu.add_command(label='Filter by Protocol', command=lambda: self._quick_filter('', vals[4].lower() if vals else ''))
        try: menu.tk_popup(event.x_root, event.y_root)
        finally: menu.grab_release()

    def _copy(self, text):
        self.root.clipboard_clear(); self.root.clipboard_append(text)

    def _quick_filter(self, field, value):
        if not value or value == '—': return
        self._dfilt_var.set(f'{field} == {value}' if field else value)
        self._apply_display_filter()

    def _apply_display_filter(self):
        if not self._need_file(): return
        filt = self._dfilt_var.get().strip()
        self._status.set('Applying filter…')
        threading.Thread(target=self._run_display_filter, args=(filt,), daemon=True).start()

    def _run_display_filter(self, filt):
        flags = subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0
        cmd = [self.TSHARK, '-r', str(self._capfile), '-n', '-T', 'fields',
               '-e', 'frame.number',    '-e', 'frame.time_relative',
               '-e', 'ip.src',          '-e', 'ip.dst',
               '-e', 'ipv6.src',        '-e', 'ipv6.dst',
               '-e', 'eth.src',         '-e', 'eth.dst',
               '-e', 'frame.protocols', '-e', 'frame.len',
               '-e', '_ws.col.Info',
               '-E', 'separator=\t', '-E', 'quote=n', '-E', 'occurrence=f']
        if filt: cmd += ['-Y', filt]
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=30, creationflags=flags)
            rows = self._parse_fields(r.stdout); ok = True
        except Exception as ex:
            rows = []; ok = False
            self.root.after(0, lambda: self._status.set(f'⚠  Filter error: {ex}'))
        if ok:
            msg = (f'Filter "{filt}" — {len(rows)} match{"es" if len(rows)!=1 else ""}'
                   if filt else f'All {len(rows)} packets')
            self.root.after(0, lambda: self._replace_packets(rows, msg))
            hi = '#1a4020' if ok else '#401020'
            self.root.after(0, lambda: self._dfilt_entry.config(
                highlightbackground=hi, highlightcolor='#38f0a8' if ok else '#ff6b6b'))

    def _parse_fields(self, stdout):
        rows = []
        for i, raw in enumerate(stdout.splitlines()):
            if not raw.strip(): continue
            p = raw.split('\t')
            while len(p) < 11: p.append('')
            no   = p[0] or str(i + 1); t = p[1]
            src  = p[2] or p[4] or p[6] or '—'
            dst  = p[3] or p[5] or p[7] or '—'
            ptag = self._proto_tag(p[8].lower())
            rows.append((no, f'{float(t):.6f}' if t else '?',
                         src, dst, ptag.upper(), p[9], p[10], ptag))
        return rows

    def _replace_packets(self, rows, msg):
        self._tree.delete(*self._tree.get_children()); self._packets = []
        for i, row in enumerate(rows):
            pkt  = row[:7]; ptag = row[7] if len(row) > 7 else 'other'
            tag  = 'even' if i % 2 == 0 else 'odd'
            self._tree.insert('', 'end', values=pkt, tags=(ptag, tag))
            self._packets.append(pkt)
        self._pkt_count = len(rows)
        self._count_var.set(f'{self._pkt_count} packet{"s" if self._pkt_count != 1 else ""}')
        self._status.set(msg)

    def _open_pcap(self):
        path = self._fd.askopenfilename(title='Open PCAP File',
            filetypes=[('PCAP/PCAPNG', '*.pcap *.pcapng *.cap'), ('All files', '*.*')])
        if not path: return
        import shutil; shutil.copy2(path, str(self._capfile))
        self._clear(keep_file=True); self._status.set(f'Loading {Path(path).name}…')
        threading.Thread(target=self._reload_from_file, daemon=True).start()

    def _save_pcap(self):
        if not self._need_file(): return
        path = self._fd.asksaveasfilename(title='Save Capture As',
            defaultextension='.pcap', filetypes=[('PCAP','*.pcap'),('PCAPNG','*.pcapng')])
        if not path: return
        import shutil; shutil.copy2(str(self._capfile), path)
        self._status.set(f'Saved → {Path(path).name}')

    def _reload_from_file(self):
        flags = subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0
        try:
            r = subprocess.run(
                [self.TSHARK, '-r', str(self._capfile), '-n', '-T', 'fields',
                 '-e', 'frame.number',    '-e', 'frame.time_relative',
                 '-e', 'ip.src',          '-e', 'ip.dst',
                 '-e', 'ipv6.src',        '-e', 'ipv6.dst',
                 '-e', 'eth.src',         '-e', 'eth.dst',
                 '-e', 'frame.protocols', '-e', 'frame.len',
                 '-e', '_ws.col.Info',
                 '-E', 'separator=\t', '-E', 'quote=n', '-E', 'occurrence=f'],
                capture_output=True, text=True, timeout=60, creationflags=flags)
            rows = self._parse_fields(r.stdout)
            self.root.after(0, lambda: self._replace_packets(rows, f'Loaded {len(rows)} packets'))
        except Exception as ex:
            self.root.after(0, lambda: self._status.set(f'⚠  {ex}'))

    def _clear(self, keep_file=False):
        self._tree.delete(*self._tree.get_children())
        self._dtree.delete(*self._dtree.get_children())
        self._hex.config(state='normal'); self._hex.delete('1.0', 'end')
        self._hex.config(state='disabled')
        self._packets = []; self._all_pkts = []; self._pkt_queue = []
        self._pkt_count = 0; self._count_var.set('0 packets')
        if not keep_file and self._capfile.exists():
            try: self._capfile.unlink()
            except Exception: pass
        self._status.set('Cleared')

    def _sort_col_click(self, col):
        numeric = col in ('no', 'len', 'time')
        items   = [(self._tree.item(i, 'values'), i) for i in self._tree.get_children()]
        rev     = (self._sort_col == col and not self._sort_rev)
        idx     = ('no','time','src','dst','proto','len','info').index(col)
        def _key(x):
            v = x[0][idx]
            if numeric:
                try: return float(v)
                except Exception: return 0.0
            return v.lower()
        items.sort(key=_key, reverse=rev)
        for i, (_, iid) in enumerate(items): self._tree.move(iid, '', i)
        self._sort_col = col; self._sort_rev = rev

    def _follow_stream(self, proto):
        if not self._need_file(): return
        sel = self._tree.selection()
        if not sel:
            self._mb.showinfo('Follow Stream', 'Select a packet first.', parent=self.root); return
        vals = self._tree.item(sel[0], 'values')
        try: pkt_no = str(int(vals[0]))
        except (ValueError, TypeError): return
        self._status.set(f'Following {proto.upper()} stream…')
        def _worker():
            flags = subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0
            try:
                idx_field = {'tcp':'tcp.stream','udp':'udp.stream','tls':'tcp.stream'}.get(proto,'tcp.stream')
                ri = subprocess.run([self.TSHARK,'-r',str(self._capfile),'-n',
                                     '-Y',f'frame.number == {pkt_no}',
                                     '-T','fields','-e',idx_field,'-E','occurrence=f'],
                                    capture_output=True, text=True, timeout=10, creationflags=flags)
                stream_idx = ri.stdout.strip() or '0'
            except Exception: stream_idx = '0'
            follow_type = {'tcp':'tcp,ascii','udp':'udp,ascii','tls':'tls,ascii'}.get(proto,'tcp,ascii')
            try:
                rs = subprocess.run([self.TSHARK,'-r',str(self._capfile),'-n','-q',
                                     '-z',f'follow,{follow_type},{stream_idx}'],
                                    capture_output=True, text=True, timeout=20, creationflags=flags)
                content = rs.stdout or rs.stderr or '(no data)'
            except Exception as ex: content = f'Error: {ex}'
            self.root.after(0, lambda: self._show_stream_window(proto, stream_idx, content))
        threading.Thread(target=_worker, daemon=True).start()

    def _show_stream_window(self, proto, idx, content):
        win = self._stat_window(f'Follow {proto.upper()} Stream — index {idx}', 900, 600)
        self._status.set('Ready')
        fc = self._tk.Frame(win, bg=self._PANEL)
        fc.pack(fill='both', expand=True, padx=6, pady=6)
        txt = self._tk.Text(fc, bg='#04080e', fg='#c8dff0', font=('Consolas', 9),
                            relief='flat', wrap='none', selectbackground='#0a3060')
        vsb = self._ttk.Scrollbar(fc, orient='vertical',   command=txt.yview)
        hsb = self._ttk.Scrollbar(fc, orient='horizontal',  command=txt.xview)
        txt.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        vsb.pack(side='right', fill='y'); hsb.pack(side='bottom', fill='x')
        txt.pack(fill='both', expand=True)
        txt.tag_configure('client', foreground='#00d4aa')
        txt.tag_configure('server', foreground='#a371f7')
        in_client = True
        for line in content.splitlines():
            if '====' in line: in_client = not in_client
            txt.insert('end', line + '\n', 'client' if in_client else 'server')
        txt.config(state='disabled')
        btn_f = self._tk.Frame(win, bg='#020810')
        btn_f.pack(fill='x', padx=6, pady=4)
        self._btn(btn_f, '📋  Copy All', lambda: self._copy(content),
                  self._ACC, '#062040', '#0a3a60').pack(side='left', padx=4)
        self._btn(btn_f, 'Close', win.destroy,
                  self._TICK, '#0a1820', '#142030').pack(side='right', padx=4)

    def _show_expert_info(self):
        if not self._need_file(): return
        self._status.set('Running expert analysis…')
        def _worker():
            flags = subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0
            try:
                r = subprocess.run([self.TSHARK,'-r',str(self._capfile),'-n','-q','-z','expert,'],
                                   capture_output=True, text=True, timeout=30, creationflags=flags)
                out = r.stdout or '(no expert items)'
            except Exception as ex: out = f'Error: {ex}'
            self.root.after(0, lambda: self._render_expert(out))
        threading.Thread(target=_worker, daemon=True).start()

    def _render_expert(self, text):
        self._status.set('Ready')
        win  = self._stat_window('Expert Information', 1000, 560)
        cols = ('sev','group','proto','summary')
        hdrs = ('Severity','Group','Protocol','Summary')
        wids = (90, 100, 90, 680)
        tv   = self._stat_tree(win, cols, hdrs, wids)
        for sev, col in [('Error','#ff6b6b'),('Warning','#ffd93d'),
                         ('Note','#38b8f0'),('Chat','#c8dff0'),('Comment','#6a9ab8')]:
            tv.tag_configure(sev.lower(), foreground=col)
        count = {'Error': 0, 'Warning': 0, 'Note': 0, 'Chat': 0}
        for line in text.splitlines():
            line = line.strip()
            if not line or '==' in line or line.startswith('Expert'): continue
            parts = re.split(r'\s{2,}|\t', line, maxsplit=3)
            while len(parts) < 4: parts.append('')
            sev = parts[0].strip()
            if sev in count: count[sev] += 1
            tv.insert('', 'end', values=tuple(p.strip() for p in parts), tags=(sev.lower(),))
        sb = self._tk.Frame(win, bg='#020810'); sb.pack(fill='x', padx=6, pady=4)
        summary = '  '.join(f'{sev}: {n}' for sev, n in count.items() if n)
        self._tk.Label(sb, text=summary or 'No expert items', bg='#020810',
                       fg=self._ACC, font=('Consolas', 9, 'bold')).pack(side='left', padx=8)

    def _decode_as(self):
        win = self._stat_window('Decode As', 500, 240)
        frm = self._tk.Frame(win, bg=self._BG)
        frm.pack(fill='both', expand=True, padx=20, pady=12)
        for row, (lbl, choices, default) in enumerate([
            ('Transport:', ['TCP','UDP'], 'TCP'), ('Port:', None, ''),
            ('Decode as:', ['HTTP','TLS','DNS','SMTP','FTP','IMAP','POP','SIP','RTP','CUSTOM'], 'HTTP'),
        ]):
            self._tk.Label(frm, text=lbl, bg=self._BG, fg=self._TICK,
                           font=('Consolas',9), width=14, anchor='w').grid(row=row, column=0, pady=6, sticky='w')
            if choices:
                var = self._tk.StringVar(value=default)
                cb  = self._ttk.Combobox(frm, textvariable=var, values=choices,
                                          state='readonly', width=20, font=('Consolas',9))
                cb.grid(row=row, column=1, padx=8, pady=6, sticky='w')
                if row == 0: self._da_trans = var
                else:        self._da_proto = var
            else:
                self._da_port = self._tk.StringVar(value=default)
                self._entry(frm, self._da_port, 10).grid(row=row, column=1, padx=8, pady=6, sticky='w')
        def _apply():
            trans = self._da_trans.get().lower(); port = self._da_port.get().strip()
            proto = self._da_proto.get().lower()
            if not port.isdigit() or not (1 <= int(port) <= 65535):
                self._mb.showerror('Decode As', 'Port must be 1–65535.', parent=win); return
            self._dfilt_var.set(f'{trans}.port == {port}'); win.destroy()
            self._status.set(f'Decoding {trans.upper()} port {port} as {proto.upper()}')
            self._apply_display_filter()
        bf = self._tk.Frame(win, bg='#020810'); bf.pack(fill='x', padx=6, pady=4)
        self._btn(bf,'Apply',_apply,self._ACC,'#062040','#0a3a60').pack(side='left',padx=6)
        self._btn(bf,'Cancel',win.destroy,self._TICK,'#0a1820','#142030').pack(side='left')

    def _show_packet_bytes(self):
        if not self._need_file(): return
        sel = self._tree.selection()
        if not sel:
            self._mb.showinfo('Packet Bytes','Select a packet first.',parent=self.root); return
        self._hex.see('1.0')
        self._mb.showinfo('Packet Bytes','Hex dump is shown in the lower-right panel.',parent=self.root)

    def _show_summary(self):
        if not self._need_file(): return
        def _worker():
            flags = subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0
            try:
                r = subprocess.run([self.TSHARK,'-r',str(self._capfile),'-q','-z','io,stat,0'],
                                   capture_output=True, text=True, timeout=20, creationflags=flags)
                out = r.stdout
            except Exception as ex: out = f'Error: {ex}'
            self.root.after(0, lambda: self._render_summary(out))
        threading.Thread(target=_worker, daemon=True).start()

    def _render_summary(self, text):
        win = self._stat_window('Capture File Summary', 680, 420)
        fc = self._tk.Frame(win, bg=self._PANEL); fc.pack(fill='both', expand=True, padx=8, pady=8)
        txt = self._tk.Text(fc, bg='#04080e', fg=self._TEXT, font=('Consolas',9),
                            relief='flat', wrap='word', state='normal')
        txt.pack(fill='both', expand=True)
        txt.tag_configure('head',  foreground=self._ACC, font=('Consolas',10,'bold'))
        txt.tag_configure('label', foreground=self._TICK)
        txt.tag_configure('val',   foreground=self._TEXT)
        n = self._pkt_count; size = self._capfile.stat().st_size if self._capfile.exists() else 0
        txt.insert('end', f'File: {self._capfile}\n', 'head')
        txt.insert('end', 'Size:         ', 'label'); txt.insert('end', f'{size:,} bytes\n', 'val')
        txt.insert('end', 'Packets:      ', 'label'); txt.insert('end', f'{n:,}\n', 'val')
        if self._packets:
            try:
                t0 = float(self._packets[0][1]); t1 = float(self._packets[-1][1]); dur = t1 - t0
                txt.insert('end', 'Duration:     ', 'label'); txt.insert('end', f'{dur:.3f} s\n', 'val')
                if dur > 0:
                    txt.insert('end', 'Avg rate:     ', 'label')
                    txt.insert('end', f'{n/dur:.1f} pkt/s\n', 'val')
            except Exception: pass
        txt.insert('end', '\n─── tshark io,stat ───\n', 'head')
        txt.insert('end', text); txt.config(state='disabled')

    def _show_proto_hierarchy(self):
        if not self._need_file(): return
        self._status.set('Building protocol hierarchy…')
        def _worker():
            flags = subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0
            try:
                r = subprocess.run([self.TSHARK,'-r',str(self._capfile),'-n','-q','-z','io,phs,'],
                                   capture_output=True, text=True, timeout=30, creationflags=flags)
                out = r.stdout
            except Exception as ex: out = f'Error: {ex}'
            self.root.after(0, lambda: self._render_proto_hier(out))
        threading.Thread(target=_worker, daemon=True).start()

    def _render_proto_hier(self, text):
        self._status.set('Ready')
        win  = self._stat_window('Protocol Hierarchy', 900, 500)
        cols = ('proto','pkts','pct','bytes','bpct','mbit')
        hdrs = ('Protocol','Packets','%','Bytes','% Bytes','Mbit/s')
        wids = (320, 80, 70, 90, 80, 80)
        tv   = self._stat_tree(win, cols, hdrs, wids)
        for proto, col in self.PROTO_COLORS.items():
            tv.tag_configure(proto, foreground=col)
        for line in text.splitlines():
            if not line.strip() or '===' in line or 'Protocol' in line: continue
            stripped = line.lstrip(' '); indent = (len(line) - len(stripped)) // 2
            m = re.match(r'(\S+)\s+frames:\s*([\d]+)\s+bytes:\s*([\d]+)', stripped)
            if m:
                tv.insert('', 'end',
                          values=('  '*indent+m.group(1), m.group(2), '', m.group(3), '', ''),
                          tags=(self._proto_tag(m.group(1).lower()),))

    def _show_conversations(self, layer):
        if not self._need_file(): return
        self._status.set(f'Computing {layer.upper()} conversations…')
        def _worker():
            flags = subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0
            try:
                r = subprocess.run([self.TSHARK,'-r',str(self._capfile),'-n','-q','-z',f'conv,{layer}'],
                                   capture_output=True, text=True, timeout=30, creationflags=flags)
                out = r.stdout
            except Exception as ex: out = f'Error: {ex}'
            self.root.after(0, lambda: self._render_conv(layer, out))
        threading.Thread(target=_worker, daemon=True).start()

    def _render_conv(self, layer, text):
        self._status.set('Ready')
        win  = self._stat_window(f'Conversations — {layer.upper()}', 1100, 460)
        cols = ('a','b','pkts_ab','bytes_ab','pkts_ba','bytes_ba','total_pkts','total_bytes','start','dur')
        hdrs = ('Address A','Address B','Pkts A→B','Bytes A→B',
                'Pkts B→A','Bytes B→A','Total Pkts','Total Bytes','Start','Duration')
        wids = (180,180,80,90,80,90,80,90,80,80)
        tv   = self._stat_tree(win, cols, hdrs, wids)
        tv.tag_configure('odd',  background='#060f1c')
        tv.tag_configure('even', background=self._PANEL)
        row_i = 0
        for line in text.splitlines():
            line = line.strip()
            if not line or '<->' not in line or '==' in line or 'Address' in line: continue
            parts = re.split(r'\s{2,}|\t', line)
            while len(parts) < 10: parts.append('')
            tv.insert('', 'end', values=tuple(p.strip() for p in parts[:10]),
                      tags=('odd' if row_i%2 else 'even',)); row_i += 1

    def _show_endpoints(self, layer):
        if not self._need_file(): return
        self._status.set(f'Computing {layer.upper()} endpoints…')
        def _worker():
            flags = subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0
            try:
                r = subprocess.run([self.TSHARK,'-r',str(self._capfile),'-n','-q','-z',f'endpoints,{layer}'],
                                   capture_output=True, text=True, timeout=30, creationflags=flags)
                out = r.stdout
            except Exception as ex: out = f'Error: {ex}'
            self.root.after(0, lambda: self._render_endpoints(layer, out))
        threading.Thread(target=_worker, daemon=True).start()

    def _render_endpoints(self, layer, text):
        self._status.set('Ready')
        win  = self._stat_window(f'Endpoints — {layer.upper()}', 860, 440)
        cols = ('addr','pkts','bytes','pkts_tx','bytes_tx','pkts_rx','bytes_rx')
        hdrs = ('Address','Packets','Bytes','Tx Pkts','Tx Bytes','Rx Pkts','Rx Bytes')
        wids = (220,80,100,80,100,80,100)
        tv   = self._stat_tree(win, cols, hdrs, wids)
        tv.tag_configure('odd',  background='#060f1c')
        tv.tag_configure('even', background=self._PANEL)
        row_i = 0
        for line in text.splitlines():
            line = line.strip()
            if not line or '==' in line or 'Address' in line: continue
            parts = re.split(r'\s{2,}|\t', line)
            while len(parts) < 7: parts.append('')
            tv.insert('', 'end', values=tuple(p.strip() for p in parts[:7]),
                      tags=('odd' if row_i%2 else 'even',)); row_i += 1

    def _show_io_graph(self):
        if not self._need_file(): return
        self._status.set('Building I/O graph…')
        def _worker():
            flags = subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0
            try:
                r = subprocess.run([self.TSHARK,'-r',str(self._capfile),'-n','-q','-z','io,stat,1'],
                                   capture_output=True, text=True, timeout=30, creationflags=flags)
                out = r.stdout
            except Exception: out = ''
            self.root.after(0, lambda: self._render_io_graph(out))
        threading.Thread(target=_worker, daemon=True).start()

    def _render_io_graph(self, text):
        self._status.set('Ready')
        times, pkts, byts = [], [], []
        for line in text.splitlines():
            m = re.search(r'\|\s*([\d.]+)\s*<>\s*[\d.]+\s*\|\s*([\d]+)\s*\|\s*([\d]+)', line)
            if m:
                times.append(float(m.group(1))); pkts.append(int(m.group(2))); byts.append(int(m.group(3)))
        win = self._stat_window('I/O Graph', 1000, 560)
        if not times:
            self._tk.Label(win, text='Not enough data.\nCapture more traffic and retry.',
                           bg=self._BG, fg=self._TICK, font=('Consolas',11)).pack(expand=True); return
        from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
        import matplotlib.figure as _mf
        fig = _mf.Figure(figsize=(11,6), facecolor=self._BG)
        ax1, ax2 = fig.subplots(2, 1, sharex=True)
        fig.subplots_adjust(hspace=0.08, left=0.07, right=0.97, top=0.93, bottom=0.09)
        for ax, data, col, lbl, unit in [
            (ax1, byts, self._ACC, 'Throughput', 'Bytes/s'),
            (ax2, pkts, '#a371f7', 'Packet Rate','Pkts/s'),
        ]:
            ax.set_facecolor(PANEL_BG)
            ax.fill_between(times, data, alpha=0.18, color=col)
            for lw, aa in [(10,0.04),(5,0.10),(2,0.28)]:
                ax.plot(times, data, color=col, lw=lw, alpha=aa)
            ax.plot(times, data, color=col, lw=1.4, alpha=0.95)
            ax.set_ylabel(unit, color=TICK_COL, fontsize=8)
            ax.yaxis.grid(True, color='#1a2535', lw=0.7, alpha=0.9)
            ax.tick_params(colors=TICK_COL, labelsize=8)
            for sp in ax.spines.values(): sp.set_color(SPIN_COL)
            ax.set_title(lbl, loc='left', color=TEXT_COL, fontsize=9, fontweight='bold')
        ax2.set_xlabel('Time (s)', color=TICK_COL, fontsize=8)
        fig.suptitle('I/O Graph', color=TEXT_COL, fontsize=11, fontweight='bold')
        canvas = FigureCanvasTkAgg(fig, master=win)
        canvas.draw(); canvas.get_tk_widget().pack(fill='both', expand=True, padx=6, pady=6)

    def _show_packet_lengths(self):
        if not self._need_file(): return
        self._status.set('Analysing packet lengths…')
        def _worker():
            flags = subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0
            try:
                r = subprocess.run([self.TSHARK,'-r',str(self._capfile),'-n','-q','-z','plen,tree'],
                                   capture_output=True, text=True, timeout=30, creationflags=flags)
                out = r.stdout
            except Exception as ex: out = f'Error: {ex}'
            self.root.after(0, lambda: self._render_pkt_lengths(out))
        threading.Thread(target=_worker, daemon=True).start()

    def _render_pkt_lengths(self, text):
        self._status.set('Ready')
        win  = self._stat_window('Packet Lengths', 820, 440)
        cols = ('range','count','pct','bytes','bpct','burst')
        hdrs = ('Length Range','Count','%','Bytes','% Bytes','Burst Rate')
        wids = (160,80,70,100,80,100)
        tv   = self._stat_tree(win, cols, hdrs, wids)
        tv.tag_configure('odd',  background='#060f1c')
        tv.tag_configure('even', background=self._PANEL)
        row_i = 0
        for line in text.splitlines():
            line = line.strip()
            if not line or '==' in line or 'Packet Lengths' in line: continue
            parts = re.split(r'\s{2,}|\t', line)
            while len(parts) < 6: parts.append('')
            tv.insert('', 'end', values=tuple(p.strip() for p in parts[:6]),
                      tags=('odd' if row_i%2 else 'even',)); row_i += 1


    def _show_dns_stats(self):
        if not self._need_file():
            return
        self._status.set('Computing DNS statistics...')
        def _worker():
            flags = subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0
            try:
                r = subprocess.run(
                    [self.TSHARK, '-r', str(self._capfile), '-n', '-q',
                     '-z', 'dns,tree'],
                    capture_output=True, text=True, timeout=30,
                    creationflags=flags)
                out = r.stdout
            except Exception as ex:
                out = f'Error: {ex}'
            self.root.after(0, lambda: self._render_text_stat('DNS Statistics', out))
        threading.Thread(target=_worker, daemon=True).start()

    def _show_http_stats(self):
        if not self._need_file():
            return
        self._status.set('Computing HTTP statistics...')
        def _worker():
            flags = subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0
            try:
                r = subprocess.run(
                    [self.TSHARK, '-r', str(self._capfile), '-n', '-q',
                     '-z', 'http,tree'],
                    capture_output=True, text=True, timeout=30,
                    creationflags=flags)
                out = r.stdout
            except Exception as ex:
                out = f'Error: {ex}'
            self.root.after(0, lambda: self._render_text_stat('HTTP Statistics', out))
        threading.Thread(target=_worker, daemon=True).start()

    def _render_text_stat(self, title, text):
        self._status.set('Ready')
        win = self._stat_window(title, 800, 500)
        fc  = self._tk.Frame(win, bg=self._PANEL)
        fc.pack(fill='both', expand=True, padx=8, pady=8)
        txt = self._tk.Text(fc, bg='#04080e', fg=self._TEXT,
                            font=('Consolas', 9), relief='flat',
                            wrap='none', state='normal')
        vsb = self._ttk.Scrollbar(fc, orient='vertical',   command=txt.yview)
        hsb = self._ttk.Scrollbar(fc, orient='horizontal',  command=txt.xview)
        txt.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        vsb.pack(side='right', fill='y')
        hsb.pack(side='bottom', fill='x')
        txt.pack(fill='both', expand=True)
        txt.tag_configure('head', foreground=self._ACC,
                          font=('Consolas', 9, 'bold'))
        for line in text.splitlines():
            tag = 'head' if ('===' in line or re.match(r'^[A-Z]', line.strip())) else ''
            txt.insert('end', line + '\n', tag)
        txt.config(state='disabled')

    # ── AI Query ──────────────────────────────────────────────────────────────
    def _build_capture_context(self):
        lines = []
        pkts  = self._packets
        lines.append(f'Total packets in view: {len(pkts)}')
        if pkts:
            proto_counts = {}
            src_counts   = {}
            dst_counts   = {}
            for row in pkts:
                proto = row[4] if len(row) > 4 else '?'
                src   = row[2] if len(row) > 2 else '?'
                dst   = row[3] if len(row) > 3 else '?'
                proto_counts[proto] = proto_counts.get(proto, 0) + 1
                src_counts[src]     = src_counts.get(src,   0) + 1
                dst_counts[dst]     = dst_counts.get(dst,   0) + 1
            lines.append('\nProtocol breakdown:')
            for p, n in sorted(proto_counts.items(), key=lambda x: -x[1])[:15]:
                lines.append(f'  {p}: {n}')
            lines.append('\nTop source IPs:')
            for ip, n in sorted(src_counts.items(), key=lambda x: -x[1])[:10]:
                lines.append(f'  {ip}: {n} pkts')
            lines.append('\nTop destination IPs:')
            for ip, n in sorted(dst_counts.items(), key=lambda x: -x[1])[:10]:
                lines.append(f'  {ip}: {n} pkts')
            try:
                t0 = float(pkts[0][1]);  t1 = float(pkts[-1][1])
                lines.append(f'\nCapture duration: {t1 - t0:.3f} s')
                if t1 > t0:
                    lines.append(f'Avg packet rate: {len(pkts)/(t1-t0):.1f} pkt/s')
            except Exception:
                pass
            lines.append('\nFirst 40 packets (no, time, src, dst, proto, len, info):')
            for row in pkts[:40]:
                lines.append('  ' + '  |  '.join(str(v) for v in row[:7]))
            if len(pkts) > 60:
                lines.append(f'\nLast 20 packets (of {len(pkts)} total):')
                for row in pkts[-20:]:
                    lines.append('  ' + '  |  '.join(str(v) for v in row[:7]))
        if self._capfile.exists():
            flags = subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0
            for stat_arg, label in [
                ('io,phs,',  'Protocol hierarchy'),
                ('conv,ip',  'IPv4 conversations'),
                ('dns,tree', 'DNS queries'),
            ]:
                try:
                    r = subprocess.run(
                        [self.TSHARK, '-r', str(self._capfile), '-n', '-q', '-z', stat_arg],
                        capture_output=True, text=True, timeout=10, creationflags=flags)
                    out = r.stdout.strip()
                    if out:
                        lines.append(f'\n{label}:\n{out[:1500]}')
                except Exception:
                    pass
        return '\n'.join(lines)

    def _open_ai_query(self):
        tk  = self._tk
        ttk = self._ttk

        win = tk.Toplevel(self.root)
        win.title('AI Capture Analysis')
        win.configure(bg=self._BG)
        win.geometry('960x700')
        win.minsize(700, 500)

        hdr = tk.Frame(win, bg='#0d0520', height=44)
        hdr.pack(fill='x'); hdr.pack_propagate(False)
        tk.Label(hdr, text='\u2746  AI Capture Analysis',
                 bg='#0d0520', fg='#c084fc',
                 font=('Consolas', 13, 'bold')).pack(side='left', padx=16, pady=8)
        tk.Label(hdr, text='Ask anything about this capture in plain English',
                 bg='#0d0520', fg='#7c5cbf',
                 font=('Consolas', 9)).pack(side='left', pady=12)
        tk.Frame(win, bg='#2a1050', height=1).pack(fill='x')

        kf = tk.Frame(win, bg='#08041a', pady=5)
        kf.pack(fill='x', padx=8)
        tk.Label(kf, text='Anthropic API key:', bg='#08041a', fg='#7c5cbf',
                 font=('Consolas', 8)).pack(side='left', padx=(4, 6))

        import os
        _key_file = Path.home() / '.nm_anthropic_key'
        saved_key = ''
        try:
            if _key_file.exists():
                saved_key = _key_file.read_text().strip()
        except Exception:
            pass
        api_key_var = tk.StringVar(value=saved_key)
        key_entry = tk.Entry(kf, textvariable=api_key_var, width=55,
                             bg='#0d0825', fg='#c084fc',
                             insertbackground='#c084fc', show='\u2022',
                             relief='flat', font=('Consolas', 9),
                             highlightthickness=1, highlightcolor='#8040c0',
                             highlightbackground='#2a1050')
        key_entry.pack(side='left', padx=(0, 6), ipady=3)

        def _toggle_show():
            cur = key_entry.cget('show')
            key_entry.config(show='' if cur == '\u2022' else '\u2022')
            show_btn.config(text='Hide' if cur == '\u2022' else 'Show')
        show_btn = tk.Button(kf, text='Show', bg='#1a0840', fg='#7c5cbf',
                             relief='flat', font=('Consolas', 8), cursor='hand2',
                             activebackground='#2a1060', command=_toggle_show)
        show_btn.pack(side='left', padx=2)

        def _save_key():
            try:
                _key_file.write_text(api_key_var.get().strip())
                import stat as _stat
                _key_file.chmod(_stat.S_IRUSR | _stat.S_IWUSR)
                ai_status.set('API key saved')
            except Exception as ex:
                ai_status.set(f'Could not save key: {ex}')
        tk.Button(kf, text='Save Key', bg='#1a0840', fg='#7c5cbf',
                  relief='flat', font=('Consolas', 8), cursor='hand2',
                  activebackground='#2a1060', command=_save_key).pack(side='left', padx=2)

        sg_frame = tk.Frame(win, bg='#08041a', pady=5)
        sg_frame.pack(fill='x', padx=8)
        tk.Label(sg_frame, text='Quick prompts:', bg='#08041a', fg='#7c5cbf',
                 font=('Consolas', 8)).pack(side='left', padx=(4, 8))

        query_var = tk.StringVar()
        suggestions = [
            'Summarise what happened in this capture',
            'Are there any suspicious or unusual patterns?',
            'Which hosts are generating the most traffic?',
            'What DNS lookups were made?',
            'Are there any signs of network errors or retransmissions?',
            'What connections were established and to where?',
        ]
        for sug in suggestions:
            short = sug[:32] + '\u2026' if len(sug) > 32 else sug
            tk.Button(sg_frame, text=short, bg='#1a0840', fg='#c084fc', relief='flat',
                      font=('Consolas', 7), cursor='hand2', padx=6,
                      activebackground='#2a1060', activeforeground='#e0b0ff',
                      command=lambda s=sug: (query_var.set(s),
                                             query_entry.icursor('end'))
                      ).pack(side='left', padx=2)

        tk.Frame(win, bg='#1a0840', height=1).pack(fill='x', padx=8, pady=(4, 0))

        qf = tk.Frame(win, bg='#08041a', pady=6)
        qf.pack(fill='x', padx=8)
        query_entry = tk.Entry(qf, textvariable=query_var, width=80,
                               bg='#0d0825', fg='#e0c0ff',
                               insertbackground='#c084fc',
                               relief='flat', font=('Consolas', 10),
                               highlightthickness=1, highlightcolor='#8040c0',
                               highlightbackground='#2a1050')
        query_entry.pack(side='left', fill='x', expand=True, padx=(0, 8), ipady=5)
        query_entry.insert(0, 'Summarise what happened in this capture')
        query_entry.select_range(0, 'end')

        send_btn = tk.Button(qf, text='  Ask AI  ',
                             bg='#3a1080', fg='#c084fc',
                             activebackground='#5020a0', activeforeground='#e0c0ff',
                             relief='flat', font=('Consolas', 10, 'bold'),
                             cursor='hand2', padx=12, pady=4)
        send_btn.pack(side='left')

        rf = tk.Frame(win, bg=self._PANEL)
        rf.pack(fill='both', expand=True, padx=8, pady=(4, 8))
        resp_txt = tk.Text(rf, bg='#06020f', fg='#e0c0ff',
                           font=('Consolas', 10), relief='flat',
                           wrap='word', state='disabled',
                           selectbackground='#3a1060', padx=12, pady=10)
        vsb = ttk.Scrollbar(rf, orient='vertical', command=resp_txt.yview)
        resp_txt.configure(yscrollcommand=vsb.set)
        vsb.pack(side='right', fill='y')
        resp_txt.pack(fill='both', expand=True)
        resp_txt.tag_configure('thinking', foreground='#7c5cbf',
                               font=('Consolas', 9, 'italic'))
        resp_txt.tag_configure('error',    foreground='#ff6b6b')
        resp_txt.tag_configure('body',     foreground='#e0c0ff')

        ai_status = tk.StringVar(value='Ready  \u2014  enter a question and click Ask AI')
        tk.Label(win, textvariable=ai_status, bg='#08041a', fg='#7c5cbf',
                 font=('Consolas', 8), anchor='w').pack(fill='x', padx=8, pady=(0, 4))

        def _set_resp(text, tag='body'):
            resp_txt.config(state='normal')
            resp_txt.delete('1.0', 'end')
            resp_txt.insert('end', text, tag)
            resp_txt.config(state='disabled')
            resp_txt.see('1.0')

        def _ask():
            question = query_var.get().strip()
            if not question: return
            key = api_key_var.get().strip()
            if not key:
                _set_resp('Please enter your Anthropic API key above.', 'error'); return
            if not self._packets:
                _set_resp('No capture data loaded.', 'error'); return
            send_btn.config(state='disabled', text='  Thinking...  ')
            ai_status.set('Building capture summary...')
            _set_resp('Analysing capture \u2014 please wait...', 'thinking')

            def _worker():
                try:
                    context = self._build_capture_context()
                    system_prompt = (
                        'You are a network security analyst and Wireshark expert. '
                        'Answer questions about the packet capture clearly and concisely. '
                        'Use bullet points where appropriate. '
                        'Highlight anything suspicious clearly.')
                    user_message = (
                        f'Here is a summary of the current packet capture:\n\n'
                        f'{context}\n\nQuestion: {question}')
                    import urllib.request, json as _json
                    payload = _json.dumps({
                        'model': 'claude-sonnet-4-20250514',
                        'max_tokens': 1000,
                        'system': system_prompt,
                        'messages': [{'role': 'user', 'content': user_message}]
                    }).encode()
                    req = urllib.request.Request(
                        'https://api.anthropic.com/v1/messages',
                        data=payload,
                        headers={'Content-Type': 'application/json',
                                 'x-api-key': key,
                                 'anthropic-version': '2023-06-01'},
                        method='POST')
                    win.after(0, lambda: ai_status.set('Waiting for AI response...'))
                    with urllib.request.urlopen(req, timeout=60) as resp:
                        data = _json.loads(resp.read(2*1024*1024).decode())
                    answer = ''.join(b.get('text','') for b in data.get('content',[]) if b.get('type')=='text')
                    if not answer: answer = '(No response received)'
                    win.after(0, lambda a=answer: (
                        _set_resp(a, 'body'),
                        ai_status.set(f'Done  \u2014  {len(a)} chars'),
                        send_btn.config(state='normal', text='  Ask AI  ')))
                except urllib.error.HTTPError as e:
                    body = e.read().decode(errors='replace')[:400]
                    msg  = f'API error {e.code}: {e.reason}\n\n{body}'
                    win.after(0, lambda m=msg: (
                        _set_resp(m, 'error'),
                        ai_status.set(f'Error {e.code}'),
                        send_btn.config(state='normal', text='  Ask AI  ')))
                except Exception as ex:
                    win.after(0, lambda m=str(ex): (
                        _set_resp(f'Error: {m}', 'error'),
                        ai_status.set('Error'),
                        send_btn.config(state='normal', text='  Ask AI  ')))
            threading.Thread(target=_worker, daemon=True).start()

        send_btn.config(command=_ask)
        query_entry.bind('<Return>', lambda e: _ask())

        copy_f = tk.Frame(win, bg='#08041a')
        copy_f.pack(fill='x', padx=8, pady=(0, 2))

        tk.Button(copy_f, text='Copy Response', bg='#1a0840', fg='#c084fc',
                  relief='flat', font=('Consolas', 8), cursor='hand2',
                  activebackground='#2a1060',
                  command=lambda: (win.clipboard_clear(),
                      win.clipboard_append(resp_txt.get('1.0', 'end').strip()))
                  ).pack(side='left', padx=2)
        tk.Button(copy_f, text='Clear Response', bg='#1a0840', fg='#7c5cbf',
                  relief='flat', font=('Consolas', 8), cursor='hand2',
                  activebackground='#2a1060',
                  command=lambda: _set_resp('')).pack(side='left', padx=2)

        add_btn = tk.Button(copy_f, text='+  Add to Report',
                            bg='#0a2a10', fg='#38f0a8', relief='flat',
                            font=('Consolas', 9, 'bold'), cursor='hand2',
                            padx=10, activebackground='#0e4020',
                            activeforeground='#60ffb8')
        add_btn.pack(side='left', padx=(16, 2))

        report_count_var = tk.StringVar(value='Report: 0 entries')
        tk.Label(copy_f, textvariable=report_count_var,
                 bg='#08041a', fg='#38f0a8',
                 font=('Consolas', 8)).pack(side='left', padx=8)

        pdf_btn = tk.Button(copy_f, text='📄  Generate Report',
                            bg='#1a0a00', fg='#ff9f43', relief='flat',
                            font=('Consolas', 9, 'bold'), cursor='hand2',
                            padx=10, activebackground='#2a1800',
                            activeforeground='#ffbf70')
        pdf_btn.pack(side='right', padx=2)

        report_entries = []

        def _add_to_report():
            q = query_var.get().strip()
            a = resp_txt.get('1.0', 'end').strip()
            if not a or 'please wait' in a:
                ai_status.set('Nothing to add — ask a question first'); return
            if not q: q = '(no question)'
            from datetime import datetime as _dt
            report_entries.append({'question': q, 'answer': a,
                                   'timestamp': _dt.now().strftime('%H:%M:%S')})
            report_count_var.set(
                f'Report: {len(report_entries)} entr{"y" if len(report_entries)==1 else "ies"}')
            ai_status.set(f'Added to report  ({len(report_entries)} total)')
            _refresh_list()

        add_btn.config(command=_add_to_report)

        def _generate_report():
            if not report_entries:
                self._mb.showwarning('No Report Entries',
                    'Add at least one Q&A response to the report first.\n\n'
                    'Ask a question, then click  + Add to Report.', parent=win); return
            from tkinter import filedialog as _fd
            from datetime import datetime as _dt
            default_name = f'capture_analysis_{_dt.now().strftime("%Y%m%d_%H%M%S")}.html'
            path = _fd.asksaveasfilename(
                parent=win, title='Save Report', defaultextension='.html',
                initialfile=default_name,
                filetypes=[('HTML Report', '*.html'), ('All files', '*.*')])
            if not path: return
            if not path.lower().endswith('.html'): path += '.html'
            ai_status.set('Generating report…')
            pdf_btn.config(state='disabled', text='Generating…')

            def _build():
                try:
                    import html as _h, re as _re
                    now_str = _dt.now().strftime('%A %d %B %Y at %H:%M:%S')
                    pkts = self._packets
                    stats_rows = ''
                    if pkts:
                        pc = {}
                        for row in pkts:
                            p = row[4] if len(row) > 4 else '?'
                            pc[p] = pc.get(p, 0) + 1
                        top = sorted(pc.items(), key=lambda x: -x[1])[:6]
                        top_str = ', '.join(f'{p} ({n:,})' for p, n in top)
                        try:
                            dur = float(pkts[-1][1]) - float(pkts[0][1])
                            dur_str = f'{dur:.3f} s'
                        except Exception:
                            dur_str = '—'
                        cap_file = self._capfile.name if self._capfile.exists() else 'Live capture'
                        for label, val in [
                            ('Packets in view', f'{len(pkts):,}'),
                            ('Duration', dur_str),
                            ('Capture file', _h.escape(cap_file)),
                            ('Top protocols', _h.escape(top_str)),
                            ('Queries in report', str(len(report_entries))),
                        ]:
                            stats_rows += f'<tr><th>{label}</th><td>{val}</td></tr>\n'
                    else:
                        stats_rows = '<tr><td colspan="2">No packet data</td></tr>'

                    entries_html = ''
                    for i, entry in enumerate(report_entries, 1):
                        q = _h.escape(entry['question'])
                        ts = _h.escape(entry['timestamp'])
                        ans = _h.escape(entry['answer'])
                        ans = _re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', ans)
                        ans = _re.sub(r'\*(.+?)\*', r'<em>\1</em>', ans)
                        lines = ans.split('\n'); formatted = []; in_ul = False
                        for ln in lines:
                            s = ln.strip()
                            is_b = s.startswith('- ') or s.startswith('\u2022 ')
                            if is_b:
                                if not in_ul: formatted.append('<ul>'); in_ul = True
                                formatted.append(f'<li>{s[2:]}</li>')
                            else:
                                if in_ul: formatted.append('</ul>'); in_ul = False
                                formatted.append(f'<p>{ln}</p>' if s else '<br>')
                        if in_ul: formatted.append('</ul>')
                        ans_html = '\n'.join(formatted)
                        entries_html += (
                            f'\n            <div class="entry">'
                            f'\n              <div class="entry-meta">Query {i} of {len(report_entries)} &nbsp;&middot;&nbsp; {ts}</div>'
                            f'\n              <div class="question"><span class="q-label">Q</span>{q}</div>'
                            f'\n              <div class="answer">{ans_html}</div>'
                            f'\n            </div>'
                        )

                    css = (
                        '* { box-sizing:border-box; margin:0; padding:0; }'
                        'body { font-family:"Segoe UI",Arial,sans-serif; font-size:14px; color:#1a1a2e; background:#f4f2fa; }'
                        '.page { max-width:900px; margin:0 auto; padding:32px 24px; }'
                        '.header { background:linear-gradient(135deg,#4a1080,#7030a0); color:white; padding:28px 32px; border-radius:8px; margin-bottom:24px; }'
                        '.header h1 { font-size:26px; font-weight:700; margin-bottom:6px; }'
                        '.header .sub { opacity:.80; font-size:13px; }'
                        '.stats-table { width:100%; border-collapse:collapse; margin-bottom:28px; background:white; border-radius:8px; overflow:hidden; }'
                        '.stats-table th { background:#7030a0; color:white; padding:9px 16px; text-align:left; font-weight:600; width:180px; font-size:13px; }'
                        '.stats-table td { padding:9px 16px; border-bottom:1px solid #ede8f5; font-size:13px; }'
                        '.stats-table tr:last-child td { border-bottom:none; }'
                        '.stats-table tr:nth-child(even) th,.stats-table tr:nth-child(even) td { background:#faf8ff; }'
                        '.section-title { font-size:17px; font-weight:700; color:#5020a0; margin:0 0 16px; padding-bottom:8px; border-bottom:2px solid #c084fc; }'
                        '.entry { background:white; border-radius:8px; margin-bottom:20px; overflow:hidden; border-left:4px solid #7030a0; }'
                        '.entry-meta { background:#f8f4ff; padding:7px 16px; font-size:11px; color:#8060a0; border-bottom:1px solid #ede8f5; }'
                        '.question { padding:14px 16px 10px; display:flex; gap:12px; align-items:flex-start; background:#f0eaff; font-weight:600; font-size:14px; color:#2a0a50; }'
                        '.q-label { background:#7030a0; color:white; border-radius:4px; padding:2px 8px; font-weight:700; font-size:12px; flex-shrink:0; margin-top:1px; }'
                        '.answer { padding:14px 18px; font-size:13px; line-height:1.7; color:#2c2c3a; }'
                        '.answer p { margin-bottom:8px; } .answer ul { margin:6px 0 10px 20px; } .answer li { margin-bottom:4px; }'
                        '.answer strong { color:#4a1080; }'
                        '.footer { text-align:center; margin-top:40px; padding-top:16px; border-top:1px solid #d8cced; font-size:11px; color:#9080a0; }'
                        '@media print { body{background:white;} .page{max-width:none;padding:16px;} .entry{break-inside:avoid;} }'
                    )
                    html_doc = (
                        '<!DOCTYPE html><html lang="en"><head>'
                        '<meta charset="UTF-8">'
                        '<meta name="viewport" content="width=device-width,initial-scale=1.0">'
                        '<title>Wireshark AI Capture Analysis</title>'
                        f'<style>{css}</style></head><body><div class="page">'
                        '<div class="header"><h1>&#10022; Wireshark AI Capture Analysis</h1>'
                        f'<div class="sub">Generated: {now_str} &nbsp;&middot;&nbsp; Powered by Claude (Anthropic)</div></div>'
                        '<h2 class="section-title">Capture Summary</h2>'
                        f'<table class="stats-table">{stats_rows}</table>'
                        f'<h2 class="section-title">Analysis Queries ({len(report_entries)})</h2>'
                        f'{entries_html}'
                        '<div class="footer">Network Monitor &nbsp;&middot;&nbsp; Wireshark AI Analysis'
                        f' &nbsp;&middot;&nbsp; {_dt.now().strftime("%Y-%m-%d %H:%M")}'
                        '<br><br><em>To save as PDF: open in your browser and use '
                        'File &rarr; Print &rarr; Save as PDF</em></div>'
                        '</div></body></html>'
                    )
                    with open(path, 'w', encoding='utf-8') as f:
                        f.write(html_doc)
                    return path
                except Exception as ex:
                    import traceback as _tb
                    return 'ERROR:' + _tb.format_exc()

            def _done(result):
                pdf_btn.config(state='normal', text='📄  Generate Report')
                if isinstance(result, str) and result.startswith('ERROR:'):
                    ai_status.set('Report generation failed')
                    self._mb.showerror('Report Failed', f'Failed:\n\n{result[6:][:600]}', parent=win)
                else:
                    ai_status.set(f'Report saved: {result}')
                    self._mb.showinfo('Report Saved',
                        f'Report saved:\n{result}\n\n'
                        'Open in your browser. Use File \u2192 Print \u2192 Save as PDF.',
                        parent=win)
                    try:
                        import os as _os
                        if sys.platform == 'win32': _os.startfile(result)
                        elif sys.platform == 'darwin':
                            import subprocess as _sp; _sp.Popen(['open', result])
                        else:
                            import subprocess as _sp; _sp.Popen(['xdg-open', result])
                    except Exception: pass

            threading.Thread(target=lambda: win.after(0, lambda: _done(_build())),
                             daemon=True).start()

        pdf_btn.config(command=_generate_report)

        # Report queue panel
        tk.Frame(win, bg='#0a2818', height=1).pack(fill='x', padx=8, pady=(4, 0))
        rp_hdr = tk.Frame(win, bg='#040f08', pady=3)
        rp_hdr.pack(fill='x', padx=8)
        tk.Label(rp_hdr, text='Report queue:', bg='#040f08', fg='#38f0a8',
                 font=('Consolas', 8, 'bold')).pack(side='left', padx=4)
        tk.Label(rp_hdr, text='Add responses above to build a multi-section HTML report',
                 bg='#040f08', fg='#1a6040',
                 font=('Consolas', 7)).pack(side='left', padx=4)

        rp_frame = tk.Frame(win, bg='#040f08', height=80)
        rp_frame.pack(fill='x', padx=8); rp_frame.pack_propagate(False)

        rp_list = tk.Listbox(rp_frame, bg='#040f08', fg='#38f0a8',
                             selectbackground='#0a3020', selectforeground='#60ffb8',
                             font=('Consolas', 8), relief='flat', activestyle='none',
                             highlightthickness=0, borderwidth=0)
        rp_vsb = ttk.Scrollbar(rp_frame, orient='vertical', command=rp_list.yview)
        rp_list.configure(yscrollcommand=rp_vsb.set)
        rp_vsb.pack(side='right', fill='y')
        rp_list.pack(fill='both', expand=True, padx=(4, 0))

        def _refresh_list():
            rp_list.delete(0, 'end')
            for i, e in enumerate(report_entries, 1):
                q_short = e['question'][:70] + ('…' if len(e['question']) > 70 else '')
                rp_list.insert('end', f'  {i}.  [{e["timestamp"]}]  {q_short}')

        def _remove_entry():
            sel = rp_list.curselection()
            if not sel: return
            report_entries.pop(sel[0]); _refresh_list()
            report_count_var.set(
                f'Report: {len(report_entries)} entr{"y" if len(report_entries)==1 else "ies"}')

        def _move_up():
            sel = rp_list.curselection()
            if not sel or sel[0] == 0: return
            i = sel[0]
            report_entries[i-1], report_entries[i] = report_entries[i], report_entries[i-1]
            _refresh_list(); rp_list.selection_set(i-1)

        def _move_down():
            sel = rp_list.curselection()
            if not sel or sel[0] >= len(report_entries)-1: return
            i = sel[0]
            report_entries[i], report_entries[i+1] = report_entries[i+1], report_entries[i]
            _refresh_list(); rp_list.selection_set(i+1)

        lc_frame = tk.Frame(win, bg='#040f08')
        lc_frame.pack(fill='x', padx=8, pady=(0, 8))
        for btn_txt, btn_cmd in [('▲ Move Up', _move_up),
                                   ('▼ Move Down', _move_down),
                                   ('✕ Remove', _remove_entry)]:
            tk.Button(lc_frame, text=btn_txt, command=btn_cmd,
                      bg='#0a2010', fg='#38f0a8', relief='flat',
                      font=('Consolas', 8), cursor='hand2', padx=8,
                      activebackground='#0e3018',
                      activeforeground='#60ffb8').pack(side='left', padx=2)

        query_entry.focus_set()



# ─────────────────────────────────────────────────────────────────────────────
#  AgentsWindow  –  remote agent management & live dashboard
# ─────────────────────────────────────────────────────────────────────────────
class AgentsWindow:
    """
    Connect to one or more speedtest_agent.py instances running on remote
    machines.  Polls their /status and /data endpoints and shows live gauges
    and charts alongside their info.
    """
    POLL_MS   = 10_000   # poll each agent every 10 s
    AGENTS_FILE = str(Path(__file__).parent / 'speedtest_agents.json')

    _BG    = '#050d1a'
    _PANEL = '#06101e'
    _ACC   = '#39ff14'
    _TEXT  = '#c8dff0'
    _TICK  = '#6a9ab8'
    _SPIN  = '#0a1828'

    def __init__(self, monitor: SpeedTestMonitor):
        import tkinter as tk
        from tkinter import ttk
        self._tk  = tk
        self._ttk = ttk
        self._monitor = monitor
        self._closed  = False

        # agents: list of dicts {url, token, label, status, data, error, last_ok}
        self._agents = self._load_agents()
        # polling: {url: after_id}
        self._polls  = {}

        self.root = tk.Toplevel()
        self.root.title('Remote Agents')
        self.root.configure(bg=self._BG)
        self.root.geometry('1200x780')
        self.root.minsize(800, 500)
        self.root.protocol('WM_DELETE_WINDOW', self._on_close)

        self._build_ui()
        self.root.update_idletasks()
        self.root.lift()
        self.root.focus_force()

        # Start polling all saved agents
        for ag in self._agents:
            self._schedule_poll(ag)

    def _on_close(self):
        self._closed = True
        self.root.destroy()

    # ── Persistence ───────────────────────────────────────────────────────────
    def _load_agents(self):
        try:
            if Path(self.AGENTS_FILE).exists():
                with open(self.AGENTS_FILE) as f:
                    saved = json.load(f)
                agents = []
                for s in saved:
                    if isinstance(s, dict) and 'url' in s:
                        agents.append({
                            'url':     s['url'].rstrip('/'),
                            'token':   s.get('token', ''),
                            'label':   s.get('label', s['url']),
                            'status':  None,
                            'data':    None,
                            'error':   None,
                            'last_ok': None,
                        })
                return agents
        except Exception:
            pass
        return []

    def _save_agents(self):
        try:
            serialisable = [
                {'url': a['url'], 'token': a['token'], 'label': a['label']}
                for a in self._agents
            ]
            with open(self.AGENTS_FILE, 'w') as f:
                json.dump(serialisable, f, indent=2)
        except Exception:
            pass

    # ── UI ────────────────────────────────────────────────────────────────────
    def _build_ui(self):
        tk  = self._tk
        ttk = self._ttk
        r   = self.root

        # Header
        hdr = tk.Frame(r, bg='#020810', height=46)
        hdr.pack(fill='x'); hdr.pack_propagate(False)
        tk.Label(hdr, text='⊞  REMOTE AGENTS',
                 bg='#020810', fg=self._ACC,
                 font=('Consolas', 15, 'bold')).pack(side='left', padx=16, pady=8)
        tk.Label(hdr, text='Monitor speedtest agents on remote machines',
                 bg='#020810', fg=self._TICK,
                 font=('Consolas', 9)).pack(side='left', pady=14)
        tk.Frame(r, bg=self._SPIN, height=1).pack(fill='x')

        # Toolbar
        tb = tk.Frame(r, bg='#040c1a', pady=5)
        tb.pack(fill='x', padx=4)

        def btn(parent, text, cmd, fg, bg, hover):
            return tk.Button(parent, text=text, command=cmd,
                             bg=bg, fg=fg, activebackground=hover,
                             activeforeground=fg, relief='flat',
                             font=('Consolas', 9, 'bold'),
                             cursor='hand2', padx=8, pady=3)

        btn(tb, '+  Add Agent', self._add_agent_dialog,
            self._ACC, '#062a1a', '#0a4028').pack(side='left', padx=2)
        btn(tb, '✕  Remove', self._remove_selected,
            '#ff6b6b', '#200808', '#3a1010').pack(side='left', padx=2)
        btn(tb, '↺  Refresh All', self._refresh_all,
            '#38b8f0', '#062040', '#0a3a60').pack(side='left', padx=2)

        tk.Frame(tb, bg=self._SPIN, width=1, height=26).pack(side='left', padx=8)

        btn(tb, '▶  Run Test on Selected', self._run_on_selected,
            '#ffd93d', '#1a1400', '#2a2200').pack(side='left', padx=2)

        self._status_var = tk.StringVar(value='No agents configured')
        tk.Label(tb, textvariable=self._status_var, bg='#040c1a',
                 fg=self._TICK, font=('Consolas', 8)).pack(side='right', padx=12)

        tk.Frame(r, bg=self._SPIN, height=1).pack(fill='x')

        # Main pane: agent list left, detail right
        pw = tk.PanedWindow(r, orient='horizontal', bg='#0a1828',
                            sashwidth=6, sashrelief='raised', handlesize=10)
        pw.pack(fill='both', expand=True)

        # Agent list
        lf = tk.Frame(pw, bg=self._PANEL)
        pw.add(lf, width=340)

        tk.Label(lf, text='  Agents', bg='#040c1a', fg=self._ACC,
                 font=('Consolas', 9, 'bold')).pack(fill='x', pady=(2, 0))

        cols  = ('label', 'url', 'dl', 'ul', 'ping', 'status')
        hdrs  = ('Label', 'URL', 'DL', 'UL', 'Ping', 'Status')
        widths = (100, 140, 55, 55, 55, 70)

        s = ttk.Style(r)
        s.theme_use('clam')
        s.configure('Ag.Treeview',
                    background=self._PANEL, fieldbackground=self._PANEL,
                    foreground=self._TEXT, font=('Consolas', 9),
                    rowheight=20, borderwidth=0)
        s.configure('Ag.Treeview.Heading',
                    background='#040c1a', foreground=self._TICK,
                    font=('Consolas', 9, 'bold'), relief='flat')
        s.map('Ag.Treeview',
              background=[('selected', '#0a3060')],
              foreground=[('selected', 'white')])

        self._tree = ttk.Treeview(lf, columns=cols, show='headings',
                                   style='Ag.Treeview', selectmode='browse')
        for c, h, w in zip(cols, hdrs, widths):
            self._tree.heading(c, text=h, anchor='w')
            self._tree.column(c, width=w, minwidth=30, stretch=(c == 'url'))
        self._tree.tag_configure('ok',      foreground='#2ea043')
        self._tree.tag_configure('error',   foreground='#ff6b6b')
        self._tree.tag_configure('polling', foreground='#ffd93d')
        vsb = ttk.Scrollbar(lf, orient='vertical', command=self._tree.yview)
        self._tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side='right', fill='y')
        self._tree.pack(fill='both', expand=True, padx=(4, 0), pady=(0, 4))
        self._tree.bind('<<TreeviewSelect>>', self._on_select)

        # Detail panel (right)
        rf = tk.Frame(pw, bg=self._PANEL)
        pw.add(rf)

        self._detail_canvas = tk.Canvas(rf, bg=self._PANEL,
                                         highlightthickness=0)
        detail_vsb = ttk.Scrollbar(rf, orient='vertical',
                                   command=self._detail_canvas.yview)
        self._detail_canvas.configure(yscrollcommand=detail_vsb.set)
        detail_vsb.pack(side='right', fill='y')
        self._detail_canvas.pack(fill='both', expand=True)

        self._detail_frame = tk.Frame(self._detail_canvas, bg=self._PANEL)
        self._canvas_window = self._detail_canvas.create_window(
            (0, 0), window=self._detail_frame, anchor='nw')

        def _on_configure(event):
            self._detail_canvas.configure(
                scrollregion=self._detail_canvas.bbox('all'))
            self._detail_canvas.itemconfig(
                self._canvas_window, width=event.width)

        self._detail_frame.bind('<Configure>', _on_configure)
        self._detail_canvas.bind('<Configure>',
            lambda e: self._detail_canvas.itemconfig(
                self._canvas_window, width=e.width))

        self._show_placeholder()

        # Status bar
        sb = tk.Frame(r, bg='#020810', height=22)
        sb.pack(fill='x', side='bottom'); sb.pack_propagate(False)
        self._sb_var = tk.StringVar(value='')
        tk.Label(sb, textvariable=self._sb_var, bg='#020810',
                 fg=self._TICK, font=('Consolas', 8), anchor='w').pack(
            side='left', padx=8, pady=2)

        self._refresh_tree()

    def _show_placeholder(self):
        for w in self._detail_frame.winfo_children():
            w.destroy()
        self._tk.Label(
            self._detail_frame,
            text='Select an agent to see its live data\n\n'
                 'Click  +  Add Agent  to connect to a remote machine\n\n'
                 'The agent runs speedtest_agent.py on the remote host',
            bg=self._PANEL, fg=self._TICK,
            font=('Consolas', 10), justify='center').pack(
            expand=True, pady=60)

    # ── Agent list management ─────────────────────────────────────────────────
    def _refresh_tree(self):
        self._tree.delete(*self._tree.get_children())
        for ag in self._agents:
            st = ag.get('status') or {}
            dl   = f"{st['download']:.1f}"  if st and st.get('download')  is not None else '—'
            ul   = f"{st['upload']:.1f}"    if st and st.get('upload')    is not None else '—'
            ping = f"{st['ping']:.0f}"      if st and st.get('ping')      is not None else '—'
            if ag.get('error'):
                status_str = 'error'; tag = 'error'
            elif ag['status'] is None:
                status_str = 'polling…'; tag = 'polling'
            else:
                status_str = 'ok'; tag = 'ok'
            self._tree.insert('', 'end',
                              iid=ag['url'],
                              values=(ag['label'], ag['url'],
                                      dl, ul, ping, status_str),
                              tags=(tag,))
        n = len(self._agents)
        ok = sum(1 for a in self._agents if a['status'] is not None and not a.get('error'))
        self._status_var.set(f'{n} agent{"s" if n!=1 else ""}  |  {ok} online')

    def _add_agent_dialog(self):
        tk = self._tk
        win = tk.Toplevel(self.root)
        win.title('Add Agent')
        win.configure(bg='#0a1828')
        win.resizable(False, False)
        win.grab_set()

        FG = '#c8dff0'; BG2 = '#0a1828'; ENT = '#0d2235'; ACC = '#39ff14'

        def lbl(text):
            return tk.Label(win, text=text, fg=FG, bg=BG2, font=('Consolas', 9))

        def entry(width=36):
            return tk.Entry(win, width=width, bg=ENT, fg=FG,
                            insertbackground=FG, relief='flat',
                            font=('Consolas', 9), highlightthickness=1,
                            highlightcolor=ACC, highlightbackground='#1a3050')

        tk.Label(win, text='⊞  Add Remote Agent', fg=ACC, bg=BG2,
                 font=('Consolas', 11, 'bold')).grid(
            row=0, column=0, columnspan=2, pady=(14, 8), padx=16)
        tk.Frame(win, bg='#1a3050', height=1).grid(
            row=1, column=0, columnspan=2, sticky='ew', padx=12, pady=(0, 8))

        for row, (label, hint) in enumerate([
            ('Agent URL',  'e.g.  http://192.168.1.10:7331'),
            ('Label',      'Friendly name (optional)'),
            ('Auth token', 'Leave blank if agent has no token'),
        ], start=2):
            lbl(label).grid(row=row, column=0, sticky='w', padx=14, pady=4)
            e = entry()
            e.grid(row=row, column=1, padx=(0, 14), pady=4)
            tk.Label(win, text=hint, fg='#2a4a6a', bg=BG2,
                     font=('Consolas', 7)).grid(
                row=row+3, column=1, sticky='w', padx=(0, 14))
            if row == 2: url_e    = e
            elif row == 3: label_e = e
            else:          token_e = e

        err_var = tk.StringVar()
        tk.Label(win, textvariable=err_var, fg='#ff6b6b', bg=BG2,
                 font=('Consolas', 8)).grid(row=8, column=0, columnspan=2, padx=14)

        def _add():
            url = url_e.get().strip().rstrip('/')
            if not url:
                err_var.set('URL is required'); return
            if not url.startswith('http'):
                url = 'http://' + url
            lbl_v   = label_e.get().strip() or url
            tok     = token_e.get().strip()
            if any(a['url'] == url for a in self._agents):
                err_var.set('Agent already added'); return
            ag = {'url': url, 'token': tok, 'label': lbl_v,
                  'status': None, 'data': None, 'error': None, 'last_ok': None}
            self._agents.append(ag)
            self._save_agents()
            self._refresh_tree()
            self._schedule_poll(ag)
            win.destroy()

        bf = tk.Frame(win, bg=BG2); bf.grid(row=9, column=0, columnspan=2, pady=(8, 14))
        tk.Button(bf, text='  Add  ', bg='#062a1a', fg=ACC, relief='flat',
                  font=('Consolas', 10, 'bold'), cursor='hand2',
                  command=_add).pack(side='left', padx=8)
        tk.Button(bf, text='  Cancel  ', bg='#1a1a2a', fg='#8899aa', relief='flat',
                  font=('Consolas', 10), cursor='hand2',
                  command=win.destroy).pack(side='left', padx=8)
        url_e.focus_set()

    def _remove_selected(self):
        sel = self._tree.selection()
        if not sel: return
        url = sel[0]
        self._agents = [a for a in self._agents if a['url'] != url]
        self._save_agents()
        self._refresh_tree()
        self._show_placeholder()

    def _refresh_all(self):
        for ag in self._agents:
            threading.Thread(target=self._fetch_agent, args=(ag,),
                             daemon=True).start()

    def _run_on_selected(self):
        sel = self._tree.selection()
        if not sel: return
        url = sel[0]
        ag  = next((a for a in self._agents if a['url'] == url), None)
        if not ag: return
        self._sb_var.set(f'Triggering test on {ag["label"]}…')
        threading.Thread(target=self._post_agent,
                         args=(ag, '/run'), daemon=True).start()

    def _on_select(self, event=None):
        sel = self._tree.selection()
        if not sel: return
        url = sel[0]
        ag  = next((a for a in self._agents if a['url'] == url), None)
        if ag:
            self._show_agent_detail(ag)

    # ── Polling ───────────────────────────────────────────────────────────────
    def _schedule_poll(self, ag):
        if self._closed: return
        threading.Thread(target=self._fetch_agent, args=(ag,),
                         daemon=True).start()
        # Store after_id keyed by url so we can cancel if removed
        after_id = self.root.after(self.POLL_MS,
                                   lambda a=ag: self._schedule_poll(a))
        self._polls[ag['url']] = after_id

    def _fetch_agent(self, ag):
        """Fetch /status and /data from agent. Called in background thread."""
        import urllib.request, urllib.error
        headers = {}
        if ag['token']:
            headers['Authorization'] = f'Bearer {ag["token"]}'

        def _get(path):
            req = urllib.request.Request(ag['url'] + path, headers=headers)
            with urllib.request.urlopen(req, timeout=8) as resp:
                return json.loads(resp.read().decode())

        try:
            status = _get('/status')
            data   = _get('/data')
            info   = _get('/info')
            ag['status']  = status
            ag['data']    = data
            ag['info']    = info
            ag['error']   = None
            ag['last_ok'] = datetime.now().isoformat()
        except urllib.error.HTTPError as e:
            ag['error'] = f'HTTP {e.code}: {e.reason}'
        except Exception as e:
            ag['error'] = str(e)

        if not self._closed:
            self.root.after(0, lambda: self._on_agent_updated(ag))

    def _post_agent(self, ag, path):
        import urllib.request, urllib.error
        headers = {'Content-Length': '0'}
        if ag['token']:
            headers['Authorization'] = f'Bearer {ag["token"]}'
        try:
            req = urllib.request.Request(
                ag['url'] + path, data=b'',
                headers=headers, method='POST')
            with urllib.request.urlopen(req, timeout=8) as resp:
                result = json.loads(resp.read().decode())
            if not self._closed:
                self.root.after(0, lambda: self._sb_var.set(
                    f'{ag["label"]}: {result.get("message", "queued")}'))
        except Exception as ex:
            if not self._closed:
                self.root.after(0, lambda: self._sb_var.set(
                    f'{ag["label"]}: error — {ex}'))

    def _on_agent_updated(self, ag):
        self._refresh_tree()
        # If this agent is currently selected, refresh the detail panel
        sel = self._tree.selection()
        if sel and sel[0] == ag['url']:
            self._show_agent_detail(ag)

    # ── Detail panel ──────────────────────────────────────────────────────────
    def _show_agent_detail(self, ag):
        tk  = self._tk
        ttk = self._ttk
        for w in self._detail_frame.winfo_children():
            w.destroy()

        FG = '#c8dff0'; BG2 = self._PANEL; TICK = self._TICK; ACC = self._ACC

        # ── Header ────────────────────────────────────────────────────────────
        hf = tk.Frame(self._detail_frame, bg='#040c1a')
        hf.pack(fill='x', pady=(0, 2))
        tk.Label(hf, text=f'  {ag["label"]}',
                 bg='#040c1a', fg=ACC,
                 font=('Consolas', 12, 'bold')).pack(side='left', padx=8, pady=6)

        if ag.get('error'):
            tk.Label(hf, text=f'⚠  {ag["error"]}',
                     bg='#040c1a', fg='#ff6b6b',
                     font=('Consolas', 8)).pack(side='left', padx=4)
        elif ag['last_ok']:
            try:
                t = datetime.fromisoformat(ag['last_ok'])
                since = int((datetime.now() - t).total_seconds())
                tk.Label(hf, text=f'Last update: {since}s ago',
                         bg='#040c1a', fg='#2ea043',
                         font=('Consolas', 8)).pack(side='right', padx=12)
            except Exception:
                pass

        tk.Frame(self._detail_frame, bg=self._SPIN, height=1).pack(fill='x')

        # ── Info row ──────────────────────────────────────────────────────────
        info = ag.get('info', {})
        if info:
            inf = tk.Frame(self._detail_frame, bg=BG2, pady=4)
            inf.pack(fill='x', padx=8)
            items = [
                ('Hostname', info.get('hostname', '—')),
                ('IP',       info.get('ip', '—')),
                ('Uptime',   f'{info.get("uptime_seconds", 0)//60} min'),
                ('Interval', f'{info.get("interval_minutes", "?")} min'),
                ('URL',      ag['url']),
            ]
            for col, (label, val) in enumerate(items):
                f = tk.Frame(inf, bg=BG2)
                f.pack(side='left', padx=12)
                tk.Label(f, text=label, fg=TICK, bg=BG2,
                         font=('Consolas', 7)).pack()
                tk.Label(f, text=val, fg=FG, bg=BG2,
                         font=('Consolas', 9, 'bold')).pack()

        tk.Frame(self._detail_frame, bg=self._SPIN, height=1).pack(fill='x')

        # ── Latest readings ───────────────────────────────────────────────────
        st = ag.get('status') or {}
        readings = [
            ('Download', st.get('download'), 'Mbps', '#00d4aa'),
            ('Upload',   st.get('upload'),   'Mbps', '#a371f7'),
            ('Ping',     st.get('ping'),     'ms',   '#f7cc73'),
            ('DNS',      st.get('dns'),      'ms',   '#ff9f43'),
        ]
        rf2 = tk.Frame(self._detail_frame, bg=BG2, pady=8)
        rf2.pack(fill='x', padx=8)
        for label, val, unit, color in readings:
            f = tk.Frame(rf2, bg='#06101e', padx=16, pady=8)
            f.pack(side='left', expand=True, fill='both', padx=4)
            tk.Label(f, text=label, fg=TICK, bg='#06101e',
                     font=('Consolas', 8)).pack()
            val_str = f'{val:.1f}' if val is not None else '—'
            tk.Label(f, text=val_str, fg=color, bg='#06101e',
                     font=('Consolas', 20, 'bold')).pack()
            tk.Label(f, text=unit, fg=color, bg='#06101e',
                     font=('Consolas', 8)).pack()

        tk.Frame(self._detail_frame, bg=self._SPIN, height=1).pack(fill='x')

        # ── History chart (matplotlib embedded) ───────────────────────────────
        data = ag.get('data')
        if data and data.get('timestamps'):
            try:
                from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
                import matplotlib.figure as _mf
                import matplotlib.dates as _mdates
                from matplotlib.dates import DateFormatter

                times  = [datetime.fromisoformat(ts) for ts in data['timestamps']]
                dl_vals = data['download']
                ul_vals = data['upload']
                pg_vals = data['ping']

                fig = _mf.Figure(figsize=(8, 3.5), facecolor=PANEL_BG)
                fig.subplots_adjust(left=0.06, right=0.97,
                                    top=0.88, bottom=0.18, hspace=0.4)

                ax_dl = fig.add_subplot(1, 3, 1)
                ax_ul = fig.add_subplot(1, 3, 2)
                ax_pg = fig.add_subplot(1, 3, 3)

                c = self._monitor.colors

                for ax, vals, color, title, ylabel in [
                    (ax_dl, dl_vals, c['download'], 'Download', 'Mbps'),
                    (ax_ul, ul_vals, c['upload'],   'Upload',   'Mbps'),
                    (ax_pg, pg_vals, c['ping'],     'Latency',  'ms'),
                ]:
                    ax.set_facecolor(PANEL_BG)
                    clean = [v if v is not None else 0 for v in vals]
                    if len(times) > 1:
                        ax.fill_between(times, 0, clean,
                                        color=color, alpha=0.15)
                        ax.plot(times, clean, color=color,
                                lw=1.4, alpha=0.95)
                    ax.xaxis.set_major_formatter(DateFormatter('%H:%M'))
                    ax.tick_params(colors=TICK_COL, labelsize=6, length=2)
                    for sp in ax.spines.values():
                        sp.set_color(SPIN_COL)
                    ax.set_title(title, loc='left', color=TEXT_COL,
                                 fontsize=8, fontweight='bold', pad=4)
                    ax.set_ylabel(ylabel, color=TICK_COL, fontsize=7)
                    ax.yaxis.grid(True, color='#1a2535',
                                  linewidth=0.5, alpha=0.8)
                    import matplotlib.pyplot as _plt
                    _plt.setp(ax.get_xticklabels(), rotation=30,
                              ha='right', color=TICK_COL, fontsize=6)

                cf = tk.Frame(self._detail_frame, bg=BG2)
                cf.pack(fill='x', padx=8, pady=4)
                canvas = FigureCanvasTkAgg(fig, master=cf)
                canvas.draw()
                canvas.get_tk_widget().pack(fill='x')

            except Exception as ex:
                tk.Label(self._detail_frame,
                         text=f'Chart error: {ex}',
                         bg=BG2, fg='#ff6b6b',
                         font=('Consolas', 8)).pack(padx=8, pady=4)

        # ── Action buttons ────────────────────────────────────────────────────
        af = tk.Frame(self._detail_frame, bg=BG2, pady=6)
        af.pack(fill='x', padx=8)

        def _run_test():
            self._sb_var.set(f'Triggering test on {ag["label"]}…')
            threading.Thread(target=self._post_agent,
                             args=(ag, '/run'), daemon=True).start()

        def _run_dns():
            self._sb_var.set(f'Triggering DNS check on {ag["label"]}…')
            threading.Thread(target=self._post_agent,
                             args=(ag, '/dns'), daemon=True).start()

        def _refresh_now():
            threading.Thread(target=self._fetch_agent,
                             args=(ag,), daemon=True).start()

        for text, cmd, fg, bg in [
            ('▶  Run Speed Test', _run_test,  '#ffd93d', '#1a1400'),
            ('⊙  Run DNS Check',  _run_dns,   '#ff9f43', '#1a0e00'),
            ('↺  Refresh Now',    _refresh_now,'#38b8f0', '#062040'),
        ]:
            tk.Button(af, text=text, command=cmd,
                      bg=bg, fg=fg, relief='flat',
                      font=('Consolas', 9, 'bold'), cursor='hand2',
                      padx=10, pady=4,
                      activebackground=bg,
                      activeforeground=fg).pack(side='left', padx=4)


if __name__ == "__main__":
    monitor = SpeedTestMonitor()
    threading.Thread(target=monitor.run_continuous, daemon=True).start()
    monitor.create_graph()
